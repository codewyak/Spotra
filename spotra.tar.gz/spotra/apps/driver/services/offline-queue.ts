import * as SQLite from 'expo-sqlite';
import NetInfo from '@react-native-community/netinfo';

const db = SQLite.openDatabaseSync('spotra_offline.db');

export interface QueuedAction {
  id: number;
  type: string;
  payload: string;
  createdAt: number;
  attempts: number;
}

export async function initOfflineQueue(): Promise<void> {
  db.execSync(`
    CREATE TABLE IF NOT EXISTS offline_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      payload TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      attempts INTEGER DEFAULT 0
    );
  `);
}

export async function enqueue(type: string, payload: object): Promise<void> {
  db.runSync(
    'INSERT INTO offline_queue (type, payload, created_at) VALUES (?, ?, ?)',
    [type, JSON.stringify(payload), Date.now()]
  );
}

export async function getPendingActions(): Promise<QueuedAction[]> {
  return db.getAllSync(
    'SELECT * FROM offline_queue WHERE attempts < 3 ORDER BY created_at ASC'
  ) as QueuedAction[];
}

export async function removeAction(id: number): Promise<void> {
  db.runSync('DELETE FROM offline_queue WHERE id = ?', [id]);
}

export async function incrementAttempts(id: number): Promise<void> {
  db.runSync('UPDATE offline_queue SET attempts = attempts + 1 WHERE id = ?', [id]);
}

// Call on reconnect to flush pending actions
export async function syncPendingActions(
  executeAction: (type: string, payload: object) => Promise<void>
): Promise<{ synced: number; failed: number }> {
  const netInfo = await NetInfo.fetch();
  if (!netInfo.isConnected) return { synced: 0, failed: 0 };

  const pending = await getPendingActions();
  let synced = 0, failed = 0;

  for (const action of pending) {
    try {
      await executeAction(action.type, JSON.parse(action.payload));
      await removeAction(action.id);
      synced++;
    } catch {
      await incrementAttempts(action.id);
      failed++;
    }
  }

  return { synced, failed };
}
