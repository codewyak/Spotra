import * as Location from 'expo-location';
import { DRIVER_LOCATION_SYNC_INTERVAL_MS } from '@spotra/shared';

let watchSub: Location.LocationSubscription | null = null;
let syncInterval: ReturnType<typeof setInterval> | null = null;
let lastLocation: Location.LocationObject | null = null;
let onLocationUpdate: ((loc: Location.LocationObject) => void) | null = null;

export async function requestPermissions(): Promise<boolean> {
  const { status } = await Location.requestForegroundPermissionsAsync();
  return status === 'granted';
}

export async function startTracking(onUpdate: (loc: Location.LocationObject) => void): Promise<void> {
  const granted = await requestPermissions();
  if (!granted) throw new Error('Location permission denied');

  onLocationUpdate = onUpdate;

  watchSub = await Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.BestForNavigation,
      timeInterval: 5000,
      distanceInterval: 10, // meters
    },
    (location) => {
      lastLocation = location;
      onLocationUpdate?.(location);
    }
  );
}

export function stopTracking(): void {
  watchSub?.remove();
  watchSub = null;
  if (syncInterval) { clearInterval(syncInterval); syncInterval = null; }
  onLocationUpdate = null;
}

export function getLastLocation(): Location.LocationObject | null {
  return lastLocation;
}

export async function getCurrentLocation(): Promise<Location.LocationObject | null> {
  try {
    return await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
    });
  } catch {
    return lastLocation;
  }
}

export function calculateDistanceMeters(
  lat1: number, lon1: number, lat2: number, lon2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
