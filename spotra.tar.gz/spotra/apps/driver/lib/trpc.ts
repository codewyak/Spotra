import { createTRPCReact } from '@trpc/react-query';
import type { AppRouter } from '@spotra/api/src/root';

export const trpc = createTRPCReact<AppRouter>();
