import { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, TextInput,
  Alert, Platform, ActivityIndicator, ScrollView,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { trpc } from '../../lib/trpc';

export default function DropoffScreen() {
  const { jobId, lotId } = useLocalSearchParams<{ jobId: string; lotId: string }>();
  const [bayLabel, setBayLabel] = useState('');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);

  const getUploadUrl = trpc.tow.getUploadUrl.useMutation();
  const confirmDropoff = trpc.tow.confirmDropoff.useMutation({
    onSuccess: () => {
      Alert.alert('Job Complete!', 'Drop-off confirmed. The vehicle owner can now pay online.', [
        { text: 'OK', onPress: () => router.replace('/tabs') },
      ]);
    },
    onError: err => Alert.alert('Error', err.message),
  });

  async function captureDropoffPhoto() {
    if (photos.length >= 3) return;
    setIsCapturing(true);
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];

      let url = asset.uri;
      try {
        const ext = asset.mimeType?.split('/')[1] ?? 'jpg';
        const { uploadUrl, publicUrl } = await getUploadUrl.mutateAsync({
          jobId: jobId!,
          fileName: `dropoff-${Date.now()}.${ext}`,
          contentType: (asset.mimeType ?? 'image/jpeg') as 'image/jpeg' | 'image/png' | 'image/webp' | 'image/heic',
          angle: 'OTHER',
        });
        const blob = await (await fetch(asset.uri)).blob();
        await fetch(uploadUrl, { method: 'PUT', body: blob, headers: { 'Content-Type': asset.mimeType ?? 'image/jpeg' } });
        url = publicUrl;
      } catch {
        // Use local URI if upload fails
      }
      setPhotos(prev => [...prev, url]);
    } finally {
      setIsCapturing(false);
    }
  }

  function handleSubmit() {
    if (photos.length < 1) {
      Alert.alert('Photo Required', 'Take at least 1 photo confirming the vehicle is at the yard.');
      return;
    }
    confirmDropoff.mutate({
      jobId: jobId!,
      lotId: lotId!,
      bayLabel: bayLabel.trim() || undefined,
      dropoffPhotoUrls: photos,
      notes: notes.trim() || undefined,
    });
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Confirm Drop-off</Text>
        <View style={{ width: 60 }} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        <View style={styles.infoCard}>
          <Text style={styles.infoText}>
            📋  Take at least 1 photo of the vehicle parked in the yard. This starts the storage clock for fee calculation.
          </Text>
        </View>

        {/* Bay number */}
        <View style={styles.field}>
          <Text style={styles.label}>Bay / Spot number (optional)</Text>
          <TextInput
            style={styles.input}
            value={bayLabel}
            onChangeText={setBayLabel}
            placeholder="e.g. A-14"
            placeholderTextColor="#4B5563"
            autoCapitalize="characters"
          />
        </View>

        {/* Drop-off photos */}
        <View style={styles.field}>
          <Text style={styles.label}>Drop-off photos * ({photos.length}/3)</Text>
          <View style={styles.photoGrid}>
            {photos.map((uri, i) => (
              <View key={i} style={styles.photoBox}>
                <Text style={styles.photoCheckmark}>✅</Text>
                <Text style={styles.photoLabel}>Photo {i + 1}</Text>
              </View>
            ))}
            {photos.length < 3 && (
              <TouchableOpacity
                style={styles.addPhotoBtn}
                onPress={captureDropoffPhoto}
                disabled={isCapturing}
                activeOpacity={0.8}
              >
                {isCapturing
                  ? <ActivityIndicator color="#60A5FA" />
                  : <Text style={styles.addPhotoText}>{photos.length === 0 ? '📷\nTake Photo' : '📷\nAdd More'}</Text>}
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Notes */}
        <View style={styles.field}>
          <Text style={styles.label}>Notes (optional)</Text>
          <TextInput
            style={[styles.input, styles.textarea]}
            value={notes}
            onChangeText={setNotes}
            placeholder="Any damage, special conditions…"
            placeholderTextColor="#4B5563"
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.submitBtn, (photos.length < 1 || confirmDropoff.isPending) && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={photos.length < 1 || confirmDropoff.isPending}
          activeOpacity={0.85}
        >
          {confirmDropoff.isPending
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.submitText}>✅  Complete Job</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: Platform.OS === 'ios' ? 54 : 20, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#1F2937' },
  backBtn: { padding: 4, width: 60 },
  backText: { color: '#60A5FA', fontSize: 15 },
  title: { fontSize: 16, fontWeight: '700', color: '#F9FAFB' },
  scroll: { flex: 1 },
  content: { padding: 20, gap: 20, paddingBottom: 32 },
  infoCard: { backgroundColor: '#1E3A5F', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#2563EB' },
  infoText: { color: '#93C5FD', fontSize: 14, lineHeight: 22 },
  field: { gap: 8 },
  label: { fontSize: 11, fontWeight: '600', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 0.8 },
  input: { backgroundColor: '#111827', borderWidth: 1, borderColor: '#374151', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: '#F3F4F6' },
  textarea: { height: 90, paddingTop: 12 },
  photoGrid: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  photoBox: { width: 80, height: 80, backgroundColor: '#052e16', borderRadius: 10, borderWidth: 1, borderColor: '#16a34a', alignItems: 'center', justifyContent: 'center', gap: 4 },
  photoCheckmark: { fontSize: 24 },
  photoLabel: { fontSize: 10, color: '#4ade80' },
  addPhotoBtn: { width: 80, height: 80, backgroundColor: '#111827', borderRadius: 10, borderWidth: 1.5, borderColor: '#374151', borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center' },
  addPhotoText: { fontSize: 11, color: '#6B7280', textAlign: 'center', lineHeight: 18 },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#1F2937', paddingBottom: Platform.OS === 'ios' ? 32 : 16 },
  submitBtn: { backgroundColor: '#16a34a', borderRadius: 14, paddingVertical: 18, alignItems: 'center' },
  submitBtnDisabled: { backgroundColor: '#1F2937', opacity: 0.5 },
  submitText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
