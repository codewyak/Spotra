import { useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Alert, Platform, Image, ActivityIndicator, Dimensions,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { trpc } from '../../lib/trpc';
import { MIN_EVIDENCE_PHOTOS } from '@spotra/shared';
import { enqueue } from '../../services/offline-queue';

const ANGLES = [
  { id: 'FRONT', label: 'Front of vehicle', icon: '🚗', required: true },
  { id: 'REAR', label: 'Rear of vehicle', icon: '🚙', required: true },
  { id: 'PLATE', label: 'License plate', icon: '🔢', required: true },
  { id: 'VIOLATION', label: 'Violation area', icon: '⚠️', required: true },
];

const { width: SCREEN_W } = Dimensions.get('window');

export default function EvidenceScreen() {
  const { jobId } = useLocalSearchParams<{ jobId: string }>();
  const [photos, setPhotos] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCapturing, setIsCapturing] = useState<string | null>(null);

  const getUploadUrl = trpc.tow.getUploadUrl.useMutation();
  const addEvidence = trpc.tow.addEvidence.useMutation();
  const updateStatus = trpc.tow.updateStatus.useMutation();

  const capturedAngles = Object.keys(photos);
  const requiredCaptured = ANGLES.filter(a => a.required && photos[a.id]).length;
  const canProceed = requiredCaptured >= MIN_EVIDENCE_PHOTOS;

  async function capturePhoto(angle: typeof ANGLES[number]) {
    setIsCapturing(angle.id);
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.85,
        allowsEditing: false,
        base64: false,
        exif: true,
      });

      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];

      // Try to upload to R2; fall back to local URI for offline
      let finalUrl = asset.uri;
      try {
        const ext = asset.mimeType?.split('/')[1] ?? 'jpg';
        const { uploadUrl, publicUrl } = await getUploadUrl.mutateAsync({
          jobId: jobId!,
          fileName: `${angle.id.toLowerCase()}.${ext}`,
          contentType: (asset.mimeType ?? 'image/jpeg') as 'image/jpeg' | 'image/png' | 'image/webp' | 'image/heic',
          angle: angle.id as 'FRONT' | 'REAR' | 'PLATE' | 'VIOLATION' | 'INTERIOR' | 'OTHER',
        });

        const file = await fetch(asset.uri);
        const blob = await file.blob();
        await fetch(uploadUrl, { method: 'PUT', body: blob, headers: { 'Content-Type': asset.mimeType ?? 'image/jpeg' } });
        finalUrl = publicUrl;
      } catch {
        // Offline: queue the upload
        await enqueue('evidence_upload', { jobId, angle: angle.id, localUri: asset.uri });
      }

      setPhotos(prev => ({ ...prev, [angle.id]: finalUrl }));
    } catch (err) {
      Alert.alert('Camera Error', 'Could not capture photo. Please try again.');
    } finally {
      setIsCapturing(null);
    }
  }

  async function handleSubmitEvidence() {
    if (!canProceed) {
      Alert.alert('More Photos Required', `You need at least ${MIN_EVIDENCE_PHOTOS} photos to proceed. Capture all 4 required angles.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const photoUrls = Object.values(photos);
      await addEvidence.mutateAsync({ jobId: jobId!, photoUrls });

      // Transition to TOWING
      await updateStatus.mutateAsync({ jobId: jobId!, status: 'TOWING' });
      router.replace(`/job/timer?jobId=${jobId}`);
    } catch (err: any) {
      Alert.alert('Error', err.message ?? 'Failed to submit evidence');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Evidence Photos</Text>
        <View style={styles.counter}>
          <Text style={styles.counterText}>{requiredCaptured}/{MIN_EVIDENCE_PHOTOS}</Text>
        </View>
      </View>

      {/* Progress bar */}
      <View style={styles.progressBg}>
        <View style={[styles.progressFill, { width: `${(requiredCaptured / MIN_EVIDENCE_PHOTOS) * 100}%` }]} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.instruction}>
          Capture all 4 required angles before proceeding. Photos are automatically uploaded as evidence.
        </Text>

        {ANGLES.map(angle => {
          const captured = photos[angle.id];
          const isLoading = isCapturing === angle.id;
          return (
            <TouchableOpacity
              key={angle.id}
              style={[styles.angleCard, captured && styles.angleCardDone, isLoading && styles.angleCardLoading]}
              onPress={() => capturePhoto(angle)}
              activeOpacity={0.8}
              disabled={isLoading || isSubmitting}
            >
              {captured ? (
                <Image source={{ uri: captured }} style={styles.capturedImage} resizeMode="cover" />
              ) : null}
              <View style={[styles.angleOverlay, captured && styles.angleOverlayDone]}>
                <Text style={styles.angleIcon}>{isLoading ? '📷' : captured ? '✅' : angle.icon}</Text>
                <View style={styles.angleTextGroup}>
                  <Text style={[styles.angleLabel, captured && styles.angleLabelDone]}>{angle.label}</Text>
                  <Text style={styles.angleHint}>
                    {isLoading ? 'Opening camera…' : captured ? 'Tap to retake' : 'Tap to capture'}
                  </Text>
                </View>
                {isLoading && <ActivityIndicator color="#60A5FA" size="small" />}
                {!captured && !isLoading && (
                  <View style={styles.captureBtn}>
                    <Text style={styles.captureBtnText}>Capture</Text>
                  </View>
                )}
              </View>
            </TouchableOpacity>
          );
        })}

        {/* AI notice */}
        <View style={styles.aiNotice}>
          <Text style={styles.aiIcon}>🤖</Text>
          <Text style={styles.aiText}>AI will automatically check evidence quality and extract the plate number.</Text>
        </View>
      </ScrollView>

      {/* Submit button */}
      <View style={styles.footer}>
        {!canProceed && (
          <Text style={styles.footerHint}>Capture all {MIN_EVIDENCE_PHOTOS} required photos to continue</Text>
        )}
        <TouchableOpacity
          style={[styles.submitBtn, !canProceed && styles.submitBtnDisabled]}
          onPress={handleSubmitEvidence}
          disabled={!canProceed || isSubmitting}
          activeOpacity={0.85}
        >
          {isSubmitting
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.submitBtnText}>Start Tow Timer →</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: Platform.OS === 'ios' ? 54 : 20, paddingBottom: 12 },
  backBtn: { padding: 4 },
  backText: { color: '#60A5FA', fontSize: 15 },
  title: { fontSize: 16, fontWeight: '700', color: '#F9FAFB' },
  counter: { backgroundColor: '#1F2937', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  counterText: { fontSize: 13, fontWeight: '700', color: '#F9FAFB' },
  progressBg: { height: 3, backgroundColor: '#1F2937', marginHorizontal: 16, borderRadius: 2 },
  progressFill: { height: '100%', backgroundColor: '#2563EB', borderRadius: 2 },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 12, paddingBottom: 24 },
  instruction: { fontSize: 13, color: '#6B7280', lineHeight: 20, marginBottom: 4 },
  angleCard: {
    borderRadius: 14, overflow: 'hidden', height: 100,
    backgroundColor: '#111827', borderWidth: 1.5, borderColor: '#374151',
    justifyContent: 'flex-end',
  },
  angleCardDone: { borderColor: '#16a34a' },
  angleCardLoading: { borderColor: '#2563EB', opacity: 0.8 },
  capturedImage: { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%' },
  angleOverlay: {
    flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14,
    backgroundColor: 'rgba(17,24,39,0.95)',
  },
  angleOverlayDone: { backgroundColor: 'rgba(5,46,22,0.92)' },
  angleIcon: { fontSize: 24 },
  angleTextGroup: { flex: 1 },
  angleLabel: { fontSize: 15, fontWeight: '600', color: '#F9FAFB' },
  angleLabelDone: { color: '#4ade80' },
  angleHint: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  captureBtn: { backgroundColor: '#2563EB', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  captureBtnText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  aiNotice: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', backgroundColor: '#111827', borderRadius: 10, padding: 12, borderWidth: 1, borderColor: '#1F2937' },
  aiIcon: { fontSize: 16 },
  aiText: { flex: 1, fontSize: 12, color: '#6B7280', lineHeight: 18 },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#1F2937', gap: 8, paddingBottom: Platform.OS === 'ios' ? 32 : 16 },
  footerHint: { fontSize: 12, color: '#6B7280', textAlign: 'center' },
  submitBtn: { backgroundColor: '#2563EB', borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  submitBtnDisabled: { backgroundColor: '#1F2937', opacity: 0.6 },
  submitBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
