import { useEffect, useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  Alert, Platform, ActivityIndicator, Vibration,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { trpc } from '../../lib/trpc';

export default function TimerScreen() {
  const { jobId } = useLocalSearchParams<{ jobId: string }>();
  const [elapsed, setElapsed] = useState(0);
  const [startTime] = useState(Date.now());
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const job = trpc.tow.get.useQuery({ id: jobId! });
  const utils = trpc.useUtils();

  useEffect(() => {
    // Start elapsed timer
    intervalRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [startTime]);

  const confirmDropoff = trpc.tow.confirmDropoff.useMutation({
    onSuccess: () => {
      utils.driver.getMyJob.invalidate();
      router.replace('/tabs');
    },
    onError: err => Alert.alert('Error', err.message),
  });

  function formatElapsed(secs: number): string {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  function handleCompleteDropoff() {
    const jobData = job.data as any;
    const lots = jobData?.impoundLot ? [jobData.impoundLot] : [];
    const lotId = lots[0]?.id;

    if (!lotId) {
      Alert.alert('Select Impound Lot', 'No lot configured. Contact dispatch.', [
        { text: 'OK' }
      ]);
      return;
    }

    Alert.alert(
      'Complete Drop-off?',
      'This will mark the vehicle as arrived at the impound yard and start the storage clock.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm Drop-off',
          onPress: () => {
            Vibration.vibrate(100);
            router.push(`/job/dropoff?jobId=${jobId}&lotId=${lotId}`);
          },
        },
      ]
    );
  }

  const jobData = job.data as any;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Tow in Progress</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.body}>
        {/* Timer display */}
        <View style={styles.timerContainer}>
          <Text style={styles.timerLabel}>ELAPSED TIME</Text>
          <Text style={styles.timerDisplay}>{formatElapsed(elapsed)}</Text>
          <View style={styles.timerPulse}>
            <View style={styles.timerPulseDot} />
            <Text style={styles.timerPulseText}>Tow in progress</Text>
          </View>
        </View>

        {/* Job summary */}
        {jobData && (
          <View style={styles.summaryCard}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Vehicle</Text>
              <Text style={styles.summaryValue}>{jobData.vehicle?.plate}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Destination</Text>
              <Text style={styles.summaryValue}>{jobData.impoundLot?.name ?? 'Main Yard'}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Lot address</Text>
              <Text style={[styles.summaryValue, { flex: 1, textAlign: 'right' }]} numberOfLines={2}>
                {jobData.impoundLot?.address ?? 'See dispatch'}
              </Text>
            </View>
          </View>
        )}

        <Text style={styles.instruction}>
          Drive to the impound yard. Tap "Arrived at Yard" when the vehicle has been safely parked.
        </Text>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.completeBtn}
          onPress={handleCompleteDropoff}
          activeOpacity={0.85}
          disabled={confirmDropoff.isPending}
        >
          {confirmDropoff.isPending
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.completeBtnText}>🏁  Arrived at Yard</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: Platform.OS === 'ios' ? 54 : 20, paddingBottom: 12 },
  backBtn: { padding: 4, width: 60 },
  backText: { color: '#60A5FA', fontSize: 15 },
  title: { fontSize: 16, fontWeight: '700', color: '#F9FAFB' },
  body: { flex: 1, paddingHorizontal: 24, justifyContent: 'center', gap: 24 },
  timerContainer: { alignItems: 'center', gap: 8 },
  timerLabel: { fontSize: 11, fontWeight: '700', color: '#6B7280', letterSpacing: 2, textTransform: 'uppercase' },
  timerDisplay: {
    fontSize: 72, fontWeight: '800', color: '#F9FAFB',
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    letterSpacing: 4,
  },
  timerPulse: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  timerPulseDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#EA580C' },
  timerPulseText: { color: '#EA580C', fontSize: 13, fontWeight: '600' },
  summaryCard: { backgroundColor: '#111827', borderRadius: 14, padding: 16, gap: 12, borderWidth: 1, borderColor: '#1F2937' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  summaryLabel: { fontSize: 13, color: '#6B7280' },
  summaryValue: { fontSize: 13, color: '#F9FAFB', fontWeight: '600' },
  instruction: { fontSize: 14, color: '#6B7280', textAlign: 'center', lineHeight: 22 },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#1F2937', paddingBottom: Platform.OS === 'ios' ? 32 : 16 },
  completeBtn: { backgroundColor: '#16a34a', borderRadius: 14, paddingVertical: 18, alignItems: 'center' },
  completeBtnText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
