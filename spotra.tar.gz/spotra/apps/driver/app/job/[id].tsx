import { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Linking, Alert, Platform, ActivityIndicator,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { trpc } from '../../lib/trpc';
import { calculateDistanceMeters } from '../../services/location';
import * as Location from 'expo-location';

const STATUS_COLORS: Record<string, string> = {
  DISPATCHED: '#2563EB',
  EN_ROUTE: '#2563EB',
  ARRIVED: '#7C3AED',
  TOWING: '#EA580C',
  COMPLETED: '#16a34a',
};

export default function JobDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [distance, setDistance] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const job = trpc.tow.get.useQuery({ id: id! }, { refetchInterval: 15000 });
  const declineMutation = trpc.driver.declineJob.useMutation({
    onSuccess: () => { router.replace('/tabs'); },
    onError: err => Alert.alert('Error', err.message),
  });
  const confirmArrival = trpc.driver.confirmArrival.useMutation({
    onSuccess: () => { utils.tow.get.invalidate(); },
    onError: err => Alert.alert('Error', err.message),
  });
  const updateStatus = trpc.tow.updateStatus.useMutation({
    onSuccess: () => utils.tow.get.invalidate(),
  });

  const jobData = job.data as any;
  const status = jobData?.status;

  // Calculate distance to property
  useEffect(() => {
    if (!jobData?.property?.lat) return;
    Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
      .then(loc => {
        const d = calculateDistanceMeters(
          loc.coords.latitude, loc.coords.longitude,
          jobData.property.lat, jobData.property.lng,
        );
        setDistance(d);
      })
      .catch(() => null);
  }, [jobData?.property?.lat]);

  function openNavigation() {
    if (!jobData?.property) return;
    const addr = encodeURIComponent(`${jobData.property.address}, ${jobData.property.city}`);
    const url = Platform.OS === 'ios'
      ? `maps://?daddr=${addr}`
      : `https://maps.google.com/?daddr=${addr}`;
    Linking.openURL(url);
  }

  async function handleEnRoute() {
    await updateStatus.mutateAsync({ jobId: id!, status: 'EN_ROUTE' });
  }

  async function handleArrived() {
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
    confirmArrival.mutate({
      jobId: id!,
      lat: loc.coords.latitude,
      lng: loc.coords.longitude,
    });
  }

  function handleDecline() {
    Alert.alert('Decline Job?', 'This job will return to the queue.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Decline', style: 'destructive',
        onPress: () => declineMutation.mutate({ jobId: id!, reason: 'Driver declined' }),
      },
    ]);
  }

  if (job.isLoading) return (
    <View style={styles.centered}>
      <ActivityIndicator color="#60A5FA" size="large" />
    </View>
  );

  if (!jobData) return (
    <View style={styles.centered}>
      <Text style={styles.errorText}>Job not found</Text>
      <TouchableOpacity onPress={() => router.back()} style={styles.backLink}>
        <Text style={styles.backLinkText}>← Go back</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Home</Text>
        </TouchableOpacity>
        <View style={[styles.statusBadge, { backgroundColor: STATUS_COLORS[status] + '25' }]}>
          <Text style={[styles.statusText, { color: STATUS_COLORS[status] ?? '#9CA3AF' }]}>
            {status?.replace('_', ' ')}
          </Text>
        </View>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent}>
        {/* Property card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📍 Location</Text>
          <Text style={styles.propertyName}>{jobData.property?.name}</Text>
          <Text style={styles.propertyAddress}>{jobData.property?.address}</Text>
          {jobData.spot && (
            <Text style={styles.spotLabel}>Zone {jobData.spot.zone} · Space {jobData.spot.label}</Text>
          )}
          {distance !== null && (
            <Text style={styles.distanceText}>
              {distance < 1000
                ? `${Math.round(distance)}m away`
                : `${(distance / 1000).toFixed(1)}km away`}
            </Text>
          )}
          <TouchableOpacity style={styles.navBtn} onPress={openNavigation} activeOpacity={0.85}>
            <Text style={styles.navBtnText}>🧭  Open in Maps</Text>
          </TouchableOpacity>
        </View>

        {/* Vehicle card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🚗 Vehicle</Text>
          <Text style={styles.plateText}>{jobData.vehicle?.plate} ({jobData.vehicle?.state})</Text>
          {jobData.vehicle?.make && (
            <Text style={styles.vehicleDetail}>
              {[jobData.vehicle.color, jobData.vehicle.year, jobData.vehicle.make, jobData.vehicle.model].filter(Boolean).join(' ')}
            </Text>
          )}
          <View style={styles.violationTag}>
            <Text style={styles.violationText}>⚠️  {jobData.violationReason}</Text>
          </View>
        </View>

        {/* Request photos */}
        {jobData.requestPhotoUrls?.length > 0 && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>📷 Request Photos ({jobData.requestPhotoUrls.length})</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.photoRow}>
              {jobData.requestPhotoUrls.map((url: string, i: number) => (
                <View key={i} style={styles.photoThumb}>
                  {/* In a real app, use an Image component: <Image source={{ uri: url }} style={styles.photoThumbImg} /> */}
                  <Text style={styles.photoPlaceholder}>Photo {i + 1}</Text>
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Notes */}
        {jobData.notes && (
          <View style={styles.notesCard}>
            <Text style={styles.cardTitle}>📝 Notes</Text>
            <Text style={styles.notesText}>{jobData.notes}</Text>
          </View>
        )}

        {/* Timeline */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⏱ Timeline</Text>
          <TimelineRow label="Requested" time={jobData.createdAt} active />
          {jobData.dispatchedAt && <TimelineRow label="Dispatched" time={jobData.dispatchedAt} active />}
          {jobData.arrivedAt && <TimelineRow label="Arrived" time={jobData.arrivedAt} active />}
          {jobData.towStartedAt && <TimelineRow label="Tow started" time={jobData.towStartedAt} active />}
          {jobData.completedAt && <TimelineRow label="Completed" time={jobData.completedAt} active />}
        </View>
      </ScrollView>

      {/* Action footer */}
      <View style={styles.footer}>
        {status === 'DISPATCHED' && (
          <>
            <TouchableOpacity style={styles.btnPrimary} onPress={handleEnRoute} activeOpacity={0.85} disabled={updateStatus.isPending}>
              {updateStatus.isPending ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>🚗  En Route</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={styles.btnDanger} onPress={handleDecline} activeOpacity={0.85}>
              <Text style={styles.btnDangerText}>Decline</Text>
            </TouchableOpacity>
          </>
        )}
        {status === 'EN_ROUTE' && (
          <TouchableOpacity style={styles.btnPrimary} onPress={handleArrived} activeOpacity={0.85} disabled={confirmArrival.isPending}>
            {confirmArrival.isPending ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnPrimaryText}>📍  Confirm Arrival</Text>}
          </TouchableOpacity>
        )}
        {status === 'ARRIVED' && (
          <TouchableOpacity style={styles.btnPrimary} onPress={() => router.push(`/job/evidence?jobId=${id}`)} activeOpacity={0.85}>
            <Text style={styles.btnPrimaryText}>📷  Capture Evidence</Text>
          </TouchableOpacity>
        )}
        {status === 'TOWING' && (
          <TouchableOpacity style={styles.btnPrimary} onPress={() => router.push(`/job/timer?jobId=${id}`)} activeOpacity={0.85}>
            <Text style={styles.btnPrimaryText}>⏱  View Tow Timer</Text>
          </TouchableOpacity>
        )}
        {status === 'COMPLETED' && (
          <View style={styles.completedBanner}>
            <Text style={styles.completedText}>✅  Job completed — awaiting owner payment</Text>
          </View>
        )}
      </View>
    </View>
  );
}

function TimelineRow({ label, time, active }: { label: string; time: string; active?: boolean }) {
  return (
    <View style={styles.timelineRow}>
      <View style={[styles.timelineDot, active && styles.timelineDotActive]} />
      <Text style={styles.timelineLabel}>{label}</Text>
      <Text style={styles.timelineTime}>{new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  centered: { flex: 1, backgroundColor: '#030712', alignItems: 'center', justifyContent: 'center', gap: 12 },
  errorText: { color: '#F87171', fontSize: 16 },
  backLink: { marginTop: 8 },
  backLinkText: { color: '#60A5FA', fontSize: 14 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: Platform.OS === 'ios' ? 54 : 20, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#1F2937' },
  backBtn: { padding: 4 },
  backText: { color: '#60A5FA', fontSize: 15 },
  statusBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  statusText: { fontSize: 12, fontWeight: '700', letterSpacing: 0.5 },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 12, paddingBottom: 24 },
  card: { backgroundColor: '#111827', borderRadius: 14, padding: 16, gap: 6, borderWidth: 1, borderColor: '#1F2937' },
  notesCard: { backgroundColor: '#111827', borderRadius: 14, padding: 16, gap: 6, borderWidth: 1, borderColor: '#1F2937' },
  cardTitle: { fontSize: 11, fontWeight: '600', color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 4 },
  propertyName: { fontSize: 18, fontWeight: '700', color: '#F9FAFB' },
  propertyAddress: { fontSize: 14, color: '#9CA3AF' },
  spotLabel: { fontSize: 13, color: '#60A5FA', marginTop: 2 },
  distanceText: { fontSize: 13, color: '#4ade80', marginTop: 4 },
  navBtn: { backgroundColor: '#1E3A5F', borderRadius: 10, paddingVertical: 12, alignItems: 'center', marginTop: 8, borderWidth: 1, borderColor: '#2563EB' },
  navBtnText: { color: '#60A5FA', fontSize: 15, fontWeight: '600' },
  plateText: { fontSize: 22, fontWeight: '800', color: '#F9FAFB', fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace', letterSpacing: 3 },
  vehicleDetail: { fontSize: 14, color: '#9CA3AF' },
  violationTag: { backgroundColor: '#431407', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, alignSelf: 'flex-start', marginTop: 4 },
  violationText: { fontSize: 13, color: '#FCA5A5', fontWeight: '600' },
  photoRow: { marginTop: 4 },
  photoThumb: { width: 80, height: 60, backgroundColor: '#1F2937', borderRadius: 8, marginRight: 8, alignItems: 'center', justifyContent: 'center' },
  photoPlaceholder: { fontSize: 10, color: '#6B7280' },
  notesText: { fontSize: 14, color: '#D1D5DB', lineHeight: 20 },
  timelineRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 3 },
  timelineDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#374151' },
  timelineDotActive: { backgroundColor: '#2563EB' },
  timelineLabel: { flex: 1, fontSize: 13, color: '#9CA3AF' },
  timelineTime: { fontSize: 13, color: '#F9FAFB', fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#1F2937', gap: 10, paddingBottom: Platform.OS === 'ios' ? 32 : 16 },
  btnPrimary: { backgroundColor: '#2563EB', borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  btnPrimaryText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  btnDanger: { backgroundColor: '#1F2937', borderRadius: 14, paddingVertical: 14, alignItems: 'center', borderWidth: 1, borderColor: '#374151' },
  btnDangerText: { color: '#F87171', fontSize: 15, fontWeight: '600' },
  completedBanner: { backgroundColor: '#052e16', borderRadius: 12, paddingVertical: 14, paddingHorizontal: 16, borderWidth: 1, borderColor: '#16a34a', alignItems: 'center' },
  completedText: { color: '#4ade80', fontSize: 14, fontWeight: '600' },
});
