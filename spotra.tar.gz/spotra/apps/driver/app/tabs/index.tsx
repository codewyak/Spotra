import { useEffect, useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Alert, AppState, Platform, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { trpc } from '../../lib/trpc';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import { startTracking, stopTracking, getLastLocation } from '../../services/location';
import { initOfflineQueue, syncPendingActions } from '../../services/offline-queue';
import NetInfo from '@react-native-community/netinfo';
import { DRIVER_LOCATION_SYNC_INTERVAL_MS } from '@spotra/shared';

export default function HomeScreen() {
  const [isAvailable, setIsAvailable] = useState(false);
  const [locationGranted, setLocationGranted] = useState(false);
  const syncIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const utils = trpc.useUtils();

  const setAvailabilityMutation = trpc.driver.setAvailability.useMutation();
  const updateLocationMutation = trpc.driver.updateLocation.useMutation();
  const currentJob = trpc.driver.getMyJob.useQuery(undefined, {
    refetchInterval: isAvailable ? 10000 : false,
  });

  useEffect(() => {
    initOfflineQueue();

    // Request notification permissions
    Notifications.requestPermissionsAsync().then(({ status }) => {
      if (status === 'granted') {
        Notifications.getExpoPushTokenAsync({ projectId: process.env.EXPO_PUBLIC_PROJECT_ID })
          .then(({ data: token }) => {
            setAvailabilityMutation.mutate({ isAvailable: false, expoPushToken: token });
          });
      }
    });

    // Listen for incoming job notifications
    const sub = Notifications.addNotificationReceivedListener(notification => {
      const jobId = notification.request.content.data?.jobId;
      if (jobId) utils.driver.getMyJob.invalidate();
    });

    const responseSub = Notifications.addNotificationResponseReceivedListener(response => {
      const jobId = response.notification.request.content.data?.jobId;
      if (jobId) router.push(`/job/${jobId}`);
    });

    // Sync offline queue on reconnect
    const unsubNet = NetInfo.addEventListener(state => {
      if (state.isConnected) {
        syncPendingActions(async (type, payload) => {
          if (type === 'location') {
            await updateLocationMutation.mutateAsync(payload as any);
          }
        });
      }
    });

    return () => {
      sub.remove();
      responseSub.remove();
      unsubNet();
      stopTracking();
      if (syncIntervalRef.current) clearInterval(syncIntervalRef.current);
    };
  }, []);

  async function toggleAvailability() {
    const next = !isAvailable;

    if (next) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Location Required', 'Location access is required to receive job assignments.');
        return;
      }
      setLocationGranted(true);

      // Start GPS tracking
      await startTracking(async (loc) => {
        try {
          await updateLocationMutation.mutateAsync({
            lat: loc.coords.latitude,
            lng: loc.coords.longitude,
            accuracy: loc.coords.accuracy ?? undefined,
            heading: loc.coords.heading ?? undefined,
          });
        } catch {
          // Will sync via offline queue
        }
      });
    } else {
      stopTracking();
    }

    setAvailabilityMutation.mutate({ isAvailable: next });
    setIsAvailable(next);
  }

  const hasActiveJob = currentJob.data && ['DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING'].includes(currentJob.data.status);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Spotra Driver</Text>
          <Text style={styles.headerSub}>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</Text>
        </View>
      </View>

      {/* Availability Toggle */}
      <TouchableOpacity
        style={[styles.availabilityCard, isAvailable ? styles.availableCard : styles.unavailableCard]}
        onPress={toggleAvailability}
        activeOpacity={0.85}
        disabled={setAvailabilityMutation.isPending}
      >
        <View style={styles.availabilityInner}>
          <View>
            <Text style={styles.availabilityStatus}>{isAvailable ? 'Available' : 'Offline'}</Text>
            <Text style={styles.availabilityHint}>
              {isAvailable ? 'You can receive job assignments' : 'Tap to go online'}
            </Text>
          </View>
          <View style={[styles.toggle, isAvailable ? styles.toggleOn : styles.toggleOff]}>
            <View style={[styles.toggleThumb, isAvailable ? styles.toggleThumbOn : styles.toggleThumbOff]} />
          </View>
        </View>
        {isAvailable && locationGranted && (
          <View style={styles.gpsIndicator}>
            <View style={styles.gpsDot} />
            <Text style={styles.gpsText}>GPS active</Text>
          </View>
        )}
      </TouchableOpacity>

      {/* Active Job Card */}
      {currentJob.isLoading ? (
        <View style={styles.loadingCard}><ActivityIndicator color="#60A5FA" /></View>
      ) : hasActiveJob ? (
        <TouchableOpacity
          style={styles.activeJobCard}
          onPress={() => router.push(`/job/${currentJob.data!.id}`)}
          activeOpacity={0.85}
        >
          <View style={styles.activeJobHeader}>
            <View style={styles.activeBadge}><Text style={styles.activeBadgeText}>ACTIVE JOB</Text></View>
            <Text style={styles.activeJobStatus}>{currentJob.data!.status.replace('_', ' ')}</Text>
          </View>
          <Text style={styles.activeJobProperty}>{(currentJob.data as any)?.property?.name}</Text>
          <Text style={styles.activeJobAddress}>{(currentJob.data as any)?.property?.address}</Text>
          <View style={styles.activeJobFooter}>
            <Text style={styles.activeJobPlate}>{(currentJob.data as any)?.vehicle?.plate}</Text>
            <Text style={styles.activeJobViolation}>{currentJob.data!.violationReason}</Text>
          </View>
          <View style={styles.viewJobRow}>
            <Text style={styles.viewJobText}>Tap to view job details →</Text>
          </View>
        </TouchableOpacity>
      ) : isAvailable ? (
        <View style={styles.waitingCard}>
          <Text style={styles.waitingIcon}>🟢</Text>
          <Text style={styles.waitingTitle}>Waiting for assignment</Text>
          <Text style={styles.waitingText}>You'll receive a notification when a job is assigned to you.</Text>
        </View>
      ) : null}

      {/* Today's stats placeholder */}
      <View style={styles.statsRow}>
        <StatBox label="Today's Jobs" value="—" />
        <StatBox label="This Week" value="—" />
        <StatBox label="This Month" value="—" />
      </View>
    </ScrollView>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.statBox}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  content: { padding: 20, gap: 16, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: Platform.OS === 'ios' ? 50 : 20 },
  headerTitle: { fontSize: 22, fontWeight: '700', color: '#F9FAFB', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: '#6B7280', marginTop: 2 },
  availabilityCard: {
    borderRadius: 16, padding: 18, borderWidth: 1.5,
  },
  availableCard: { backgroundColor: '#052e16', borderColor: '#16a34a' },
  unavailableCard: { backgroundColor: '#111827', borderColor: '#374151' },
  availabilityInner: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  availabilityStatus: { fontSize: 20, fontWeight: '700', color: '#F9FAFB' },
  availabilityHint: { fontSize: 13, color: '#9CA3AF', marginTop: 3 },
  toggle: { width: 52, height: 30, borderRadius: 15, justifyContent: 'center', padding: 2 },
  toggleOn: { backgroundColor: '#16a34a' },
  toggleOff: { backgroundColor: '#374151' },
  toggleThumb: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#fff' },
  toggleThumbOn: { marginLeft: 22 },
  toggleThumbOff: { marginLeft: 0 },
  gpsIndicator: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10 },
  gpsDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#4ade80' },
  gpsText: { fontSize: 12, color: '#4ade80' },
  activeJobCard: { backgroundColor: '#1e3a5f', borderRadius: 16, padding: 16, borderWidth: 1.5, borderColor: '#2563EB', gap: 6 },
  activeJobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  activeBadge: { backgroundColor: '#2563EB', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  activeBadgeText: { fontSize: 10, fontWeight: '700', color: '#fff', letterSpacing: 0.8 },
  activeJobStatus: { fontSize: 12, color: '#93C5FD', fontWeight: '600' },
  activeJobProperty: { fontSize: 18, fontWeight: '700', color: '#F9FAFB' },
  activeJobAddress: { fontSize: 13, color: '#93C5FD' },
  activeJobFooter: { flexDirection: 'row', gap: 8, marginTop: 4 },
  activeJobPlate: { fontSize: 13, color: '#F9FAFB', fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace', backgroundColor: '#0F172A', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  activeJobViolation: { fontSize: 13, color: '#9CA3AF', flex: 1 },
  viewJobRow: { borderTopWidth: 1, borderTopColor: '#1e40af', marginTop: 8, paddingTop: 10 },
  viewJobText: { fontSize: 13, color: '#60A5FA', textAlign: 'center' },
  waitingCard: { backgroundColor: '#111827', borderRadius: 16, padding: 24, alignItems: 'center', gap: 8, borderWidth: 1, borderColor: '#1F2937' },
  waitingIcon: { fontSize: 32 },
  waitingTitle: { fontSize: 16, fontWeight: '600', color: '#F9FAFB' },
  waitingText: { fontSize: 13, color: '#6B7280', textAlign: 'center', lineHeight: 20 },
  loadingCard: { backgroundColor: '#111827', borderRadius: 16, padding: 32, alignItems: 'center', borderWidth: 1, borderColor: '#1F2937' },
  statsRow: { flexDirection: 'row', gap: 10 },
  statBox: { flex: 1, backgroundColor: '#111827', borderRadius: 12, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: '#1F2937' },
  statValue: { fontSize: 22, fontWeight: '700', color: '#F9FAFB' },
  statLabel: { fontSize: 11, color: '#6B7280', marginTop: 3, textAlign: 'center' },
});
