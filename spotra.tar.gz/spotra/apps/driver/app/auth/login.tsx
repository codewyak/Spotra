import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, Alert, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { trpc } from '../../lib/trpc';
import { storeTokens } from '../../services/auth.service';
import * as Notifications from 'expo-notifications';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async (data) => {
      await storeTokens(data.accessToken, data.refreshToken);

      if (data.user.role !== 'DRIVER') {
        Alert.alert('Access Denied', 'This app is for drivers only.');
        return;
      }

      // Register push token
      const { status } = await Notifications.requestPermissionsAsync();
      if (status === 'granted') {
        const { data: pushToken } = await Notifications.getExpoPushTokenAsync({
          projectId: process.env.EXPO_PUBLIC_PROJECT_ID,
        });
        // Register push token with backend
        // This happens in the tabs home screen after login
      }

      router.replace('/tabs');
    },
    onError: (err) => {
      Alert.alert('Login Failed', err.message);
    },
  });

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.inner}>
        {/* Logo */}
        <View style={styles.logoContainer}>
          <View style={styles.logoBox}>
            <Text style={styles.logoIcon}>⚡</Text>
          </View>
          <Text style={styles.logoText}>Spotra Driver</Text>
          <Text style={styles.logoSub}>Towing operations app</Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="driver@company.com"
              placeholderTextColor="#6B7280"
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Password</Text>
            <View style={styles.pwContainer}>
              <TextInput
                style={[styles.input, { flex: 1 }]}
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                placeholderTextColor="#6B7280"
                secureTextEntry={!showPw}
                autoCapitalize="none"
              />
              <TouchableOpacity onPress={() => setShowPw(p => !p)} style={styles.pwToggle}>
                <Text style={styles.pwToggleText}>{showPw ? 'Hide' : 'Show'}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity
            style={[styles.btn, (!email || !password || loginMutation.isPending) && styles.btnDisabled]}
            onPress={() => loginMutation.mutate({ email, password })}
            disabled={!email || !password || loginMutation.isPending}
            activeOpacity={0.8}
          >
            {loginMutation.isPending
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.btnText}>Sign In</Text>}
          </TouchableOpacity>
        </View>

        {/* Demo */}
        <View style={styles.demo}>
          <Text style={styles.demoTitle}>Demo login</Text>
          <Text style={styles.demoText}>driver1@bostontowco.com</Text>
          <Text style={styles.demoText}>Password123!</Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#030712' },
  inner: { flex: 1, justifyContent: 'center', paddingHorizontal: 24, paddingBottom: 40 },
  logoContainer: { alignItems: 'center', marginBottom: 40 },
  logoBox: { width: 64, height: 64, backgroundColor: '#2563EB', borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  logoIcon: { fontSize: 28 },
  logoText: { fontSize: 26, fontWeight: '700', color: '#F9FAFB', letterSpacing: -0.5 },
  logoSub: { fontSize: 14, color: '#6B7280', marginTop: 4 },
  form: { gap: 16 },
  fieldGroup: { gap: 6 },
  label: { fontSize: 11, fontWeight: '600', color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 0.8 },
  input: {
    backgroundColor: '#111827', borderWidth: 1, borderColor: '#374151',
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 13,
    fontSize: 15, color: '#F3F4F6',
  },
  pwContainer: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pwToggle: { paddingHorizontal: 12, paddingVertical: 13, backgroundColor: '#111827', borderWidth: 1, borderColor: '#374151', borderRadius: 10 },
  pwToggleText: { fontSize: 13, color: '#60A5FA' },
  btn: {
    backgroundColor: '#2563EB', paddingVertical: 15, borderRadius: 12,
    alignItems: 'center', marginTop: 8,
  },
  btnDisabled: { opacity: 0.5 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  demo: { marginTop: 32, padding: 14, backgroundColor: '#111827', borderRadius: 10, gap: 3 },
  demoTitle: { fontSize: 11, color: '#6B7280', fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 2 },
  demoText: { fontSize: 13, color: '#9CA3AF', fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
});
