import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  transpilePackages: ['@spotra/shared', '@spotra/db'],
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client', 'bcryptjs'],
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '*.r2.cloudflarestorage.com' },
      { protocol: 'https', hostname: '*.spotra.com' },
      { protocol: 'https', hostname: 'picsum.photos' },
    ],
  },
  async rewrites() {
    // In development, proxy API calls to Express server
    if (process.env.NODE_ENV === 'development') {
      return [
        { source: '/api/trpc/:path*', destination: 'http://localhost:3001/api/trpc/:path*' },
        { source: '/api/v1/:path*', destination: 'http://localhost:3001/api/v1/:path*' },
      ];
    }
    return [];
  },
};

export default nextConfig;
