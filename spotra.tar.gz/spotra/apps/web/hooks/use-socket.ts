'use client';
import { useEffect, useState, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './use-auth';

export function useSocket() {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!user?.companyId && !user?.propertyId) return;

    const token = localStorage.getItem('spotra_access_token');
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_APP_URL ?? '', {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
    });

    socket.on('connect', () => {
      setIsConnected(true);
      // Join tenant room
      if (user.companyId) socket.emit('join:company', user.companyId);
      if (user.propertyId) socket.emit('join:property', user.propertyId);
    });

    socket.on('disconnect', () => setIsConnected(false));
    socket.on('connect_error', () => setIsConnected(false));

    socketRef.current = socket;

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [user?.companyId, user?.propertyId]);

  return { socket: socketRef.current, isConnected };
}
