'use client';
import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import type { AuthUser } from '@spotra/shared';

interface AuthState {
  user: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string; user?: AuthUser }>;
  logout: () => void;
}

const AuthContext = createContext<AuthState>({
  user: null, isLoading: true,
  login: async () => ({ ok: false }),
  logout: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const utils = trpc.useUtils();

  const loginMutation = trpc.auth.login.useMutation();

  // Restore session on mount
  useEffect(() => {
    const token = localStorage.getItem('spotra_access_token');
    if (!token) { setIsLoading(false); return; }

    utils.auth.me.fetch()
      .then(u => setUser(u))
      .catch(() => {
        // Try refresh
        const refresh = localStorage.getItem('spotra_refresh_token');
        if (!refresh) { localStorage.removeItem('spotra_access_token'); setIsLoading(false); return; }

        utils.auth.refresh.fetch({ refreshToken: refresh })
          .then(result => {
            localStorage.setItem('spotra_access_token', result.accessToken);
            localStorage.setItem('spotra_refresh_token', result.refreshToken);
            return utils.auth.me.fetch();
          })
          .then(u => setUser(u))
          .catch(() => {
            localStorage.removeItem('spotra_access_token');
            localStorage.removeItem('spotra_refresh_token');
          })
          .finally(() => setIsLoading(false));
        return;
      })
      .finally(() => setIsLoading(false));
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    try {
      const result = await loginMutation.mutateAsync({ email, password });
      localStorage.setItem('spotra_access_token', result.accessToken);
      localStorage.setItem('spotra_refresh_token', result.refreshToken);
      setUser(result.user as AuthUser);
      return { ok: true, user: result.user as AuthUser };
    } catch (err: any) {
      return { ok: false, error: err?.message ?? 'Login failed' };
    }
  }, [loginMutation]);

  const logout = useCallback(() => {
    const refresh = localStorage.getItem('spotra_refresh_token');
    if (refresh) {
      utils.auth.logout.fetch({ refreshToken: refresh }).catch(() => null);
    }
    localStorage.removeItem('spotra_access_token');
    localStorage.removeItem('spotra_refresh_token');
    setUser(null);
    window.location.href = '/login';
  }, [utils]);

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
