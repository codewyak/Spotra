'use client';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/hooks/use-auth';
import Link from 'next/link';
import { ClipboardList, Clock, CheckCircle2, AlertTriangle, Plus, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { StatusBadge } from '../(dashboard)/dispatch/page';

export default function PropertyDashboard() {
  const { user } = useAuth();
  const properties = trpc.property.list.useQuery();
  const property = properties.data?.[0]; // Primary property for this manager

  const history = trpc.property.getHistory.useQuery(
    { propertyId: property?.id ?? '', page: 1, limit: 5 },
    { enabled: !!property?.id }
  );

  const stats = property
    ? {
        totalSpots: property.parkingSpots?.length ?? 0,
        recentJobs: history.data?.total ?? 0,
      }
    : null;

  if (properties.isLoading) return <LoadingState />;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-white">{property?.name ?? 'My Property'}</h1>
          <p className="text-sm text-gray-400 mt-0.5">{property?.address}</p>
        </div>
        <Link href="/property/requests" className="btn-primary flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" /> New Tow Request
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Total Spots" value={stats?.totalSpots ?? 0} icon={Clock} color="blue" />
        <StatCard label="Total Requests" value={stats?.recentJobs ?? 0} icon={ClipboardList} color="amber" />
        <StatCard label="Active Now" value={history.data?.items.filter(j => !['COMPLETED','RELEASED','CANCELLED'].includes(j.status)).length ?? 0} icon={AlertTriangle} color="orange" />
      </div>

      {/* Recent requests */}
      <div className="card">
        <div className="px-4 py-3 border-b border-gray-800 flex items-center justify-between">
          <h2 className="text-sm font-medium text-gray-300">Recent Requests</h2>
          <Link href="/property/history" className="text-xs text-blue-400 hover:text-blue-300">View all</Link>
        </div>
        {history.isLoading ? (
          <div className="p-4 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-gray-500" /></div>
        ) : !history.data?.items.length ? (
          <div className="p-8 text-center">
            <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm text-gray-400">No tow requests yet</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-800">
            {history.data.items.map(job => (
              <div key={job.id} className="px-4 py-3 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <StatusBadge status={job.status} />
                    <span className="text-xs text-gray-500 font-mono">#{(job as any).ticketNumber ?? job.id.slice(0,8)}</span>
                  </div>
                  <p className="text-sm text-gray-200">{(job.vehicle as any)?.plate} · {job.violationReason}</p>
                  <p className="text-xs text-gray-500">{formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</p>
                </div>
                {(job as any).payment?.status === 'SUCCEEDED' && (
                  <span className="badge bg-green-500/15 text-green-400 text-xs">Paid</span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: any; color: string }) {
  const colors: Record<string, string> = {
    blue: 'text-blue-400 bg-blue-500/10',
    amber: 'text-amber-400 bg-amber-500/10',
    orange: 'text-orange-400 bg-orange-500/10',
  };
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="label">{label}</p>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <p className="text-2xl font-bold text-white">{value.toLocaleString()}</p>
    </div>
  );
}
function LoadingState() {
  return <div className="p-6 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-gray-500" /></div>;
}
