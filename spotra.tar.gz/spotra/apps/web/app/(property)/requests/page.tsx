'use client';
import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { trpc } from '@/lib/trpc';
import { VIOLATION_REASONS } from '@spotra/shared';
import { Camera, Upload, X, CheckCircle2, Loader2, AlertCircle, MapPin } from 'lucide-react';

type Step = 'location' | 'vehicle' | 'photos' | 'confirm';

export default function NewRequestPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('location');
  const [form, setForm] = useState({
    propertyId: '',
    spotId: '',
    vehiclePlate: '',
    vehicleState: 'MA',
    vehicleMake: '',
    vehicleModel: '',
    vehicleColor: '',
    violationReason: '' as typeof VIOLATION_REASONS[number] | '',
    notes: '',
    photoUrls: [] as string[],
  });
  const [photoFiles, setPhotoFiles] = useState<{ url: string; name: string }[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const properties = trpc.property.list.useQuery();
  const selectedProperty = properties.data?.find(p => p.id === form.propertyId);

  const createMutation = trpc.tow.create.useMutation({
    onSuccess: () => router.push('/property/history'),
    onError: err => setSubmitError(err.message),
  });

  const getUploadUrl = trpc.tow.getUploadUrl.useMutation();

  const handlePhotoAdd = useCallback(async (files: FileList | null) => {
    if (!files || !form.propertyId) return;
    setIsUploading(true);
    const newUrls: string[] = [];

    for (const file of Array.from(files).slice(0, 8 - photoFiles.length)) {
      try {
        const { uploadUrl, publicUrl } = await getUploadUrl.mutateAsync({
          jobId: form.propertyId, // temp key using propertyId
          fileName: file.name,
          contentType: file.type as 'image/jpeg' | 'image/png' | 'image/webp' | 'image/heic',
          angle: 'OTHER',
        });
        await fetch(uploadUrl, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
        newUrls.push(publicUrl);
        setPhotoFiles(prev => [...prev, { url: publicUrl, name: file.name }]);
      } catch {
        // Fallback: use object URL for demo
        const objUrl = URL.createObjectURL(file);
        newUrls.push(objUrl);
        setPhotoFiles(prev => [...prev, { url: objUrl, name: file.name }]);
      }
    }

    setForm(f => ({ ...f, photoUrls: [...f.photoUrls, ...newUrls] }));
    setIsUploading(false);
  }, [form.propertyId, photoFiles.length, getUploadUrl]);

  function removePhoto(idx: number) {
    setPhotoFiles(prev => prev.filter((_, i) => i !== idx));
    setForm(f => ({ ...f, photoUrls: f.photoUrls.filter((_, i) => i !== idx) }));
  }

  async function handleSubmit() {
    if (!form.propertyId || !form.vehiclePlate || !form.violationReason || form.photoUrls.length < 1) {
      setSubmitError('Please complete all required fields and add at least 1 photo.');
      return;
    }
    setSubmitError('');
    createMutation.mutate({
      propertyId: form.propertyId,
      spotId: form.spotId || undefined,
      vehiclePlate: form.vehiclePlate,
      vehicleState: form.vehicleState,
      vehicleMake: form.vehicleMake || undefined,
      vehicleModel: form.vehicleModel || undefined,
      vehicleColor: form.vehicleColor || undefined,
      violationReason: form.violationReason as typeof VIOLATION_REASONS[number],
      photoUrls: form.photoUrls,
      notes: form.notes || undefined,
    });
  }

  const STEPS: { id: Step; label: string }[] = [
    { id: 'location', label: 'Location' },
    { id: 'vehicle', label: 'Vehicle' },
    { id: 'photos', label: 'Photos' },
    { id: 'confirm', label: 'Confirm' },
  ];
  const stepIdx = STEPS.findIndex(s => s.id === step);

  return (
    <div className="p-6 max-w-xl">
      <h1 className="text-xl font-semibold text-white mb-6">New Tow Request</h1>

      {/* Progress */}
      <div className="flex items-center gap-0 mb-8">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex items-center flex-1">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${i < stepIdx ? 'bg-green-600 text-white' : i === stepIdx ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-500'}`}>
              {i < stepIdx ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
            </div>
            <div className="flex-1">
              <p className={`text-xs mt-1 ml-1 ${i === stepIdx ? 'text-gray-300' : 'text-gray-600'}`}>{s.label}</p>
              {i < STEPS.length - 1 && <div className={`h-0.5 mt-2 mx-1 ${i < stepIdx ? 'bg-green-600' : 'bg-gray-800'}`} />}
            </div>
          </div>
        ))}
      </div>

      {/* Step: Location */}
      {step === 'location' && (
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-medium text-gray-300">Where is the vehicle?</h2>
          <div>
            <label className="label mb-1 block">Property *</label>
            <select value={form.propertyId} onChange={e => setForm(f => ({ ...f, propertyId: e.target.value, spotId: '' }))} className="input">
              <option value="">Select property…</option>
              {properties.data?.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          {selectedProperty && (
            <div>
              <label className="label mb-1 block">Parking spot (optional)</label>
              <select value={form.spotId} onChange={e => setForm(f => ({ ...f, spotId: e.target.value }))} className="input">
                <option value="">Select spot…</option>
                {(selectedProperty as any).parkingSpots?.map((s: any) => (
                  <option key={s.id} value={s.id}>Zone {s.zone} · Space {s.label} ({s.spotType})</option>
                ))}
              </select>
            </div>
          )}
          <div>
            <label className="label mb-1 block">Violation reason *</label>
            <select value={form.violationReason} onChange={e => setForm(f => ({ ...f, violationReason: e.target.value as any }))} className="input">
              <option value="">Select violation…</option>
              {VIOLATION_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <button onClick={() => setStep('vehicle')} disabled={!form.propertyId || !form.violationReason} className="btn-primary w-full">Next: Vehicle Info →</button>
        </div>
      )}

      {/* Step: Vehicle */}
      {step === 'vehicle' && (
        <div className="card p-5 space-y-4">
          <h2 className="text-sm font-medium text-gray-300">Vehicle details</h2>
          <div className="flex gap-2">
            <div className="flex-1">
              <label className="label mb-1 block">License plate *</label>
              <input value={form.vehiclePlate} onChange={e => setForm(f => ({ ...f, vehiclePlate: e.target.value.toUpperCase() }))} className="input font-mono tracking-widest" placeholder="7XKA123" />
            </div>
            <div className="w-20">
              <label className="label mb-1 block">State</label>
              <input value={form.vehicleState} onChange={e => setForm(f => ({ ...f, vehicleState: e.target.value.toUpperCase().slice(0, 2) }))} className="input text-center" placeholder="MA" maxLength={2} />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[['vehicleMake', 'Make'], ['vehicleModel', 'Model'], ['vehicleColor', 'Color']].map(([key, label]) => (
              <div key={key}>
                <label className="label mb-1 block">{label}</label>
                <input value={(form as any)[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} className="input" placeholder={label} />
              </div>
            ))}
          </div>
          <div>
            <label className="label mb-1 block">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} className="input min-h-[80px] resize-none" placeholder="Any additional details…" />
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep('location')} className="btn-secondary flex-1">← Back</button>
            <button onClick={() => setStep('photos')} disabled={!form.vehiclePlate} className="btn-primary flex-1">Next: Photos →</button>
          </div>
        </div>
      )}

      {/* Step: Photos */}
      {step === 'photos' && (
        <div className="card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-medium text-gray-300">Upload violation photos</h2>
            <span className="text-xs text-gray-500">{photoFiles.length}/8 photos</span>
          </div>
          <p className="text-xs text-gray-500">Include: front, rear, plate, and the violation (e.g. no permit, wrong spot).</p>

          {/* Photo grid */}
          {photoFiles.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              {photoFiles.map((photo, i) => (
                <div key={i} className="relative aspect-video bg-gray-800 rounded-lg overflow-hidden group">
                  <img src={photo.url} alt={photo.name} className="w-full h-full object-cover" />
                  <button onClick={() => removePhoto(i)} className="absolute top-1 right-1 w-5 h-5 bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Upload area */}
          {photoFiles.length < 8 && (
            <label className="flex flex-col items-center gap-3 p-6 border-2 border-dashed border-gray-700 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-500/5 transition-colors">
              {isUploading ? <Loader2 className="w-8 h-8 text-blue-500 animate-spin" /> : <Camera className="w-8 h-8 text-gray-600" />}
              <div className="text-center">
                <p className="text-sm text-gray-300">{isUploading ? 'Uploading…' : 'Tap to add photos'}</p>
                <p className="text-xs text-gray-500 mt-0.5">JPG, PNG or HEIC · Up to 8 photos</p>
              </div>
              <input type="file" accept="image/*" multiple className="hidden" disabled={isUploading} onChange={e => handlePhotoAdd(e.target.files)} capture="environment" />
            </label>
          )}

          <div className="flex gap-3">
            <button onClick={() => setStep('vehicle')} className="btn-secondary flex-1">← Back</button>
            <button onClick={() => setStep('confirm')} disabled={photoFiles.length < 1} className="btn-primary flex-1">Next: Review →</button>
          </div>
        </div>
      )}

      {/* Step: Confirm */}
      {step === 'confirm' && (
        <div className="space-y-4">
          <div className="card p-4 space-y-3">
            <h2 className="text-sm font-medium text-gray-300">Review & Submit</h2>
            <Row label="Property" value={selectedProperty?.name ?? ''} />
            {form.spotId && <Row label="Spot" value={selectedProperty?.parkingSpots?.find((s: any) => s.id === form.spotId)?.label ?? ''} />}
            <Row label="Violation" value={form.violationReason} />
            <Row label="Plate" value={`${form.vehiclePlate} (${form.vehicleState})`} mono />
            {form.vehicleMake && <Row label="Vehicle" value={`${form.vehicleColor} ${form.vehicleMake} ${form.vehicleModel}`} />}
            {form.notes && <Row label="Notes" value={form.notes} />}
          </div>
          <div className="card p-4">
            <p className="label mb-2">Photos ({photoFiles.length})</p>
            <div className="grid grid-cols-4 gap-1.5">
              {photoFiles.map((p, i) => (
                <img key={i} src={p.url} alt="" className="aspect-square object-cover rounded-lg bg-gray-800" />
              ))}
            </div>
          </div>

          {submitError && (
            <div className="flex items-start gap-2 text-sm text-red-400 bg-red-900/20 rounded-lg p-3 border border-red-900">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{submitError}
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={() => setStep('photos')} className="btn-secondary flex-1">← Back</button>
            <button onClick={handleSubmit} disabled={createMutation.isPending} className="btn-primary flex-1 flex items-center justify-center gap-2">
              {createMutation.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting…</> : 'Submit Request'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-start gap-2 text-sm">
      <span className="text-gray-500 w-20 shrink-0">{label}</span>
      <span className={`text-gray-200 ${mono ? 'font-mono' : ''}`}>{value || '—'}</span>
    </div>
  );
}
