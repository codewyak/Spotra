import { NextRequest, NextResponse } from 'next/server';
import { VehicleLookupSchema } from '@spotra/shared';
import { PrismaClient } from '@prisma/client';
import { FeeService } from '@spotra/api/src/services/fee.service';

const db = new PrismaClient();

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const parse = VehicleLookupSchema.safeParse({
    q: searchParams.get('q'),
    type: searchParams.get('type') ?? 'plate',
    state: searchParams.get('state') ?? 'MA',
  });

  if (!parse.success) {
    return NextResponse.json({ found: false, error: 'Invalid search parameters' }, { status: 400 });
  }

  const { q, type, state } = parse.data;

  try {
    // Find the vehicle + active tow job
    let job = null;

    if (type === 'ticket') {
      job = await db.towJob.findUnique({
        where: { ticketNumber: q },
        include: buildJobInclude(),
      });
    } else if (type === 'plate') {
      const vehicle = await db.vehicle.findUnique({ where: { plate_state: { plate: q, state } } });
      if (vehicle) {
        job = await db.towJob.findFirst({
          where: {
            vehicleId: vehicle.id,
            status: { in: ['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING', 'COMPLETED'] },
          },
          orderBy: { createdAt: 'desc' },
          include: buildJobInclude(),
        });
      }
    } else if (type === 'vin') {
      const vehicle = await db.vehicle.findUnique({ where: { vin: q } });
      if (vehicle) {
        job = await db.towJob.findFirst({
          where: {
            vehicleId: vehicle.id,
            status: { in: ['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING', 'COMPLETED'] },
          },
          orderBy: { createdAt: 'desc' },
          include: buildJobInclude(),
        });
      }
    }

    if (!job) {
      return NextResponse.json({ found: false });
    }

    // Calculate fees if completed
    let fees = null;
    if (job.status === 'COMPLETED' || job.status === 'RELEASED') {
      try {
        const feeService = new FeeService(db);
        const calculated = await feeService.calculateFees(job.id);
        fees = {
          baseTowCents: calculated.baseTowCents,
          storageCents: calculated.storageCents,
          storageDays: calculated.storageDays,
          totalCents: calculated.totalCents,
          calculatedAt: calculated.lockedAt,
        };
      } catch { /* fee calc may fail if job not complete */ }
    }

    return NextResponse.json({
      found: true,
      jobId: job.id,
      ticketNumber: job.ticketNumber,
      status: job.status,
      towedAt: job.towStartedAt ?? job.dispatchedAt ?? job.createdAt,
      completedAt: job.completedAt,
      vehicle: {
        plate: job.vehicle.plate,
        state: job.vehicle.state,
        make: job.vehicle.make,
        model: job.vehicle.model,
        color: job.vehicle.color,
        year: job.vehicle.year,
      },
      company: {
        name: job.company.name,
        phone: job.company.phone,
      },
      impoundLot: job.impoundLot ? {
        name: job.impoundLot.name,
        address: job.impoundLot.address,
        lat: job.impoundLot.lat,
        lng: job.impoundLot.lng,
        phone: job.impoundLot.phone,
        hours: job.impoundLot.hoursJson,
      } : null,
      fees,
      requiresDocuments: ['Valid government-issued photo ID', 'Vehicle registration or proof of ownership'],
      paymentStatus: job.payment?.status ?? null,
    });
  } catch (err) {
    console.error('[vehicle lookup]', err);
    return NextResponse.json({ found: false, error: 'Server error' }, { status: 500 });
  }
}

function buildJobInclude() {
  return {
    vehicle: true,
    company: { select: { name: true, phone: true } },
    impoundLot: { select: { name: true, address: true, lat: true, lng: true, phone: true, hoursJson: true } },
    payment: { select: { status: true, totalCents: true, paidAt: true } },
  };
}
