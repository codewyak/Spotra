'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Zap, Loader2, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const { login, isLoading } = useAuth();
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const result = await login(email, password);
    if (!result.ok) { setError(result.error ?? 'Invalid email or password'); return; }

    const role = result.user?.role;
    if (role === 'PROPERTY_MANAGER' || role === 'PROPERTY_STAFF') router.push('/property');
    else if (role === 'DRIVER') router.push('/driver-redirect'); // handled by mobile app
    else router.push('/dashboard');
  }

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <span className="text-2xl font-bold text-white">Spotra</span>
        </div>

        <div className="card p-6">
          <h1 className="text-lg font-semibold text-white mb-1">Sign in</h1>
          <p className="text-sm text-gray-400 mb-6">Towing operations platform</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label mb-1 block">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input" placeholder="you@company.com" required autoFocus />
            </div>
            <div>
              <label className="label mb-1 block">Password</label>
              <div className="relative">
                <input type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} className="input pr-10" placeholder="••••••••" required />
                <button type="button" onClick={() => setShowPw(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-red-400 bg-red-900/20 rounded-lg p-3 border border-red-900">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <button type="submit" disabled={isLoading || !email || !password} className="btn-primary w-full py-2.5 flex items-center justify-center gap-2">
              {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Signing in…</> : 'Sign in'}
            </button>
          </form>
        </div>

        {/* Demo creds */}
        <div className="mt-4 card p-3 text-xs text-gray-500 space-y-0.5">
          <p className="font-medium text-gray-400 mb-1">Demo accounts (password: Password123!)</p>
          <p>Admin: admin@bostontowco.com</p>
          <p>Dispatcher: dispatch@bostontowco.com</p>
          <p>Property Mgr: manager@harborview.com</p>
        </div>
      </div>
    </div>
  );
}
