'use client';
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { formatDistanceToNow } from 'date-fns';
import { Loader2, Search, Filter, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { JOB_STATUS, VIOLATION_REASONS } from '@spotra/shared';
import { StatusBadge } from '../dispatch/page';

const STATUSES = Object.keys(JOB_STATUS) as (keyof typeof JOB_STATUS)[];

export default function JobsPage() {
  const [status, setStatus] = useState<string>('');
  const [page, setPage] = useState(1);

  const jobs = trpc.tow.list.useQuery({
    status: (status as any) || undefined,
    page,
    limit: 25,
  }, { keepPreviousData: true });

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-white">All Jobs</h1>
        <div className="flex items-center gap-2">
          <select
            value={status}
            onChange={e => { setStatus(e.target.value); setPage(1); }}
            className="input w-40 text-sm"
          >
            <option value="">All statuses</option>
            {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
          </select>
        </div>
      </div>

      <div className="card overflow-hidden">
        {/* Table header */}
        <div className="grid grid-cols-[2fr_1fr_1.5fr_1fr_1fr_auto] gap-4 px-4 py-2.5 border-b border-gray-800 text-xs text-gray-500 uppercase tracking-wider font-medium">
          <span>Property / Vehicle</span>
          <span>Violation</span>
          <span>Driver</span>
          <span>Status</span>
          <span>Created</span>
          <span></span>
        </div>

        {jobs.isLoading ? (
          <div className="p-8 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-gray-500" /></div>
        ) : !jobs.data?.items.length ? (
          <div className="p-8 text-center text-sm text-gray-500">No jobs found</div>
        ) : (
          <div className="divide-y divide-gray-800">
            {jobs.data.items.map((job: any) => (
              <Link
                key={job.id}
                href={`/dashboard/jobs/${job.id}`}
                className="grid grid-cols-[2fr_1fr_1.5fr_1fr_1fr_auto] gap-4 px-4 py-3 hover:bg-gray-800/50 transition-colors items-center group"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-100 truncate">{job.property?.name}</p>
                  <p className="text-xs text-gray-500 font-mono">{job.vehicle?.plate} · {job.vehicle?.state}</p>
                </div>
                <div className="min-w-0">
                  <p className="text-xs text-gray-400 truncate">{job.violationReason}</p>
                </div>
                <div className="min-w-0">
                  {job.driver
                    ? <p className="text-xs text-gray-300 truncate">{job.driver.user?.firstName} {job.driver.user?.lastName}</p>
                    : <p className="text-xs text-gray-600">Unassigned</p>}
                </div>
                <div><StatusBadge status={job.status} /></div>
                <div>
                  <p className="text-xs text-gray-500">{formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition-colors" />
              </Link>
            ))}
          </div>
        )}

        {/* Pagination */}
        {jobs.data && jobs.data.total > 25 && (
          <div className="px-4 py-3 border-t border-gray-800 flex items-center justify-between text-sm text-gray-400">
            <span>{jobs.data.total} total jobs</span>
            <div className="flex items-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary py-1 px-3 text-xs disabled:opacity-40">
                ← Prev
              </button>
              <span>Page {page}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={!jobs.data?.hasMore} className="btn-secondary py-1 px-3 text-xs disabled:opacity-40">
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
