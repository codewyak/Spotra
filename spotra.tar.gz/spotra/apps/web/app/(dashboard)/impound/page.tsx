'use client';
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { formatDistanceToNow, differenceInDays } from 'date-fns';
import { Warehouse, Loader2, CheckCircle2, Clock, DollarSign, AlertTriangle } from 'lucide-react';
import { formatCents } from '@/lib/utils';

export default function ImpoundPage() {
  const [selectedLotId, setSelectedLotId] = useState<string>('');
  const utils = trpc.useUtils();

  const lots = trpc.impound.getLots.useQuery();
  const activeLotId = selectedLotId || lots.data?.[0]?.id || '';

  const inventory = trpc.impound.getInventory.useQuery(
    { lotId: activeLotId },
    { enabled: !!activeLotId, refetchInterval: 30000 }
  );

  const releaseMutation = trpc.impound.releaseVehicle.useMutation({
    onSuccess: () => {
      utils.impound.getInventory.invalidate();
      utils.impound.getLots.invalidate();
    },
  });

  const activeLot = lots.data?.find(l => l.id === activeLotId);

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-white">Impound Inventory</h1>
        {lots.data && lots.data.length > 1 && (
          <select value={activeLotId} onChange={e => setSelectedLotId(e.target.value)} className="input w-48 text-sm">
            {lots.data.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        )}
      </div>

      {/* Lot stats */}
      {activeLot && (
        <div className="grid grid-cols-3 gap-4">
          <LotStat label="Capacity" value={`${activeLot.currentCount} / ${activeLot.capacity}`} icon={Warehouse} />
          <LotStat label="Occupancy" value={`${Math.round((activeLot.currentCount / activeLot.capacity) * 100)}%`} icon={Clock} color={activeLot.currentCount / activeLot.capacity > 0.8 ? 'red' : 'blue'} />
          <LotStat label="Address" value={activeLot.address} icon={Warehouse} small />
        </div>
      )}

      {/* Inventory table */}
      <div className="card overflow-hidden">
        <div className="grid grid-cols-[1.5fr_1fr_1fr_1fr_1fr_auto] gap-4 px-4 py-2.5 border-b border-gray-800 text-xs text-gray-500 uppercase tracking-wider font-medium">
          <span>Vehicle</span>
          <span>Bay</span>
          <span>Storage</span>
          <span>Fees</span>
          <span>Payment</span>
          <span>Action</span>
        </div>

        {inventory.isLoading ? (
          <div className="p-8 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-gray-500" /></div>
        ) : !inventory.data?.length ? (
          <div className="p-8 text-center">
            <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Lot is empty</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-800">
            {inventory.data.map((record: any) => {
              const storageStart = new Date(record.storageStartAt);
              const days = differenceInDays(new Date(), storageStart);
              const isPaid = record.job?.payment?.status === 'SUCCEEDED';
              const storageCents = days * 4500;
              const totalCents = (record.job?.payment?.totalCents ?? (15000 + storageCents));

              return (
                <div key={record.id} className="grid grid-cols-[1.5fr_1fr_1fr_1fr_1fr_auto] gap-4 px-4 py-3 items-center">
                  <div>
                    <p className="text-sm font-medium text-gray-100 font-mono">{record.job?.vehicle?.plate}</p>
                    <p className="text-xs text-gray-500">
                      {[record.job?.vehicle?.color, record.job?.vehicle?.make, record.job?.vehicle?.model].filter(Boolean).join(' ') || '—'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-300">{record.bayLabel || <span className="text-gray-600">Unassigned</span>}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-300">{days} day{days !== 1 ? 's' : ''}</p>
                    <p className="text-xs text-gray-500">{formatDistanceToNow(storageStart, { addSuffix: true })}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-300">{formatCents(totalCents)}</p>
                    {days > 7 && <p className="text-xs text-amber-400 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Long storage</p>}
                  </div>
                  <div>
                    {isPaid
                      ? <span className="badge bg-green-500/15 text-green-400">Paid</span>
                      : <span className="badge bg-amber-500/15 text-amber-400">Unpaid</span>}
                  </div>
                  <div>
                    {isPaid ? (
                      <button
                        onClick={() => releaseMutation.mutate({ jobId: record.jobId })}
                        disabled={releaseMutation.isPending}
                        className="btn-primary text-xs py-1.5 px-3"
                      >
                        Release
                      </button>
                    ) : (
                      <span className="text-xs text-gray-600">Awaiting payment</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function LotStat({ label, value, icon: Icon, color = 'blue', small = false }: any) {
  const colors: Record<string, string> = {
    blue: 'text-blue-400 bg-blue-500/10',
    red: 'text-red-400 bg-red-500/10',
  };
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="label">{label}</p>
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-3.5 h-3.5" />
        </div>
      </div>
      <p className={`font-bold text-white ${small ? 'text-sm' : 'text-xl'}`}>{value}</p>
    </div>
  );
}
