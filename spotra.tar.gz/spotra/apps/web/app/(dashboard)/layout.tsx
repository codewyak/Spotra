'use client';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';
import { useEffect } from 'react';
import {
  LayoutDashboard, Radio, ClipboardList, Users, Truck,
  Warehouse, CreditCard, BarChart3, Settings, LogOut, Zap,
} from 'lucide-react';

const NAV = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard, roles: ['COMPANY_ADMIN', 'DISPATCHER'] },
  { href: '/dashboard/dispatch', label: 'Dispatch', icon: Radio, roles: ['COMPANY_ADMIN', 'DISPATCHER'] },
  { href: '/dashboard/jobs', label: 'Jobs', icon: ClipboardList, roles: ['COMPANY_ADMIN', 'DISPATCHER'] },
  { href: '/dashboard/drivers', label: 'Drivers', icon: Users, roles: ['COMPANY_ADMIN', 'DISPATCHER'] },
  { href: '/dashboard/fleet', label: 'Fleet', icon: Truck, roles: ['COMPANY_ADMIN'] },
  { href: '/dashboard/impound', label: 'Impound', icon: Warehouse, roles: ['COMPANY_ADMIN', 'DISPATCHER'] },
  { href: '/dashboard/payments', label: 'Payments', icon: CreditCard, roles: ['COMPANY_ADMIN'] },
  { href: '/dashboard/reports', label: 'Reports', icon: BarChart3, roles: ['COMPANY_ADMIN'] },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings, roles: ['COMPANY_ADMIN'] },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) router.push('/login');
    if (!isLoading && user && !['COMPANY_ADMIN', 'DISPATCHER'].includes(user.role)) {
      if (user.role === 'PROPERTY_MANAGER' || user.role === 'PROPERTY_STAFF') router.push('/property');
      else router.push('/login');
    }
  }, [user, isLoading, router]);

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="flex items-center gap-3 text-gray-400">
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          Loading…
        </div>
      </div>
    );
  }

  const visibleNav = NAV.filter(n => n.roles.includes(user.role));

  return (
    <div className="min-h-screen bg-gray-950 flex">
      {/* Sidebar */}
      <aside className="w-56 bg-gray-900 border-r border-gray-800 flex flex-col shrink-0">
        {/* Logo */}
        <div className="px-4 py-4 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-white text-lg">Spotra</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {visibleNav.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || (href !== '/dashboard' && pathname.startsWith(href));
            return (
              <Link key={href} href={href} className={active ? 'sidebar-link-active' : 'sidebar-link'}>
                <Icon className="w-4 h-4 shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* User footer */}
        <div className="px-3 py-3 border-t border-gray-800">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-7 h-7 bg-blue-700 rounded-full flex items-center justify-center text-xs font-bold text-white">
              {user.firstName[0]}{user.lastName[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-200 truncate">{user.firstName} {user.lastName}</p>
              <p className="text-xs text-gray-500 truncate">{user.role.replace('_', ' ')}</p>
            </div>
          </div>
          <button onClick={logout} className="sidebar-link w-full text-red-400 hover:text-red-300 hover:bg-red-900/20">
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
