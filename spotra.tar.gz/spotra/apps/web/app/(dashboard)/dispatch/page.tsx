'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import { useSocket } from '@/hooks/use-socket';
import { JOB_STATUS_LABELS, JOB_STATUS_COLORS } from '@spotra/shared';
import { formatDistanceToNow } from 'date-fns';
import {
  MapPin, Clock, User, AlertTriangle, Zap, CheckCircle2,
  ChevronRight, Phone, Loader2, Navigation, RefreshCw, X,
} from 'lucide-react';
import type { TowJobSummary } from '@spotra/shared';

export default function DispatchPage() {
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [queue, setQueue] = useState<any[]>([]);
  const utils = trpc.useUtils();
  const { socket, isConnected } = useSocket();

  const queueQuery = trpc.dispatch.getQueue.useQuery(undefined, { refetchInterval: 10000 });
  const locationsQuery = trpc.dispatch.getDriverLocations.useQuery(undefined, { refetchInterval: 5000 });

  // Sync queue from query
  useEffect(() => {
    if (queueQuery.data) setQueue(queueQuery.data);
  }, [queueQuery.data]);

  // WebSocket live updates
  useEffect(() => {
    if (!socket) return;

    const handleJobCreated = (event: any) => {
      utils.dispatch.getQueue.invalidate();
      utils.tow.getDashboardStats.invalidate();
    };
    const handleStatusChanged = (event: any) => {
      setQueue(prev => prev.map(j => j.id === event.payload.jobId ? { ...j, status: event.payload.status } : prev));
      utils.dispatch.getQueue.invalidate();
    };
    const handleDeclined = (event: any) => {
      utils.dispatch.getQueue.invalidate();
    };

    socket.on('job:created', handleJobCreated);
    socket.on('job:status_changed', handleStatusChanged);
    socket.on('job:declined', handleDeclined);
    return () => {
      socket.off('job:created', handleJobCreated);
      socket.off('job:status_changed', handleStatusChanged);
      socket.off('job:declined', handleDeclined);
    };
  }, [socket, utils]);

  const pending = queue.filter(j => j.status === 'PENDING');
  const active = queue.filter(j => ['DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING'].includes(j.status));
  const selectedJob = queue.find(j => j.id === selectedJobId) ?? null;

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="px-6 py-3 border-b border-gray-800 flex items-center justify-between bg-gray-900/50">
        <div className="flex items-center gap-3">
          <h1 className="text-sm font-semibold text-white">Dispatch Console</h1>
          <div className={`flex items-center gap-1.5 text-xs ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400 status-pulse' : 'bg-red-400'}`} />
            {isConnected ? 'Live' : 'Reconnecting…'}
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs text-gray-400">
          <span><span className="text-amber-400 font-medium">{pending.length}</span> pending</span>
          <span><span className="text-blue-400 font-medium">{active.length}</span> active</span>
          <span><span className="text-green-400 font-medium">{locationsQuery.data?.filter(d => d.isAvailable).length ?? 0}</span> available drivers</span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Job Queue Panel */}
        <div className="w-80 border-r border-gray-800 flex flex-col bg-gray-900/30 overflow-hidden">
          {/* Pending */}
          <div className="flex-1 overflow-y-auto">
            {pending.length > 0 && (
              <div>
                <div className="px-3 py-2 border-b border-gray-800 flex items-center gap-2">
                  <div className="w-2 h-2 bg-amber-400 rounded-full status-pulse" />
                  <span className="text-xs font-medium text-amber-400 uppercase tracking-wider">Needs Dispatch ({pending.length})</span>
                </div>
                {pending.map(job => (
                  <JobCard key={job.id} job={job} selected={job.id === selectedJobId} onClick={() => setSelectedJobId(job.id)} />
                ))}
              </div>
            )}

            {active.length > 0 && (
              <div>
                <div className="px-3 py-2 border-b border-gray-800 flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full status-pulse" />
                  <span className="text-xs font-medium text-blue-400 uppercase tracking-wider">In Progress ({active.length})</span>
                </div>
                {active.map(job => (
                  <JobCard key={job.id} job={job} selected={job.id === selectedJobId} onClick={() => setSelectedJobId(job.id)} />
                ))}
              </div>
            )}

            {queue.length === 0 && !queueQuery.isLoading && (
              <div className="p-6 text-center text-sm text-gray-500">
                <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
                Queue is clear
              </div>
            )}
            {queueQuery.isLoading && (
              <div className="p-4 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-gray-500" /></div>
            )}
          </div>
        </div>

        {/* Map + Detail Panel */}
        <div className="flex-1 flex overflow-hidden">
          {/* Map placeholder (Mapbox integration point) */}
          <div className="flex-1 relative bg-gray-950">
            <MapView drivers={locationsQuery.data ?? []} selectedJobId={selectedJobId} />
          </div>

          {/* Job Detail Side Panel */}
          {selectedJob && (
            <div className="w-96 border-l border-gray-800 overflow-y-auto bg-gray-900">
              <JobDetailPanel job={selectedJob} onClose={() => setSelectedJobId(null)} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Job Card ───────────────────────────────────────────────────────────────────
function JobCard({ job, selected, onClick }: { job: any; selected: boolean; onClick: () => void }) {
  const isPending = job.status === 'PENDING';
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-3 py-3 border-b border-gray-800/50 transition-colors ${selected ? 'bg-blue-500/10 border-l-2 border-l-blue-500' : 'hover:bg-gray-800/50'}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            <StatusBadge status={job.status} />
            {job.aiFlags?.length > 0 && (
              <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
            )}
          </div>
          <p className="text-sm font-medium text-gray-100 truncate">{job.property?.name}</p>
          <p className="text-xs text-gray-400 truncate">{job.vehicle?.plate} · {job.violationReason}</p>
          {job.driver && (
            <p className="text-xs text-blue-400 mt-0.5">
              <User className="w-3 h-3 inline mr-0.5" />
              {job.driver.user?.firstName} {job.driver.user?.lastName}
            </p>
          )}
        </div>
        <div className="text-right shrink-0">
          <p className="text-xs text-gray-500">{formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</p>
          {isPending && <div className="w-2 h-2 bg-amber-400 rounded-full ml-auto mt-1 status-pulse" />}
        </div>
      </div>
    </button>
  );
}

// ── Job Detail Panel ───────────────────────────────────────────────────────────
function JobDetailPanel({ job, onClose }: { job: any; onClose: () => void }) {
  const [selectedDriverId, setSelectedDriverId] = useState<string>('');
  const utils = trpc.useUtils();

  const suggestion = trpc.dispatch.getSuggestion.useQuery({ jobId: job.id }, { enabled: job.status === 'PENDING' });
  const availableDrivers = trpc.dispatch.getAvailableDrivers.useQuery(undefined, { enabled: job.status === 'PENDING' });
  const assignMutation = trpc.tow.assignDriver.useMutation({
    onSuccess: () => {
      utils.dispatch.getQueue.invalidate();
      setSelectedDriverId('');
    },
  });

  const topSuggestion = suggestion.data?.[0];

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-gray-500 font-mono">#{job.ticketNumber}</p>
          <StatusBadge status={job.status} />
        </div>
        <button onClick={onClose} className="p-1 hover:bg-gray-800 rounded-lg">
          <X className="w-4 h-4 text-gray-400" />
        </button>
      </div>

      {/* Property */}
      <Section title="Location">
        <Detail icon={MapPin} label="Property" value={job.property?.name} />
        <Detail icon={MapPin} label="Address" value={job.property?.address} />
        {job.spot && <Detail icon={MapPin} label="Spot" value={`Zone ${job.spot.zone} · Space ${job.spot.label}`} />}
      </Section>

      {/* Vehicle */}
      <Section title="Vehicle">
        <Detail label="Plate" value={`${job.vehicle?.plate} (${job.vehicle?.state})`} mono />
        {job.vehicle?.make && <Detail label="Vehicle" value={`${job.vehicle.color ?? ''} ${job.vehicle.year ?? ''} ${job.vehicle.make} ${job.vehicle.model ?? ''}`.trim()} />}
        <Detail label="Violation" value={job.violationReason} />
      </Section>

      {/* Evidence photos */}
      {job.requestPhotoUrls?.length > 0 && (
        <Section title={`Request Photos (${job.requestPhotoUrls.length})`}>
          <div className="grid grid-cols-2 gap-1.5">
            {job.requestPhotoUrls.slice(0, 4).map((url: string, i: number) => (
              <img key={i} src={url} alt={`Evidence ${i + 1}`} className="w-full aspect-video object-cover rounded-lg bg-gray-800" />
            ))}
          </div>
        </Section>
      )}

      {/* AI Flags */}
      {job.aiFlags?.length > 0 && (
        <Section title="AI Flags">
          {job.aiFlags.map((flag: any) => (
            <div key={flag.id} className="flex items-start gap-2 text-xs bg-amber-500/10 rounded-lg p-2">
              <AlertTriangle className="w-3 h-3 text-amber-400 mt-0.5 shrink-0" />
              <span className="text-amber-300">{flag.message}</span>
            </div>
          ))}
        </Section>
      )}

      {/* Driver Assignment (PENDING jobs) */}
      {job.status === 'PENDING' && (
        <Section title="Assign Driver">
          {/* AI Suggestion */}
          {topSuggestion && (
            <div className="bg-blue-500/10 rounded-lg p-3 mb-3 border border-blue-500/20">
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-3 h-3 text-blue-400" />
                <span className="text-xs font-medium text-blue-400">AI Suggestion</span>
              </div>
              <p className="text-sm font-medium text-white">{topSuggestion.driverName}</p>
              <p className="text-xs text-gray-400">{topSuggestion.reason} · ~{topSuggestion.estimatedMinutes} min</p>
              <button
                onClick={() => assignMutation.mutate({ jobId: job.id, driverId: topSuggestion.driverId })}
                disabled={assignMutation.isPending}
                className="btn-primary mt-2 w-full text-xs py-1.5"
              >
                {assignMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mx-auto" /> : `Assign ${topSuggestion.driverName}`}
              </button>
            </div>
          )}

          {/* Manual select */}
          <div className="space-y-2">
            <select
              value={selectedDriverId}
              onChange={e => setSelectedDriverId(e.target.value)}
              className="input text-sm"
            >
              <option value="">Select a driver manually…</option>
              {availableDrivers.data?.map((d: any) => (
                <option key={d.id} value={d.id}>
                  {d.user.firstName} {d.user.lastName} — {d.fleetVehicle?.make ?? 'No vehicle'}
                </option>
              ))}
            </select>
            {selectedDriverId && (
              <button
                onClick={() => assignMutation.mutate({ jobId: job.id, driverId: selectedDriverId })}
                disabled={assignMutation.isPending}
                className="btn-secondary w-full text-sm"
              >
                {assignMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Assign Driver'}
              </button>
            )}
          </div>
        </Section>
      )}

      {/* Current driver info */}
      {job.driver && (
        <Section title="Assigned Driver">
          <Detail icon={User} label="Name" value={`${job.driver.user?.firstName} ${job.driver.user?.lastName}`} />
          {job.driver.user?.phone && <Detail icon={Phone} label="Phone" value={job.driver.user.phone} />}
          <Detail label="Status" value={JOB_STATUS_LABELS[job.status as keyof typeof JOB_STATUS_LABELS]} />
        </Section>
      )}

      {/* Timeline */}
      <Section title="Timeline">
        <TimelineRow label="Requested" time={job.createdAt} />
        {job.dispatchedAt && <TimelineRow label="Dispatched" time={job.dispatchedAt} />}
        {job.arrivedAt && <TimelineRow label="Arrived" time={job.arrivedAt} />}
        {job.towStartedAt && <TimelineRow label="Tow started" time={job.towStartedAt} />}
        {job.completedAt && <TimelineRow label="Completed" time={job.completedAt} />}
      </Section>
    </div>
  );
}

// ── Map View (Mapbox integration point) ────────────────────────────────────────
function MapView({ drivers, selectedJobId }: { drivers: any[]; selectedJobId: string | null }) {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <div className="text-center">
        <Navigation className="w-8 h-8 text-gray-600 mx-auto mb-2" />
        <p className="text-sm text-gray-500">Map View</p>
        <p className="text-xs text-gray-600 mt-1">
          {drivers.length} drivers · {drivers.filter(d => d.isOnline).length} online
        </p>
        <p className="text-xs text-gray-700 mt-1">Mapbox GL JS integration point</p>
        <div className="mt-4 space-y-1">
          {drivers.filter(d => d.lat).map(d => (
            <div key={d.driverId} className="flex items-center gap-2 text-xs text-left bg-gray-900 rounded-lg px-3 py-1.5">
              <div className={`w-2 h-2 rounded-full ${d.isAvailable ? 'bg-green-400' : 'bg-gray-500'}`} />
              <span className="text-gray-300">{d.driverName}</span>
              <span className="text-gray-500">{d.lat?.toFixed(4)}, {d.lng?.toFixed(4)}</span>
              {d.isOnline && <span className="text-green-500 ml-auto">●</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="label mb-2">{title}</p>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function Detail({ icon: Icon, label, value, mono }: { icon?: any; label: string; value?: string | null; mono?: boolean }) {
  return (
    <div className="flex items-start gap-2 text-sm">
      {Icon && <Icon className="w-3.5 h-3.5 text-gray-500 mt-0.5 shrink-0" />}
      <span className="text-gray-400 shrink-0">{label}:</span>
      <span className={`text-gray-200 ${mono ? 'font-mono' : ''}`}>{value ?? '—'}</span>
    </div>
  );
}

function TimelineRow({ label, time }: { label: string; time: string | Date }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-gray-400">{label}</span>
      <span className="text-gray-300 font-mono">{new Date(time).toLocaleTimeString()}</span>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    PENDING: 'bg-amber-500/15 text-amber-400',
    DISPATCHED: 'bg-blue-500/15 text-blue-400',
    EN_ROUTE: 'bg-blue-500/15 text-blue-300',
    ARRIVED: 'bg-indigo-500/15 text-indigo-400',
    TOWING: 'bg-orange-500/15 text-orange-400',
    COMPLETED: 'bg-green-500/15 text-green-400',
    RELEASED: 'bg-emerald-500/15 text-emerald-400',
    DISPUTED: 'bg-red-500/15 text-red-400',
    CANCELLED: 'bg-gray-700 text-gray-400',
  };
  return (
    <span className={`badge ${colors[status] ?? 'bg-gray-700 text-gray-400'}`}>
      {JOB_STATUS_LABELS[status as keyof typeof JOB_STATUS_LABELS] ?? status}
    </span>
  );
}
