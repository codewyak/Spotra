'use client';
import { trpc } from '@/lib/trpc';
import { formatCents, formatDuration } from '@/lib/utils';
import { Zap, TrendingUp, Clock, DollarSign, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';

export default function DashboardPage() {
  const stats = trpc.tow.getDashboardStats.useQuery(undefined, { refetchInterval: 30000 });
  const summary = trpc.admin.getDailySummary.useQuery(undefined, { staleTime: 60000 });
  const flags = trpc.admin.getStats.useQuery(undefined, { staleTime: 60000 });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-white">Overview</h1>
        <p className="text-sm text-gray-400 mt-0.5">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="Active Jobs"
          value={stats.data?.activeJobs ?? 0}
          icon={Zap}
          color="blue"
          loading={stats.isLoading}
          pulse={!!stats.data?.activeJobs}
        />
        <KpiCard
          label="Pending Dispatch"
          value={stats.data?.pendingJobs ?? 0}
          icon={Clock}
          color={stats.data?.pendingJobs ? 'amber' : 'gray'}
          loading={stats.isLoading}
        />
        <KpiCard
          label="Completed Today"
          value={stats.data?.completedToday ?? 0}
          icon={CheckCircle2}
          color="green"
          loading={stats.isLoading}
        />
        <KpiCard
          label="Revenue Today"
          value={formatCents(stats.data?.revenueToday ?? 0)}
          icon={DollarSign}
          color="emerald"
          loading={stats.isLoading}
          isString
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* AI Daily Summary */}
        <div className="card p-4 lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <h2 className="text-sm font-medium text-gray-300">Daily Summary</h2>
            <span className="badge bg-blue-500/15 text-blue-400">AI</span>
          </div>
          {summary.isLoading ? (
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating summary…
            </div>
          ) : (
            <p className="text-sm text-gray-300 leading-relaxed">
              {summary.data ?? 'No summary available yet. Check back after your first completed job today.'}
            </p>
          )}
        </div>

        {/* Unresolved Flags */}
        <div className="card p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-medium text-gray-300">AI Flags</h2>
            {!!flags.data?.openDisputes && (
              <span className="badge bg-red-500/15 text-red-400">{flags.data.openDisputes} open</span>
            )}
          </div>
          {flags.isLoading ? (
            <div className="text-sm text-gray-500">Loading…</div>
          ) : !flags.data?.recentFlags?.length ? (
            <div className="text-sm text-gray-500">No active flags — all clear.</div>
          ) : (
            <div className="space-y-2">
              {flags.data.recentFlags.slice(0, 4).map((f: any) => (
                <div key={f.id} className="flex items-start gap-2 text-xs">
                  <span className={`badge mt-0.5 shrink-0 ${
                    f.severity === 'HIGH' ? 'bg-red-500/15 text-red-400' :
                    f.severity === 'MEDIUM' ? 'bg-amber-500/15 text-amber-400' :
                    'bg-gray-700 text-gray-400'
                  }`}>
                    {f.severity}
                  </span>
                  <div>
                    <p className="text-gray-300">{f.message}</p>
                    <p className="text-gray-500">{f.job?.vehicle?.plate} · {f.job?.property?.name}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Avg dispatch time */}
      {stats.data?.avgDispatchMs > 0 && (
        <div className="card p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-blue-400 shrink-0" />
          <div>
            <p className="text-sm font-medium text-gray-300">
              Avg dispatch time today: <span className="text-white">{formatDuration(stats.data.avgDispatchMs)}</span>
            </p>
            <p className="text-xs text-gray-500">From request submitted to driver assigned</p>
          </div>
        </div>
      )}
    </div>
  );
}

function KpiCard({ label, value, icon: Icon, color, loading, pulse, isString }: {
  label: string; value: number | string; icon: any; color: string; loading?: boolean; pulse?: boolean; isString?: boolean;
}) {
  const colors: Record<string, string> = {
    blue: 'text-blue-400 bg-blue-500/10',
    amber: 'text-amber-400 bg-amber-500/10',
    green: 'text-green-400 bg-green-500/10',
    emerald: 'text-emerald-400 bg-emerald-500/10',
    gray: 'text-gray-400 bg-gray-800',
  };
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="label">{label}</p>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colors[color] ?? colors.gray}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      {loading ? (
        <div className="h-8 w-16 bg-gray-800 animate-pulse rounded" />
      ) : (
        <p className={`text-2xl font-bold text-white ${pulse ? 'status-pulse' : ''}`}>
          {isString ? value : value.toLocaleString()}
        </p>
      )}
    </div>
  );
}
