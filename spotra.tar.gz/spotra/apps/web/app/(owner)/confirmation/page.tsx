'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { CheckCircle2, MapPin, Phone, Clock, Zap, ArrowRight } from 'lucide-react';

export default function ConfirmationPage() {
  const [data, setData] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    const stored = sessionStorage.getItem('spotra_lookup');
    if (!stored) { router.push('/'); return; }
    setData(JSON.parse(stored));
  }, [router]);

  if (!data) return null;

  const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const todayKey = DAYS[new Date().getDay()];
  const todayHours = data.impoundLot?.hours?.[todayKey];

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <header className="border-b border-gray-800 px-4 py-3 flex items-center gap-2">
        <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center"><Zap className="w-3.5 h-3.5 text-white" /></div>
        <span className="font-bold text-white">Spotra</span>
      </header>

      <main className="flex-1 px-4 py-8 max-w-md mx-auto w-full">
        {/* Success header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-500/15 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-xl font-bold text-white mb-1">Payment confirmed</h1>
          <p className="text-sm text-gray-400">
            {formatCents(data.fees?.totalCents ?? 0)} paid · Receipt sent to {data.ownerEmail ?? 'your email'}
          </p>
        </div>

        {/* What to do next */}
        <div className="card p-4 mb-4">
          <p className="label mb-3">What to do now</p>
          <div className="space-y-3">
            <Step n={1} text="Bring your valid photo ID and vehicle registration" />
            <Step n={2} text={`Go to ${data.impoundLot?.name ?? 'the impound lot'}`} />
            <Step n={3} text="Show this confirmation screen to the attendant" />
            <Step n={4} text="Pick up your vehicle" />
          </div>
        </div>

        {/* Lot details */}
        {data.impoundLot && (
          <div className="card p-4 mb-4 space-y-3">
            <p className="label">Impound location</p>
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-white">{data.impoundLot.name}</p>
                <p className="text-sm text-gray-400">{data.impoundLot.address}</p>
              </div>
            </div>
            {todayHours && (
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Clock className="w-3.5 h-3.5" />
                Today: <span className="text-gray-200 font-medium">{todayHours}</span>
              </div>
            )}
            {data.impoundLot.phone && (
              <a href={`tel:${data.impoundLot.phone}`} className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300">
                <Phone className="w-3.5 h-3.5" />
                {data.impoundLot.phone}
              </a>
            )}
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(data.impoundLot.address)}`}
              target="_blank" rel="noopener noreferrer"
              className="btn-primary w-full flex items-center justify-center gap-2 text-sm"
            >
              Get Directions <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        )}

        {/* Confirmation code */}
        <div className="card p-4 text-center">
          <p className="label mb-2">Your confirmation</p>
          <p className="font-mono text-2xl font-bold text-white tracking-widest">{data.ticketNumber}</p>
          <p className="text-xs text-gray-500 mt-1">Show this to yard staff</p>
        </div>

        <button onClick={() => { sessionStorage.removeItem('spotra_lookup'); router.push('/'); }} className="btn-secondary w-full mt-4 text-sm">
          Done
        </button>
      </main>
    </div>
  );
}

function Step({ n, text }: { n: number; text: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 mt-0.5">{n}</div>
      <p className="text-sm text-gray-300">{text}</p>
    </div>
  );
}
function formatCents(c: number) { return `$${(c / 100).toFixed(2)}`; }
