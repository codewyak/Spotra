'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { ArrowLeft, Zap, Lock, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

export default function PayPage() {
  const [data, setData] = useState<any>(null);
  const [clientSecret, setClientSecret] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [step, setStep] = useState<'info' | 'payment'>('info');
  const [initError, setInitError] = useState('');
  const [isInitializing, setIsInitializing] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const stored = sessionStorage.getItem('spotra_lookup');
    if (!stored) { router.push('/'); return; }
    setData(JSON.parse(stored));
  }, [router]);

  async function initPayment(e: React.FormEvent) {
    e.preventDefault();
    if (!data?.jobId) return;
    setInitError('');
    setIsInitializing(true);

    try {
      const res = await fetch('/api/v1/payments/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId: data.jobId, ownerEmail, ownerName }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? 'Failed to initialize payment');
      setClientSecret(json.clientSecret);
      setStep('payment');
    } catch (err: any) {
      setInitError(err.message);
    } finally {
      setIsInitializing(false);
    }
  }

  if (!data) return <div className="min-h-screen bg-gray-950 flex items-center justify-center"><div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <header className="border-b border-gray-800 px-4 py-3 flex items-center gap-3">
        <button onClick={() => step === 'payment' ? setStep('info') : router.back()} className="p-1 hover:bg-gray-800 rounded-lg">
          <ArrowLeft className="w-4 h-4 text-gray-400" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center"><Zap className="w-3.5 h-3.5 text-white" /></div>
          <span className="font-bold text-white">Spotra</span>
        </div>
        <div className="ml-auto flex items-center gap-1.5 text-xs text-gray-500">
          <Lock className="w-3 h-3" /> Secure payment
        </div>
      </header>

      <main className="flex-1 px-4 py-6 max-w-md mx-auto w-full">
        {/* Order summary */}
        <div className="card p-4 mb-4">
          <p className="label mb-2">Payment summary</p>
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-400">{data.vehicle?.plate} · {data.company?.name}</p>
              <p className="text-xs text-gray-500 mt-0.5">
                Tow fee + {data.fees?.storageDays ?? 0} day{data.fees?.storageDays !== 1 ? 's' : ''} storage
              </p>
            </div>
            <p className="text-xl font-bold text-white">{formatCents(data.fees?.totalCents ?? 0)}</p>
          </div>
        </div>

        {step === 'info' ? (
          <form onSubmit={initPayment} className="card p-4 space-y-4">
            <p className="text-sm font-medium text-gray-300">Your contact info</p>
            <div>
              <label className="label mb-1 block">Full name</label>
              <input
                value={ownerName}
                onChange={e => setOwnerName(e.target.value)}
                className="input"
                placeholder="Jane Smith"
                required
              />
            </div>
            <div>
              <label className="label mb-1 block">Email (for receipt)</label>
              <input
                type="email"
                value={ownerEmail}
                onChange={e => setOwnerEmail(e.target.value)}
                className="input"
                placeholder="jane@example.com"
                required
              />
            </div>
            {initError && (
              <div className="flex items-start gap-2 text-sm text-red-400 bg-red-900/20 rounded-lg p-3 border border-red-900">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                {initError}
              </div>
            )}
            <button type="submit" disabled={isInitializing || !ownerEmail || !ownerName} className="btn-primary w-full py-3 flex items-center justify-center gap-2">
              {isInitializing ? <><Loader2 className="w-4 h-4 animate-spin" /> Setting up payment…</> : 'Continue to Payment'}
            </button>
          </form>
        ) : clientSecret ? (
          <Elements
            stripe={stripePromise}
            options={{
              clientSecret,
              appearance: {
                theme: 'night',
                variables: {
                  colorPrimary: '#3b82f6',
                  colorBackground: '#111827',
                  colorText: '#f3f4f6',
                  colorDanger: '#ef4444',
                  fontFamily: 'Inter, system-ui, sans-serif',
                  borderRadius: '8px',
                },
              },
            }}
          >
            <CheckoutForm
              total={data.fees?.totalCents ?? 0}
              jobId={data.jobId}
              onSuccess={() => {
                const updated = { ...data, paymentStatus: 'SUCCEEDED' };
                sessionStorage.setItem('spotra_lookup', JSON.stringify(updated));
                router.push('/confirmation');
              }}
            />
          </Elements>
        ) : null}
      </main>
    </div>
  );
}

function CheckoutForm({ total, jobId, onSuccess }: { total: number; jobId: string; onSuccess: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!stripe || !elements) return;
    setError('');
    setIsProcessing(true);

    const { error: submitError } = await elements.submit();
    if (submitError) { setError(submitError.message ?? 'Payment failed'); setIsProcessing(false); return; }

    const { error: confirmError } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: `${window.location.origin}/confirmation?jobId=${jobId}` },
      redirect: 'if_required',
    });

    if (confirmError) {
      setError(confirmError.message ?? 'Payment failed. Please try again.');
      setIsProcessing(false);
    } else {
      onSuccess();
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card p-4 space-y-4">
      <p className="text-sm font-medium text-gray-300">Card details</p>
      <PaymentElement />
      {error && (
        <div className="flex items-start gap-2 text-sm text-red-400 bg-red-900/20 rounded-lg p-3 border border-red-900">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          {error}
        </div>
      )}
      <button type="submit" disabled={!stripe || isProcessing} className="btn-primary w-full py-3 flex items-center justify-center gap-2 text-base">
        {isProcessing
          ? <><Loader2 className="w-5 h-5 animate-spin" /> Processing…</>
          : <><Lock className="w-4 h-4" /> Pay {formatCents(total)}</>}
      </button>
      <p className="text-xs text-center text-gray-600">Secured by Stripe · No card data stored by Spotra</p>
    </form>
  );
}

function formatCents(c: number) { return `$${(c / 100).toFixed(2)}`; }
