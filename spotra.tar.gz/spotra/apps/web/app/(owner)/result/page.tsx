'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { MapPin, Phone, Clock, DollarSign, ChevronRight, AlertCircle, ArrowLeft, CheckCircle2, Zap } from 'lucide-react';

export default function ResultPage() {
  const [data, setData] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    const stored = sessionStorage.getItem('spotra_lookup');
    if (!stored) { router.push('/'); return; }
    setData(JSON.parse(stored));
  }, [router]);

  if (!data) return <LoadingScreen />;

  const isPaid = data.paymentStatus === 'SUCCEEDED';
  const isPayable = ['COMPLETED', 'RELEASED'].includes(data.status) && !isPaid;

  const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const todayKey = DAYS[new Date().getDay()];
  const todayHours = data.impoundLot?.hours?.[todayKey];

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <header className="border-b border-gray-800 px-4 py-3 flex items-center gap-3">
        <button onClick={() => router.push('/')} className="p-1 hover:bg-gray-800 rounded-lg">
          <ArrowLeft className="w-4 h-4 text-gray-400" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-bold text-white">Spotra</span>
        </div>
      </header>

      <main className="flex-1 px-4 py-6 max-w-lg mx-auto w-full space-y-4">
        {/* Vehicle confirmed */}
        <div className="card p-4">
          <p className="label mb-2">Your vehicle</p>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-2xl font-bold font-mono text-white tracking-widest">{data.vehicle?.plate}</p>
              <p className="text-sm text-gray-400 mt-0.5">
                {[data.vehicle?.color, data.vehicle?.year, data.vehicle?.make, data.vehicle?.model].filter(Boolean).join(' ')}
                {data.vehicle?.state && <span className="ml-1 text-gray-500">({data.vehicle.state})</span>}
              </p>
            </div>
            <span className="badge bg-amber-500/15 text-amber-400">Towed</span>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-800 text-xs text-gray-500">
            Ticket #{data.ticketNumber} · Towed {data.towedAt ? new Date(data.towedAt).toLocaleString() : 'recently'}
          </div>
        </div>

        {/* Towing company */}
        <div className="card p-4">
          <p className="label mb-2">Towed by</p>
          <div className="flex items-center justify-between">
            <p className="font-medium text-white">{data.company?.name}</p>
            <a href={`tel:${data.company?.phone}`} className="flex items-center gap-1.5 text-sm text-blue-400 hover:text-blue-300">
              <Phone className="w-3.5 h-3.5" />
              {data.company?.phone}
            </a>
          </div>
        </div>

        {/* Impound location */}
        {data.impoundLot && (
          <div className="card p-4">
            <p className="label mb-2">Vehicle location</p>
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-medium text-white">{data.impoundLot.name}</p>
                <p className="text-sm text-gray-400">{data.impoundLot.address}</p>
                {todayHours && (
                  <div className="flex items-center gap-1.5 mt-1.5 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    Today: <span className="text-gray-200">{todayHours}</span>
                  </div>
                )}
              </div>
            </div>
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(data.impoundLot.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 btn-secondary w-full text-center text-sm block"
            >
              Get Directions
            </a>
          </div>
        )}

        {/* Fees */}
        {data.fees && (
          <div className="card p-4">
            <p className="label mb-3">Fee breakdown</p>
            <div className="space-y-2 text-sm">
              <FeeRow label="Base tow fee" cents={data.fees.baseTowCents} />
              <FeeRow
                label={`Storage (${data.fees.storageDays} day${data.fees.storageDays !== 1 ? 's' : ''})`}
                cents={data.fees.storageCents}
              />
              <div className="pt-2 mt-2 border-t border-gray-800 flex justify-between font-semibold text-base">
                <span className="text-white">Total due</span>
                <span className="text-white">{formatCents(data.fees.totalCents)}</span>
              </div>
              <p className="text-xs text-gray-500">
                Fees calculated as of {new Date(data.fees.calculatedAt).toLocaleTimeString()}. Storage fees increase daily.
              </p>
            </div>
          </div>
        )}

        {/* Documents required */}
        <div className="card p-4">
          <p className="label mb-2">What to bring to the yard</p>
          <ul className="space-y-1.5">
            {(data.requiresDocuments ?? []).map((doc: string, i: number) => (
              <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0" />
                {doc}
              </li>
            ))}
          </ul>
        </div>

        {/* Payment CTA */}
        {isPaid ? (
          <div className="card p-4 flex items-center gap-3 border-green-900">
            <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0" />
            <div>
              <p className="font-medium text-green-400">Payment complete</p>
              <p className="text-sm text-gray-400">Show your receipt at the yard to pick up your vehicle.</p>
            </div>
          </div>
        ) : isPayable && data.fees ? (
          <button
            onClick={() => {
              sessionStorage.setItem('spotra_lookup', JSON.stringify(data));
              router.push('/pay');
            }}
            className="btn-primary w-full py-4 text-base flex items-center justify-center gap-2"
          >
            <DollarSign className="w-5 h-5" />
            Pay {formatCents(data.fees.totalCents)} Online
            <ChevronRight className="w-5 h-5" />
          </button>
        ) : data.status && !['COMPLETED', 'RELEASED'].includes(data.status) ? (
          <div className="card p-4 flex items-start gap-3">
            <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <div className="text-sm text-gray-300">
              <p className="font-medium">Vehicle is currently being towed</p>
              <p className="text-gray-400 mt-1">Online payment will be available once your vehicle has been checked into the impound lot. Call {data.company?.phone} for updates.</p>
            </div>
          </div>
        ) : null}
      </main>
    </div>
  );
}

function FeeRow({ label, cents }: { label: string; cents: number }) {
  return (
    <div className="flex justify-between text-gray-300">
      <span>{label}</span>
      <span className="font-mono">{formatCents(cents)}</span>
    </div>
  );
}

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center">
      <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

function formatCents(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}
