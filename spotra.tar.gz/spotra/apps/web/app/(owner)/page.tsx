'use client';
import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Loader2, AlertCircle, Zap, Shield, Clock } from 'lucide-react';

export default function OwnerSearchPage() {
  const [query, setQuery] = useState('');
  const [state, setState] = useState('MA');
  const [type, setType] = useState<'plate' | 'vin' | 'ticket'>('plate');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  const US_STATES = ['MA', 'NH', 'RI', 'CT', 'VT', 'ME', 'NY', 'NJ', 'PA', 'CA', 'TX', 'FL', 'IL', 'OH', 'GA', 'NC', 'MI', 'WA', 'AZ', 'CO'];

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    setError('');
    setIsLoading(true);

    try {
      const params = new URLSearchParams({ q: query.trim(), type, state });
      const res = await fetch(`/api/v1/vehicles/lookup?${params}`);
      const data = await res.json();

      if (!data.found) {
        setError('No towed vehicle found matching that information. Double-check the plate number and state.');
        setIsLoading(false);
        return;
      }

      // Store result in sessionStorage for the result page
      sessionStorage.setItem('spotra_lookup', JSON.stringify(data));
      router.push('/result');
    } catch {
      setError('Something went wrong. Please try again.');
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-800 px-4 py-3 flex items-center gap-2">
        <div className="w-6 h-6 bg-blue-600 rounded-lg flex items-center justify-center">
          <Zap className="w-3.5 h-3.5 text-white" />
        </div>
        <span className="font-bold text-white">Spotra</span>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {/* Hero */}
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Was your car towed?</h1>
            <p className="text-gray-400 text-sm">
              Enter your license plate to find your vehicle, see the fees, and pay online.
            </p>
          </div>

          {/* Search form */}
          <div className="card p-5">
            <form onSubmit={handleSearch} className="space-y-4">
              {/* Type toggle */}
              <div className="flex rounded-lg border border-gray-700 overflow-hidden text-sm">
                {(['plate', 'vin', 'ticket'] as const).map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => { setType(t); setQuery(''); inputRef.current?.focus(); }}
                    className={`flex-1 py-1.5 font-medium capitalize transition-colors ${
                      type === t ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:text-gray-200'
                    }`}
                  >
                    {t === 'ticket' ? 'Ticket #' : t.toUpperCase()}
                  </button>
                ))}
              </div>

              {/* Input */}
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  value={query}
                  onChange={e => setQuery(e.target.value.toUpperCase())}
                  placeholder={type === 'plate' ? '7XKA123' : type === 'vin' ? '1HGBH41JXMN109186' : 'SPOT-XXXX-XXX'}
                  className="input font-mono tracking-widest text-lg text-center"
                  autoFocus
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                />
                {type === 'plate' && (
                  <select
                    value={state}
                    onChange={e => setState(e.target.value)}
                    className="input w-20 text-center shrink-0"
                  >
                    {US_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                )}
              </div>

              {error && (
                <div className="flex items-start gap-2 text-sm text-red-400 bg-red-900/20 rounded-lg p-3 border border-red-900">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={!query.trim() || isLoading}
                className="btn-primary w-full flex items-center justify-center gap-2 py-3 text-base"
              >
                {isLoading ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Searching…</>
                ) : (
                  <><Search className="w-5 h-5" /> Find My Vehicle</>
                )}
              </button>
            </form>
          </div>

          {/* Trust signals */}
          <div className="mt-6 grid grid-cols-3 gap-3 text-center text-xs text-gray-500">
            <div className="flex flex-col items-center gap-1">
              <Shield className="w-4 h-4 text-gray-600" />
              Secure payment
            </div>
            <div className="flex flex-col items-center gap-1">
              <Clock className="w-4 h-4 text-gray-600" />
              24/7 lookup
            </div>
            <div className="flex flex-col items-center gap-1">
              <Search className="w-4 h-4 text-gray-600" />
              No login needed
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
