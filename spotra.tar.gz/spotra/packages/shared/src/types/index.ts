import type { UserRole, JobStatus } from '../constants';

// ─── Auth ─────────────────────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  companyId: string | null;
  propertyId: string | null;
  avatarUrl: string | null;
}

export interface TokenPair {
  accessToken: string;
  expiresIn: number;
}

// ─── Tow Job ──────────────────────────────────────────────────────────────────
export interface TowJobSummary {
  id: string;
  status: JobStatus;
  violationReason: string;
  vehiclePlate: string;
  vehicleState: string;
  vehicleMake: string | null;
  vehicleModel: string | null;
  vehicleColor: string | null;
  propertyName: string;
  propertyAddress: string;
  driverName: string | null;
  driverId: string | null;
  requestPhotoUrls: string[];
  evidencePhotoUrls: string[];
  evidencePhotoCount: number;
  createdAt: Date;
  dispatchedAt: Date | null;
  arrivedAt: Date | null;
  towStartedAt: Date | null;
  completedAt: Date | null;
  notes: string | null;
  aiFlags: AiFlag[];
  hasPayment: boolean;
  paymentStatus: string | null;
}

export interface JobEvent {
  id: string;
  jobId: string;
  actorId: string | null;
  actorName: string | null;
  eventType: string;
  payload: Record<string, unknown>;
  timestamp: Date;
}

// ─── Driver ───────────────────────────────────────────────────────────────────
export interface DriverLocation {
  driverId: string;
  driverName: string;
  lat: number;
  lng: number;
  heading: number | null;
  isAvailable: boolean;
  currentJobId: string | null;
  lastSeenAt: Date;
}

export interface DriverWithStatus {
  id: string;
  userId: string;
  name: string;
  phone: string | null;
  isAvailable: boolean;
  currentJobId: string | null;
  currentLat: number | null;
  currentLng: number | null;
  lastSeenAt: Date | null;
  vehicleName: string | null;
  activeJobCount: number;
}

// ─── Vehicle Lookup (public) ──────────────────────────────────────────────────
export interface VehicleLookupResult {
  found: boolean;
  jobId?: string;
  status?: JobStatus;
  towedAt?: Date;
  completedAt?: Date;
  vehicle?: {
    plate: string;
    state: string;
    make: string | null;
    model: string | null;
    color: string | null;
  };
  company?: {
    name: string;
    phone: string;
  };
  impoundLot?: {
    name: string;
    address: string;
    lat: number;
    lng: number;
    phone: string | null;
    hours: Record<string, string> | null;
  };
  fees?: {
    baseTowCents: number;
    storageCents: number;
    storageDays: number;
    totalCents: number;
    calculatedAt: Date;
  };
  requiresDocuments: string[];
  paymentStatus: 'UNPAID' | 'PAID' | 'REFUNDED' | null;
}

// ─── AI ───────────────────────────────────────────────────────────────────────
export interface AiFlag {
  id: string;
  flagType: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  message: string;
  resolved: boolean;
  createdAt: Date;
}

export interface EvidenceCheckResult {
  score: number;
  missing: string[];
  flags: string[];
  plateDetected: string | null;
  confidence: number;
}

export interface DispatchSuggestion {
  driverId: string;
  driverName: string;
  score: number;
  reason: string;
  distanceMiles: number;
  estimatedMinutes: number;
}

// ─── WebSocket Events ─────────────────────────────────────────────────────────
export type WsEventType =
  | 'job:created'
  | 'job:updated'
  | 'job:status_changed'
  | 'job:driver_assigned'
  | 'job:evidence_added'
  | 'driver:location_updated'
  | 'driver:available'
  | 'driver:unavailable'
  | 'dispatch:suggestion'
  | 'job:declined';

export interface WsEvent<T = unknown> {
  type: WsEventType;
  payload: T;
  timestamp: Date;
}

// ─── API Responses ────────────────────────────────────────────────────────────
export interface ApiResponse<T> {
  success: true;
  data: T;
}

export interface ApiError {
  success: false;
  error: string;
  code: string;
  statusCode: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}
