import { z } from 'zod';
import { VIOLATION_REASONS } from '../constants/job-status';

// ─── Pagination ──────────────────────────────────────────────────────────────
export const PaginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});
export type Pagination = z.infer<typeof PaginationSchema>;

// ─── Auth ─────────────────────────────────────────────────────────────────────
export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const TokenPayloadSchema = z.object({
  userId: z.string().uuid(),
  companyId: z.string().uuid().nullable(),
  propertyId: z.string().uuid().nullable(),
  role: z.enum(['SUPER_ADMIN', 'COMPANY_ADMIN', 'DISPATCHER', 'DRIVER', 'PROPERTY_MANAGER', 'PROPERTY_STAFF']),
  iat: z.number().optional(),
  exp: z.number().optional(),
});
export type TokenPayload = z.infer<typeof TokenPayloadSchema>;

// ─── Company ──────────────────────────────────────────────────────────────────
export const CreateCompanySchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  phone: z.string().min(10).max(20),
  address: z.string().min(5),
  city: z.string().default('Boston'),
  state: z.string().length(2).default('MA'),
  zip: z.string().min(5).max(10),
});

// ─── Property ─────────────────────────────────────────────────────────────────
export const CreatePropertySchema = z.object({
  name: z.string().min(2).max(100),
  address: z.string().min(5),
  city: z.string().default('Boston'),
  state: z.string().length(2).default('MA'),
  zip: z.string().min(5).max(10),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  companyId: z.string().uuid(),
});

export const CreateParkingSpotSchema = z.object({
  propertyId: z.string().uuid(),
  zone: z.string().min(1).max(20),
  label: z.string().min(1).max(20),
  spotType: z.enum(['STANDARD', 'RESERVED', 'HANDICAP', 'FIRE_LANE', 'VISITOR']).default('STANDARD'),
  authorizedPlates: z.array(z.string()).default([]),
});

// ─── Tow Job ──────────────────────────────────────────────────────────────────
export const CreateTowJobSchema = z.object({
  propertyId: z.string().uuid(),
  spotId: z.string().uuid().optional(),
  vehiclePlate: z.string().min(2).max(10).toUpperCase(),
  vehicleState: z.string().length(2).default('MA'),
  vehicleMake: z.string().optional(),
  vehicleModel: z.string().optional(),
  vehicleColor: z.string().optional(),
  violationReason: z.enum(VIOLATION_REASONS),
  photoUrls: z.array(z.string().url()).min(1).max(20),
  notes: z.string().max(500).optional(),
});
export type CreateTowJob = z.infer<typeof CreateTowJobSchema>;

export const AssignDriverSchema = z.object({
  jobId: z.string().uuid(),
  driverId: z.string().uuid(),
});

export const UpdateJobStatusSchema = z.object({
  jobId: z.string().uuid(),
  status: z.enum(['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING', 'COMPLETED', 'RELEASED', 'DISPUTED', 'CANCELLED']),
  notes: z.string().max(500).optional(),
});

export const JobFiltersSchema = z.object({
  status: z.enum(['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING', 'COMPLETED', 'RELEASED', 'DISPUTED', 'CANCELLED']).optional(),
  propertyId: z.string().uuid().optional(),
  driverId: z.string().uuid().optional(),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
}).merge(PaginationSchema);

// ─── Evidence ─────────────────────────────────────────────────────────────────
export const AddEvidenceSchema = z.object({
  jobId: z.string().uuid(),
  photoUrls: z.array(z.string().url()).min(1).max(10),
  angle: z.enum(['FRONT', 'REAR', 'PLATE', 'VIOLATION', 'INTERIOR', 'OTHER']).optional(),
  notes: z.string().max(200).optional(),
});

export const PresignedUrlRequestSchema = z.object({
  jobId: z.string().uuid(),
  fileName: z.string().max(100),
  contentType: z.enum(['image/jpeg', 'image/png', 'image/webp', 'image/heic']),
  angle: z.enum(['FRONT', 'REAR', 'PLATE', 'VIOLATION', 'INTERIOR', 'OTHER']),
});

// ─── Driver ───────────────────────────────────────────────────────────────────
export const UpdateDriverLocationSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  accuracy: z.number().optional(),
  heading: z.number().min(0).max(360).optional(),
});

export const DriverDropoffSchema = z.object({
  jobId: z.string().uuid(),
  lotId: z.string().uuid(),
  bayLabel: z.string().max(20).optional(),
  dropoffPhotoUrls: z.array(z.string().url()).min(1).max(5),
  notes: z.string().max(300).optional(),
});

// ─── Vehicle Lookup ───────────────────────────────────────────────────────────
export const VehicleLookupSchema = z.object({
  q: z.string().min(3).max(20).transform(v => v.toUpperCase().replace(/\s/g, '')),
  type: z.enum(['plate', 'vin', 'ticket']).default('plate'),
  state: z.string().length(2).default('MA'),
});
export type VehicleLookup = z.infer<typeof VehicleLookupSchema>;

// ─── Payment ──────────────────────────────────────────────────────────────────
export const InitiatePaymentSchema = z.object({
  jobId: z.string().uuid(),
  ownerEmail: z.string().email(),
  ownerName: z.string().min(2).max(100),
});

export const FeeBreakdownSchema = z.object({
  baseTowCents: z.number().int().min(0),
  storageCents: z.number().int().min(0),
  storageDays: z.number().int().min(0),
  afterHoursCents: z.number().int().min(0),
  convenienceCents: z.number().int().min(0),
  platformFeeCents: z.number().int().min(0),
  totalCents: z.number().int().min(0),
  lockedAt: z.date(),
});
export type FeeBreakdown = z.infer<typeof FeeBreakdownSchema>;

// ─── Impound ──────────────────────────────────────────────────────────────────
export const CreateImpoundLotSchema = z.object({
  name: z.string().min(2).max(100),
  address: z.string().min(5),
  lat: z.number(),
  lng: z.number(),
  capacity: z.number().int().min(1).max(10000),
  phone: z.string().optional(),
  hoursJson: z.record(z.string()).optional(),
});

// ─── User ─────────────────────────────────────────────────────────────────────
export const InviteUserSchema = z.object({
  email: z.string().email(),
  firstName: z.string().min(1).max(50),
  lastName: z.string().min(1).max(50),
  role: z.enum(['COMPANY_ADMIN', 'DISPATCHER', 'DRIVER', 'PROPERTY_MANAGER', 'PROPERTY_STAFF']),
  phone: z.string().min(10).max(20).optional(),
  propertyId: z.string().uuid().optional(),
});
