export * from './roles';
export * from './job-status';

export const GEOFENCE_RADIUS_METERS = 50;
export const GEOFENCE_WARN_METERS = 100;
export const GEOFENCE_BLOCK_METERS = 500;
export const STORAGE_FEE_DAILY_CENTS = 4500;   // $45/day default
export const PLATFORM_FEE_PERCENT = 0.025;      // 2.5%
export const DRIVER_LOCATION_TTL_SECONDS = 30;
export const DRIVER_LOCATION_SYNC_INTERVAL_MS = 15000;
export const MAX_ACTIVE_JOBS_PER_DRIVER = 1;
export const JOB_DECLINE_RETURN_DELAY_MS = 0;   // Immediate return to queue
