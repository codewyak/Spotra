export const JOB_STATUS = {
  PENDING: 'PENDING',
  DISPATCHED: 'DISPATCHED',
  EN_ROUTE: 'EN_ROUTE',
  ARRIVED: 'ARRIVED',
  TOWING: 'TOWING',
  COMPLETED: 'COMPLETED',
  RELEASED: 'RELEASED',
  DISPUTED: 'DISPUTED',
  CANCELLED: 'CANCELLED',
} as const;

export type JobStatus = keyof typeof JOB_STATUS;

export const VALID_TRANSITIONS: Record<JobStatus, JobStatus[]> = {
  PENDING: ['DISPATCHED', 'CANCELLED', 'DISPUTED'],
  DISPATCHED: ['EN_ROUTE', 'PENDING', 'CANCELLED', 'DISPUTED'],
  EN_ROUTE: ['ARRIVED', 'PENDING', 'CANCELLED', 'DISPUTED'],
  ARRIVED: ['TOWING', 'CANCELLED', 'DISPUTED'],
  TOWING: ['COMPLETED', 'DISPUTED'],
  COMPLETED: ['RELEASED', 'DISPUTED'],
  RELEASED: [],
  DISPUTED: ['PENDING', 'COMPLETED', 'RELEASED'],
  CANCELLED: [],
};

export const TERMINAL_STATUSES: JobStatus[] = ['RELEASED', 'CANCELLED'];
export const MIN_EVIDENCE_PHOTOS = 4;

export const JOB_STATUS_LABELS: Record<JobStatus, string> = {
  PENDING: 'Pending',
  DISPATCHED: 'Dispatched',
  EN_ROUTE: 'En Route',
  ARRIVED: 'Arrived',
  TOWING: 'Towing',
  COMPLETED: 'Completed',
  RELEASED: 'Released',
  DISPUTED: 'Disputed',
  CANCELLED: 'Cancelled',
};

export const JOB_STATUS_COLORS: Record<JobStatus, string> = {
  PENDING: 'amber',
  DISPATCHED: 'blue',
  EN_ROUTE: 'blue',
  ARRIVED: 'indigo',
  TOWING: 'orange',
  COMPLETED: 'green',
  RELEASED: 'emerald',
  DISPUTED: 'red',
  CANCELLED: 'gray',
};

export const VIOLATION_REASONS = [
  'No permit displayed',
  'Wrong parking spot',
  'Expired permit',
  'Fire lane violation',
  'Handicap space violation',
  'Blocking driveway',
  'Abandoned vehicle',
  'Unauthorized overnight parking',
  'Double parking',
  'Other',
] as const;

export type ViolationReason = typeof VIOLATION_REASONS[number];
