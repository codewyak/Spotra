import { router } from './trpc';
import { towRouter } from './routers/tow';
import { dispatchRouter } from './routers/dispatch';
import { driverRouter } from './routers/driver';
import { propertyRouter } from './routers/property';
import { paymentRouter } from './routers/payment';
import { impoundRouter } from './routers/impound';
import { adminRouter } from './routers/admin';
import { authRouter } from './routers/auth';

export const appRouter = router({
  auth: authRouter,
  tow: towRouter,
  dispatch: dispatchRouter,
  driver: driverRouter,
  property: propertyRouter,
  payment: paymentRouter,
  impound: impoundRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
