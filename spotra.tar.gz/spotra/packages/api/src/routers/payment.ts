import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import Stripe from 'stripe';
import { router, adminProcedure, companyProcedure } from '../trpc';
import { FeeService } from '../services/fee.service';
import { InitiatePaymentSchema } from '@spotra/shared';
import type { NextApiRequest, NextApiResponse } from 'next';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });

export const paymentRouter = router({

  // ── Get fee breakdown for a job ───────────────────────────────────────────
  getFees: companyProcedure
    .input(z.object({ jobId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const svc = new FeeService(ctx.db);
      return svc.calculateFees(input.jobId);
    }),

  // ── List payments for company ─────────────────────────────────────────────
  list: companyProcedure
    .input(z.object({ page: z.number().int().min(1).default(1), limit: z.number().int().min(1).max(50).default(20) }))
    .query(async ({ ctx, input }) => {
      const skip = (input.page - 1) * input.limit;
      const [items, total, agg] = await Promise.all([
        ctx.db.payment.findMany({
          where: { companyId: ctx.user.companyId! },
          orderBy: { createdAt: 'desc' },
          skip, take: input.limit,
          include: { job: { include: { vehicle: true, property: true } } },
        }),
        ctx.db.payment.count({ where: { companyId: ctx.user.companyId! } }),
        ctx.db.payment.aggregate({
          where: { companyId: ctx.user.companyId!, status: 'SUCCEEDED' },
          _sum: { totalCents: true, platformFeeCents: true },
        }),
      ]);
      return {
        items, total, page: input.page, limit: input.limit,
        hasMore: skip + items.length < total,
        totalRevenueCents: agg._sum.totalCents ?? 0,
        totalPlatformFeesCents: agg._sum.platformFeeCents ?? 0,
      };
    }),

  // ── Issue refund ──────────────────────────────────────────────────────────
  refund: adminProcedure
    .input(z.object({ paymentId: z.string().uuid(), reason: z.string().min(5), amountCents: z.number().int().positive().optional() }))
    .mutation(async ({ ctx, input }) => {
      const payment = await ctx.db.payment.findUnique({ where: { id: input.paymentId, companyId: ctx.user.companyId! } });
      if (!payment) throw new TRPCError({ code: 'NOT_FOUND' });
      if (payment.status !== 'SUCCEEDED') throw new TRPCError({ code: 'BAD_REQUEST', message: 'Payment is not in SUCCEEDED state' });
      if (!payment.stripePaymentIntentId) throw new TRPCError({ code: 'BAD_REQUEST', message: 'No Stripe payment intent found' });

      const refundAmount = input.amountCents ?? payment.totalCents;

      const refund = await stripe.refunds.create({
        payment_intent: payment.stripePaymentIntentId,
        amount: refundAmount,
        reason: 'requested_by_customer',
      });

      await ctx.db.payment.update({
        where: { id: input.paymentId },
        data: {
          status: refundAmount === payment.totalCents ? 'REFUNDED' : 'PARTIALLY_REFUNDED',
          refundedAt: new Date(),
          refundAmountCents: refundAmount,
          refundReason: input.reason,
        },
      });

      return { refundId: refund.id, status: refund.status };
    }),

  // ── Get Stripe Connect onboarding link ────────────────────────────────────
  getOnboardingLink: adminProcedure
    .query(async ({ ctx }) => {
      const company = await ctx.db.company.findUnique({ where: { id: ctx.user.companyId! } });
      if (!company) throw new TRPCError({ code: 'NOT_FOUND' });

      let accountId = company.stripeAccountId;
      if (!accountId) {
        const account = await stripe.accounts.create({
          type: 'express',
          country: 'US',
          email: company.email,
          capabilities: { transfers: { requested: true }, card_payments: { requested: true } },
          business_profile: { name: company.name, mcc: '7549' }, // Towing services MCC
        });
        accountId = account.id;
        await ctx.db.company.update({ where: { id: company.id }, data: { stripeAccountId: accountId } });
      }

      const link = await stripe.accountLinks.create({
        account: accountId,
        refresh_url: `${process.env.NEXT_PUBLIC_APP_URL}/settings?stripe=refresh`,
        return_url: `${process.env.NEXT_PUBLIC_APP_URL}/settings?stripe=success`,
        type: 'account_onboarding',
      });

      return { url: link.url };
    }),
});

// ── REST: Initiate payment (public-facing) ────────────────────────────────────
export async function initiatePaymentRest(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const parse = InitiatePaymentSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: parse.error.flatten() });

  const { jobId, ownerEmail, ownerName } = parse.data;

  const { PrismaClient } = await import('@prisma/client');
  const db = new PrismaClient();

  try {
    const job = await db.towJob.findUnique({
      where: { id: jobId, status: { in: ['COMPLETED', 'RELEASED'] } },
      include: { company: true, vehicle: true },
    });

    if (!job) return res.status(404).json({ error: 'Job not found or not eligible for payment' });
    if (job.payment?.status === 'SUCCEEDED') return res.status(400).json({ error: 'Payment already completed' });

    const feeService = new FeeService(db);
    const fees = await feeService.calculateFees(jobId);

    if (!job.company.stripeAccountId) {
      return res.status(400).json({ error: 'Towing company has not set up payments yet' });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: fees.totalCents,
      currency: 'usd',
      application_fee_amount: fees.platformFeeCents,
      transfer_data: { destination: job.company.stripeAccountId },
      metadata: { jobId, companyId: job.companyId, plate: job.vehicle.plate },
      receipt_email: ownerEmail,
    });

    // Upsert payment record
    await db.payment.upsert({
      where: { jobId },
      create: {
        jobId,
        companyId: job.companyId,
        stripePaymentIntentId: paymentIntent.id,
        ...fees,
        status: 'PENDING',
        ownerEmail,
        ownerName,
        feeLockedAt: new Date(),
      },
      update: {
        stripePaymentIntentId: paymentIntent.id,
        ...fees,
        status: 'PENDING',
        ownerEmail,
        ownerName,
        feeLockedAt: new Date(),
      },
    });

    return res.status(200).json({
      clientSecret: paymentIntent.client_secret,
      fees,
      companyName: job.company.name,
    });
  } finally {
    await db.$disconnect();
  }
}

// ── REST: Stripe webhook handler ──────────────────────────────────────────────
export async function stripeWebhookRest(req: NextApiRequest, res: NextApiResponse) {
  const sig = req.headers['stripe-signature'] as string;
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return res.status(400).json({ error: 'Invalid webhook signature' });
  }

  const { PrismaClient } = await import('@prisma/client');
  const db = new PrismaClient();

  try {
    if (event.type === 'payment_intent.succeeded') {
      const pi = event.data.object as Stripe.PaymentIntent;
      const { jobId } = pi.metadata;

      await db.payment.update({
        where: { stripePaymentIntentId: pi.id },
        data: { status: 'SUCCEEDED', paidAt: new Date(), stripeChargeId: pi.latest_charge as string },
      });

      await db.towJob.update({
        where: { id: jobId },
        data: { vehicleStatus: 'IN_IMPOUND' }, // Owner has paid, ready for release
      });

      await db.jobEvent.create({
        data: {
          jobId,
          eventType: 'PAYMENT_SUCCEEDED',
          payload: { paymentIntentId: pi.id, amountCents: pi.amount },
        },
      });

      // TODO: Send receipt email
    }

    if (event.type === 'payment_intent.payment_failed') {
      const pi = event.data.object as Stripe.PaymentIntent;
      await db.payment.update({
        where: { stripePaymentIntentId: pi.id },
        data: { status: 'FAILED' },
      });
    }

    return res.status(200).json({ received: true });
  } finally {
    await db.$disconnect();
  }
}
