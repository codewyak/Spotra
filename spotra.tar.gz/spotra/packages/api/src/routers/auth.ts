import { z } from 'zod';
import { router, publicProcedure, protectedProcedure } from '../trpc';
import { LoginSchema } from '@spotra/shared';
import { loginUser, refreshAccessToken } from '../services/auth.service';

export const authRouter = router({
  login: publicProcedure
    .input(LoginSchema)
    .mutation(async ({ ctx, input }) => {
      return loginUser(input.email, input.password, ctx.db);
    }),

  refresh: publicProcedure
    .input(z.object({ refreshToken: z.string().min(10) }))
    .mutation(async ({ ctx, input }) => {
      return refreshAccessToken(input.refreshToken, ctx.db);
    }),

  logout: protectedProcedure
    .input(z.object({ refreshToken: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const bcrypt = await import('bcryptjs');
      const tokens = await ctx.db.refreshToken.findMany({
        where: { userId: ctx.user.id, isRevoked: false },
      });
      for (const t of tokens) {
        if (await bcrypt.compare(input.refreshToken, t.tokenHash)) {
          await ctx.db.refreshToken.update({ where: { id: t.id }, data: { isRevoked: true } });
          break;
        }
      }
      return { ok: true };
    }),

  me: protectedProcedure.query(({ ctx }) => ctx.user),
});
