import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, driverProcedure, companyProcedure, dispatcherProcedure } from '../trpc';
import { UpdateDriverLocationSchema, DRIVER_LOCATION_TTL_SECONDS } from '@spotra/shared';

export const driverRouter = router({

  // ── Set availability ───────────────────────────────────────────────────────
  setAvailability: driverProcedure
    .input(z.object({ isAvailable: z.boolean(), expoPushToken: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND', message: 'Driver profile not found' });

      const updated = await ctx.db.driver.update({
        where: { id: driver.id },
        data: {
          isAvailable: input.isAvailable,
          expoPushToken: input.expoPushToken ?? undefined,
          lastSeenAt: new Date(),
        },
      });

      ctx.io.to(ctx.user.companyId!).emit(input.isAvailable ? 'driver:available' : 'driver:unavailable', {
        type: input.isAvailable ? 'driver:available' : 'driver:unavailable',
        payload: { driverId: driver.id },
        timestamp: new Date(),
      });

      return updated;
    }),

  // ── Update GPS location ────────────────────────────────────────────────────
  updateLocation: driverProcedure
    .input(UpdateDriverLocationSchema)
    .mutation(async ({ ctx, input }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND' });

      // Store in Redis (hot path)
      await ctx.redis.setex(
        `driver:loc:${driver.id}`,
        DRIVER_LOCATION_TTL_SECONDS,
        JSON.stringify({ lat: input.lat, lng: input.lng, heading: input.heading, ts: Date.now() }),
      );

      // Sync to DB every ~60s using a separate key
      const lastSync = await ctx.redis.get(`driver:loc:sync:${driver.id}`);
      if (!lastSync) {
        await ctx.db.driver.update({
          where: { id: driver.id },
          data: { currentLat: input.lat, currentLng: input.lng, lastSeenAt: new Date() },
        });
        await ctx.redis.setex(`driver:loc:sync:${driver.id}`, 60, '1');
      }

      // Broadcast to dispatcher
      ctx.io.to(ctx.user.companyId!).emit('driver:location_updated', {
        type: 'driver:location_updated',
        payload: { driverId: driver.id, lat: input.lat, lng: input.lng, heading: input.heading },
        timestamp: new Date(),
      });

      return { ok: true };
    }),

  // ── Get my current assigned job ────────────────────────────────────────────
  getMyJob: driverProcedure
    .query(async ({ ctx }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND' });

      return ctx.db.towJob.findFirst({
        where: {
          driverId: driver.id,
          status: { in: ['DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING'] },
        },
        include: {
          vehicle: true,
          property: true,
          spot: true,
          impoundLot: true,
        },
      });
    }),

  // ── Get job history (driver's own) ────────────────────────────────────────
  getHistory: driverProcedure
    .input(z.object({ page: z.number().int().min(1).default(1), limit: z.number().int().min(1).max(50).default(20) }))
    .query(async ({ ctx, input }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND' });

      const [items, total] = await Promise.all([
        ctx.db.towJob.findMany({
          where: { driverId: driver.id, status: { in: ['COMPLETED', 'RELEASED', 'CANCELLED'] } },
          orderBy: { completedAt: 'desc' },
          skip: (input.page - 1) * input.limit,
          take: input.limit,
          include: { vehicle: true, property: true },
        }),
        ctx.db.towJob.count({ where: { driverId: driver.id, status: { in: ['COMPLETED', 'RELEASED', 'CANCELLED'] } } }),
      ]);

      return { items, total, page: input.page, limit: input.limit, hasMore: input.page * input.limit < total };
    }),

  // ── Decline job (returns to PENDING queue) ────────────────────────────────
  declineJob: driverProcedure
    .input(z.object({ jobId: z.string().uuid(), reason: z.string().max(200).optional() }))
    .mutation(async ({ ctx, input }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND' });

      const job = await ctx.db.towJob.findUnique({ where: { id: input.jobId, driverId: driver.id, status: 'DISPATCHED' } });
      if (!job) throw new TRPCError({ code: 'NOT_FOUND', message: 'Job not found or not assigned to you' });

      await ctx.db.towJob.update({
        where: { id: input.jobId },
        data: { driverId: null, status: 'PENDING', dispatchedAt: null },
      });

      await ctx.db.jobEvent.create({
        data: {
          jobId: input.jobId,
          actorId: ctx.user.id,
          eventType: 'JOB_DECLINED',
          payload: { driverId: driver.id, reason: input.reason || null },
        },
      });

      ctx.io.to(job.companyId).emit('job:declined', {
        type: 'job:declined',
        payload: { jobId: input.jobId, driverId: driver.id, reason: input.reason },
        timestamp: new Date(),
      });

      return { ok: true };
    }),

  // ── List all drivers (admin/dispatcher view) ──────────────────────────────
  list: dispatcherProcedure
    .query(async ({ ctx }) => {
      return ctx.db.driver.findMany({
        where: { companyId: ctx.user.companyId! },
        include: {
          user: { select: { id: true, firstName: true, lastName: true, email: true, phone: true, isActive: true } },
          fleetVehicle: true,
        },
        orderBy: { user: { firstName: 'asc' } },
      });
    }),

  // ── Confirm GPS arrival ────────────────────────────────────────────────────
  confirmArrival: driverProcedure
    .input(z.object({ jobId: z.string().uuid(), lat: z.number(), lng: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
      if (!driver) throw new TRPCError({ code: 'NOT_FOUND' });

      const job = await ctx.db.towJob.findUnique({
        where: { id: input.jobId, driverId: driver.id },
        include: { property: true },
      });
      if (!job) throw new TRPCError({ code: 'NOT_FOUND' });

      // Geofence check
      const dist = haversineMeters(input.lat, input.lng, job.property.lat, job.property.lng);

      await ctx.db.jobEvent.create({
        data: {
          jobId: input.jobId,
          actorId: ctx.user.id,
          eventType: 'ARRIVAL_CONFIRMED',
          payload: { lat: input.lat, lng: input.lng, distanceMeters: Math.round(dist) },
        },
      });

      if (dist > 500) {
        throw new TRPCError({ code: 'BAD_REQUEST', message: `You appear to be ${Math.round(dist)}m from the property. Please drive to the correct location.` });
      }

      await ctx.db.towJob.update({ where: { id: input.jobId }, data: { arrivedAt: new Date(), status: 'ARRIVED' } });
      ctx.io.to(job.companyId).emit('job:status_changed', {
        type: 'job:status_changed',
        payload: { jobId: input.jobId, status: 'ARRIVED', distanceMeters: Math.round(dist) },
        timestamp: new Date(),
      });

      return { ok: true, distanceMeters: Math.round(dist), warned: dist > 100 };
    }),
});

function haversineMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
