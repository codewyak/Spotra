import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure, dispatcherProcedure, companyProcedure, propertyProcedure } from '../trpc';
import { JobService } from '../services/job.service';
import {
  CreateTowJobSchema, AssignDriverSchema, UpdateJobStatusSchema,
  JobFiltersSchema, AddEvidenceSchema, PresignedUrlRequestSchema,
} from '@spotra/shared';
import { generatePresignedUploadUrl } from '../services/storage.service';
import { AiService } from '../services/ai.service';

export const towRouter = router({

  // ── Create Job (Property Manager, Dispatcher, Admin) ───────────────────────
  create: propertyProcedure
    .input(CreateTowJobSchema)
    .mutation(async ({ ctx, input }) => {
      // Resolve companyId: property managers get it from their property contract
      let companyId = ctx.user.companyId;
      if (!companyId) {
        const contract = await ctx.db.companyProperty.findFirst({
          where: { propertyId: input.propertyId, isDefault: true, isActive: true },
        });
        if (!contract) throw new TRPCError({ code: 'BAD_REQUEST', message: 'No towing company contracted for this property' });
        companyId = contract.companyId;
      }

      const vehicle = await ctx.db.vehicle.upsert({
        where: { plate_state: { plate: input.vehiclePlate, state: input.vehicleState } },
        create: {
          plate: input.vehiclePlate,
          state: input.vehicleState,
          make: input.vehicleMake,
          model: input.vehicleModel,
          color: input.vehicleColor,
        },
        update: {
          make: input.vehicleMake ?? undefined,
          model: input.vehicleModel ?? undefined,
          color: input.vehicleColor ?? undefined,
        },
      });

      const job = await ctx.db.towJob.create({
        data: {
          companyId,
          propertyId: input.propertyId,
          spotId: input.spotId,
          vehicleId: vehicle.id,
          violationReason: input.violationReason,
          requestPhotoUrls: input.photoUrls,
          notes: input.notes,
          requestedById: ctx.user.id,
          status: 'PENDING',
        },
        include: { vehicle: true, property: true, spot: true },
      });

      await ctx.db.jobEvent.create({
        data: {
          jobId: job.id,
          actorId: ctx.user.id,
          eventType: 'JOB_CREATED',
          payload: { source: ctx.user.role, violationReason: input.violationReason },
        },
      });

      ctx.io.to(companyId).emit('job:created', {
        type: 'job:created',
        payload: {
          jobId: job.id,
          ticketNumber: job.ticketNumber,
          propertyName: job.property.name,
          violationReason: job.violationReason,
          plate: job.vehicle.plate,
          createdAt: job.createdAt,
        },
        timestamp: new Date(),
      });

      // Async AI dispatch suggestion (don't await)
      void AiService.suggestDriver(job.id, companyId, ctx.db, ctx.io).catch(() => null);
      void AiService.runOcr(job.id, input.photoUrls, ctx.db).catch(() => null);

      return job;
    }),

  // ── Get Single Job ────────────────────────────────────────────────────────
  get: protectedProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const job = await ctx.db.towJob.findUnique({
        where: { id: input.id },
        include: {
          vehicle: true,
          property: true,
          spot: true,
          driver: { include: { user: { select: { firstName: true, lastName: true, phone: true } } } },
          impoundLot: true,
          impoundRecord: true,
          payment: true,
          disputes: { orderBy: { createdAt: 'desc' }, take: 1 },
          aiFlags: { where: { resolved: false }, orderBy: { createdAt: 'desc' } },
          events: { orderBy: { timestamp: 'asc' }, include: { actor: { select: { firstName: true, lastName: true, role: true } } } },
        },
      });

      if (!job) throw new TRPCError({ code: 'NOT_FOUND' });

      // Tenant isolation
      const user = ctx.user;
      if (user.companyId && job.companyId !== user.companyId) throw new TRPCError({ code: 'FORBIDDEN' });
      if (user.propertyId && job.propertyId !== user.propertyId) throw new TRPCError({ code: 'FORBIDDEN' });

      return job;
    }),

  // ── List Jobs ─────────────────────────────────────────────────────────────
  list: companyProcedure
    .input(JobFiltersSchema)
    .query(async ({ ctx, input }) => {
      const { page, limit, status, propertyId, driverId, dateFrom, dateTo } = input;
      const skip = (page - 1) * limit;

      const where: Record<string, unknown> = { companyId: ctx.user.companyId };
      if (status) where.status = status;
      if (propertyId) where.propertyId = propertyId;
      if (driverId) where.driverId = driverId;
      if (dateFrom || dateTo) {
        where.createdAt = {};
        if (dateFrom) (where.createdAt as Record<string, Date>).gte = dateFrom;
        if (dateTo) (where.createdAt as Record<string, Date>).lte = dateTo;
      }

      const [items, total] = await Promise.all([
        ctx.db.towJob.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            vehicle: true,
            property: true,
            driver: { include: { user: { select: { firstName: true, lastName: true } } } },
            aiFlags: { where: { resolved: false } },
            payment: { select: { status: true, totalCents: true } },
          },
        }),
        ctx.db.towJob.count({ where }),
      ]);

      return { items, total, page, limit, hasMore: skip + items.length < total };
    }),

  // ── Assign Driver ─────────────────────────────────────────────────────────
  assignDriver: dispatcherProcedure
    .input(AssignDriverSchema)
    .mutation(async ({ ctx, input }) => {
      const svc = new JobService(ctx.db, ctx.io);
      return svc.assignDriver(input.jobId, input.driverId, ctx.user.id, ctx.user.companyId!);
    }),

  // ── Update Status ─────────────────────────────────────────────────────────
  updateStatus: protectedProcedure
    .input(UpdateJobStatusSchema)
    .mutation(async ({ ctx, input }) => {
      // Drivers can only update their own jobs
      if (ctx.user.role === 'DRIVER') {
        const job = await ctx.db.towJob.findUnique({ where: { id: input.jobId } });
        const driver = await ctx.db.driver.findUnique({ where: { userId: ctx.user.id } });
        if (job?.driverId !== driver?.id) throw new TRPCError({ code: 'FORBIDDEN' });
      }
      const svc = new JobService(ctx.db, ctx.io);
      return svc.transition(
        input.jobId, input.status, ctx.user.id,
        ctx.user.companyId || (await ctx.db.towJob.findUnique({ where: { id: input.jobId } }))?.companyId || '',
        input.notes,
      );
    }),

  // ── Add Evidence ──────────────────────────────────────────────────────────
  addEvidence: protectedProcedure
    .input(AddEvidenceSchema)
    .mutation(async ({ ctx, input }) => {
      const job = await ctx.db.towJob.findUnique({ where: { id: input.jobId } });
      if (!job) throw new TRPCError({ code: 'NOT_FOUND' });
      const svc = new JobService(ctx.db, ctx.io);
      const updated = await svc.addEvidence(input.jobId, input.photoUrls, ctx.user.id, job.companyId);
      // Async evidence quality check
      void AiService.checkEvidence(input.jobId, job.evidencePhotoUrls.concat(input.photoUrls), ctx.db).catch(() => null);
      return updated;
    }),

  // ── Get Presigned Upload URL ───────────────────────────────────────────────
  getUploadUrl: protectedProcedure
    .input(PresignedUrlRequestSchema)
    .mutation(async ({ input }) => {
      const key = `evidence/${input.jobId}/${Date.now()}-${input.angle.toLowerCase()}.${input.contentType.split('/')[1]}`;
      const url = await generatePresignedUploadUrl(key, input.contentType, 300);
      return { uploadUrl: url, key, publicUrl: `${process.env.R2_PUBLIC_URL}/${key}` };
    }),

  // ── Flag Dispute ──────────────────────────────────────────────────────────
  flagDispute: dispatcherProcedure
    .input(z.object({ jobId: z.string().uuid(), reason: z.string().min(10), evidenceNotes: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const svc = new JobService(ctx.db, ctx.io);
      await svc.transition(input.jobId, 'DISPUTED', ctx.user.id, ctx.user.companyId!, input.reason);
      return ctx.db.dispute.create({
        data: {
          jobId: input.jobId,
          raisedById: ctx.user.id,
          reason: input.reason,
          evidenceNotes: input.evidenceNotes,
          status: 'OPEN',
        },
      });
    }),

  // ── Cancel Job ────────────────────────────────────────────────────────────
  cancel: dispatcherProcedure
    .input(z.object({ jobId: z.string().uuid(), reason: z.string().min(5) }))
    .mutation(async ({ ctx, input }) => {
      const svc = new JobService(ctx.db, ctx.io);
      return svc.transition(input.jobId, 'CANCELLED', ctx.user.id, ctx.user.companyId!, input.reason);
    }),

  // ── Get Job Timeline ──────────────────────────────────────────────────────
  getTimeline: protectedProcedure
    .input(z.object({ jobId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      return ctx.db.jobEvent.findMany({
        where: { jobId: input.jobId },
        orderBy: { timestamp: 'asc' },
        include: { actor: { select: { firstName: true, lastName: true, role: true } } },
      });
    }),

  // ── Confirm Dropoff (Driver) ───────────────────────────────────────────────
  confirmDropoff: protectedProcedure
    .input(z.object({
      jobId: z.string().uuid(),
      lotId: z.string().uuid(),
      bayLabel: z.string().optional(),
      dropoffPhotoUrls: z.array(z.string().url()).min(1),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const job = await ctx.db.towJob.findUnique({ where: { id: input.jobId } });
      if (!job) throw new TRPCError({ code: 'NOT_FOUND' });

      const svc = new JobService(ctx.db, ctx.io);
      await svc.addEvidence(input.jobId, input.dropoffPhotoUrls, ctx.user.id, job.companyId);

      // Create impound record
      await ctx.db.impoundRecord.upsert({
        where: { jobId: input.jobId },
        create: {
          jobId: input.jobId,
          lotId: input.lotId,
          bayLabel: input.bayLabel,
          storageStartAt: new Date(),
          status: 'IN_IMPOUND',
        },
        update: { lotId: input.lotId, bayLabel: input.bayLabel },
      });

      // Update lot count
      await ctx.db.impoundLot.update({
        where: { id: input.lotId },
        data: { currentCount: { increment: 1 } },
      });

      await ctx.db.towJob.update({
        where: { id: input.jobId },
        data: { impoundLotId: input.lotId },
      });

      return svc.transition(input.jobId, 'COMPLETED', ctx.user.id, job.companyId, input.notes);
    }),

  // ── Dashboard Stats ───────────────────────────────────────────────────────
  getDashboardStats: companyProcedure
    .query(async ({ ctx }) => {
      const companyId = ctx.user.companyId!;
      const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);

      const [
        totalToday, activeJobs, pendingJobs, completedToday,
        revenueToday, avgDispatchMs,
      ] = await Promise.all([
        ctx.db.towJob.count({ where: { companyId, createdAt: { gte: todayStart } } }),
        ctx.db.towJob.count({ where: { companyId, status: { in: ['DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING'] } } }),
        ctx.db.towJob.count({ where: { companyId, status: 'PENDING' } }),
        ctx.db.towJob.count({ where: { companyId, status: { in: ['COMPLETED', 'RELEASED'] }, completedAt: { gte: todayStart } } }),
        ctx.db.payment.aggregate({ where: { companyId, status: 'SUCCEEDED', paidAt: { gte: todayStart } }, _sum: { totalCents: true } }),
        ctx.db.$queryRaw<{ avg: number }[]>`
          SELECT AVG(EXTRACT(EPOCH FROM (dispatched_at - created_at)) * 1000) as avg
          FROM tow_jobs
          WHERE company_id = ${companyId}
            AND dispatched_at IS NOT NULL
            AND created_at >= ${todayStart}
        `,
      ]);

      return {
        totalToday,
        activeJobs,
        pendingJobs,
        completedToday,
        revenueToday: revenueToday._sum.totalCents ?? 0,
        avgDispatchMs: Math.round(avgDispatchMs[0]?.avg ?? 0),
      };
    }),
});
