import { z } from 'zod';
import { router, dispatcherProcedure, companyProcedure } from '../trpc';
import { DRIVER_LOCATION_TTL_SECONDS } from '@spotra/shared';

export const dispatchRouter = router({

  // ── Live driver locations from Redis ──────────────────────────────────────
  getDriverLocations: dispatcherProcedure
    .query(async ({ ctx }) => {
      const companyId = ctx.user.companyId!;
      const drivers = await ctx.db.driver.findMany({
        where: { companyId },
        include: { user: { select: { firstName: true, lastName: true } }, fleetVehicle: true },
      });

      const locations = await Promise.all(
        drivers.map(async (d) => {
          const cached = await ctx.redis.get(`driver:loc:${d.id}`).then(v => v ? JSON.parse(v) : null);
          return {
            driverId: d.id,
            driverName: `${d.user.firstName} ${d.user.lastName}`,
            vehicleName: d.fleetVehicle ? `${d.fleetVehicle.year} ${d.fleetVehicle.make} ${d.fleetVehicle.model}` : null,
            lat: cached?.lat ?? d.currentLat,
            lng: cached?.lng ?? d.currentLng,
            heading: cached?.heading ?? null,
            isAvailable: d.isAvailable,
            currentJobId: null,
            isOnline: !!cached,
            lastSeenAt: cached?.ts ? new Date(cached.ts) : d.lastSeenAt,
          };
        })
      );

      return locations;
    }),

  // ── Get pending job queue ─────────────────────────────────────────────────
  getQueue: dispatcherProcedure
    .query(async ({ ctx }) => {
      return ctx.db.towJob.findMany({
        where: { companyId: ctx.user.companyId!, status: { in: ['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING'] } },
        orderBy: [{ status: 'asc' }, { createdAt: 'asc' }],
        include: {
          vehicle: true,
          property: true,
          spot: true,
          driver: { include: { user: { select: { firstName: true, lastName: true } } } },
          aiFlags: { where: { resolved: false } },
        },
      });
    }),

  // ── Get AI dispatch suggestion ─────────────────────────────────────────────
  getSuggestion: dispatcherProcedure
    .input(z.object({ jobId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const suggestions = await ctx.redis.get(`dispatch:suggest:${input.jobId}`);
      if (suggestions) return JSON.parse(suggestions);

      // Fall back to basic distance-based ranking
      const job = await ctx.db.towJob.findUnique({
        where: { id: input.jobId },
        include: { property: true },
      });
      if (!job) return null;

      const availableDrivers = await ctx.db.driver.findMany({
        where: { companyId: ctx.user.companyId!, isAvailable: true },
        include: { user: { select: { firstName: true, lastName: true } } },
      });

      if (!availableDrivers.length) return null;

      const scored = availableDrivers
        .filter(d => d.currentLat && d.currentLng)
        .map(d => {
          const dist = haversineKm(
            d.currentLat!, d.currentLng!,
            job.property.lat, job.property.lng
          );
          return {
            driverId: d.id,
            driverName: `${d.user.firstName} ${d.user.lastName}`,
            score: Math.max(0, 100 - dist * 10),
            reason: `${dist.toFixed(1)} km away`,
            distanceMiles: dist * 0.621371,
            estimatedMinutes: Math.round(dist * 3),
          };
        })
        .sort((a, b) => b.score - a.score)
        .slice(0, 3);

      return scored;
    }),

  // ── Available drivers list ─────────────────────────────────────────────────
  getAvailableDrivers: dispatcherProcedure
    .query(async ({ ctx }) => {
      return ctx.db.driver.findMany({
        where: { companyId: ctx.user.companyId!, isAvailable: true },
        include: {
          user: { select: { firstName: true, lastName: true, phone: true } },
          fleetVehicle: true,
        },
      });
    }),

  // ── Today's completed count per driver ────────────────────────────────────
  getDriverStats: companyProcedure
    .query(async ({ ctx }) => {
      const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
      return ctx.db.towJob.groupBy({
        by: ['driverId'],
        where: { companyId: ctx.user.companyId!, status: { in: ['COMPLETED', 'RELEASED'] }, completedAt: { gte: todayStart }, driverId: { not: null } },
        _count: { id: true },
      });
    }),
});

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function toRad(d: number) { return (d * Math.PI) / 180; }
