import { z } from 'zod';
import { router, adminProcedure } from '../trpc';
import { InviteUserSchema } from '@spotra/shared';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { AiService } from '../services/ai.service';

export const adminRouter = router({
  getStats: adminProcedure.query(async ({ ctx }) => {
    const companyId = ctx.user.companyId!;
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const [totalJobs, totalRevenue, activeDrivers, totalProperties, openDisputes, recentFlags] = await Promise.all([
      ctx.db.towJob.count({ where: { companyId } }),
      ctx.db.payment.aggregate({ where: { companyId, status: 'SUCCEEDED' }, _sum: { totalCents: true } }),
      ctx.db.driver.count({ where: { companyId, isAvailable: true } }),
      ctx.db.companyProperty.count({ where: { companyId, isActive: true } }),
      ctx.db.dispute.count({ where: { job: { companyId }, status: { in: ['OPEN', 'UNDER_REVIEW'] } } }),
      ctx.db.aiFlag.findMany({ where: { job: { companyId }, resolved: false }, orderBy: { createdAt: 'desc' }, take: 10, include: { job: { include: { vehicle: true, property: true } } } }),
    ]);

    return { totalJobs, totalRevenue: totalRevenue._sum.totalCents ?? 0, activeDrivers, totalProperties, openDisputes, recentFlags };
  }),

  inviteUser: adminProcedure
    .input(InviteUserSchema)
    .mutation(async ({ ctx, input }) => {
      const tempPassword = crypto.randomBytes(12).toString('hex');
      const hashed = await bcrypt.hash(tempPassword, 10);
      const user = await ctx.db.user.create({
        data: {
          email: input.email.toLowerCase(),
          hashedPassword: hashed,
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
          role: input.role as never,
          companyId: ctx.user.companyId,
          propertyId: input.propertyId,
        },
      });
      return { userId: user.id, email: user.email };
    }),

  listUsers: adminProcedure.query(async ({ ctx }) => {
    return ctx.db.user.findMany({
      where: { companyId: ctx.user.companyId! },
      select: { id: true, email: true, firstName: true, lastName: true, role: true, isActive: true, phone: true, lastLoginAt: true, createdAt: true, property: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }),

  getDailySummary: adminProcedure.query(async ({ ctx }) => {
    return AiService.generateDailySummary(ctx.user.companyId!, ctx.db);
  }),

  updateCompany: adminProcedure
    .input(z.object({
      name: z.string().min(2).optional(),
      phone: z.string().optional(),
      baseTowFeeCents: z.number().int().min(0).optional(),
      storageDailyFeeCents: z.number().int().min(0).optional(),
      afterHoursFeeCents: z.number().int().min(0).optional(),
      convenienceFeeEnabled: z.boolean().optional(),
      convenienceFeeCents: z.number().int().min(0).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      return ctx.db.company.update({ where: { id: ctx.user.companyId! }, data: input });
    }),

  getAuditLog: adminProcedure
    .input(z.object({ jobId: z.string().uuid().optional(), page: z.number().int().min(1).default(1), limit: z.number().int().max(100).default(50) }))
    .query(async ({ ctx, input }) => {
      const where = input.jobId
        ? { jobId: input.jobId }
        : { job: { companyId: ctx.user.companyId! } };
      const skip = (input.page - 1) * input.limit;
      const [items, total] = await Promise.all([
        ctx.db.jobEvent.findMany({ where, orderBy: { timestamp: 'desc' }, skip, take: input.limit, include: { actor: { select: { firstName: true, lastName: true, role: true } } } }),
        ctx.db.jobEvent.count({ where }),
      ]);
      return { items, total, page: input.page, limit: input.limit };
    }),

  resolveFlag: adminProcedure
    .input(z.object({ flagId: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      return ctx.db.aiFlag.update({
        where: { id: input.flagId },
        data: { resolved: true, resolvedById: ctx.user.id, resolvedAt: new Date() },
      });
    }),
});
