import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, companyProcedure, dispatcherProcedure, adminProcedure } from '../trpc';
import { CreateImpoundLotSchema } from '@spotra/shared';

export const impoundRouter = router({
  getLots: companyProcedure.query(async ({ ctx }) => {
    return ctx.db.impoundLot.findMany({
      where: { companyId: ctx.user.companyId!, isActive: true },
      include: { _count: { select: { impoundRecords: true } } },
    });
  }),

  getInventory: companyProcedure
    .input(z.object({ lotId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      return ctx.db.impoundRecord.findMany({
        where: { lotId: input.lotId, status: 'IN_IMPOUND' },
        include: {
          job: {
            include: {
              vehicle: true,
              payment: { select: { status: true, totalCents: true, paidAt: true } },
            },
          },
        },
        orderBy: { storageStartAt: 'asc' },
      });
    }),

  releaseVehicle: dispatcherProcedure
    .input(z.object({ jobId: z.string().uuid(), notes: z.string().optional() }))
    .mutation(async ({ ctx, input }) => {
      const record = await ctx.db.impoundRecord.findUnique({
        where: { jobId: input.jobId },
        include: { job: { include: { payment: true } } },
      });
      if (!record) throw new TRPCError({ code: 'NOT_FOUND' });
      if (record.job.payment?.status !== 'SUCCEEDED') {
        throw new TRPCError({ code: 'BAD_REQUEST', message: 'Payment must be completed before release' });
      }

      await Promise.all([
        ctx.db.impoundRecord.update({
          where: { jobId: input.jobId },
          data: { status: 'RELEASED', releaseAt: new Date() },
        }),
        ctx.db.towJob.update({
          where: { id: input.jobId },
          data: { status: 'RELEASED', vehicleStatus: 'RELEASED', releasedAt: new Date() },
        }),
        ctx.db.impoundLot.update({
          where: { id: record.lotId },
          data: { currentCount: { decrement: 1 } },
        }),
      ]);

      await ctx.db.jobEvent.create({
        data: {
          jobId: input.jobId,
          actorId: ctx.user.id,
          eventType: 'VEHICLE_RELEASED',
          payload: { notes: input.notes || null },
        },
      });

      return { ok: true };
    }),

  createLot: adminProcedure
    .input(CreateImpoundLotSchema)
    .mutation(async ({ ctx, input }) => {
      return ctx.db.impoundLot.create({ data: { ...input, companyId: ctx.user.companyId! } });
    }),
});
