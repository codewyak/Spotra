import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, adminProcedure, propertyProcedure, companyProcedure } from '../trpc';
import { CreatePropertySchema, CreateParkingSpotSchema, InviteUserSchema } from '@spotra/shared';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';

export const propertyRouter = router({

  // ── Create property (admin only) ──────────────────────────────────────────
  create: adminProcedure
    .input(CreatePropertySchema)
    .mutation(async ({ ctx, input }) => {
      const property = await ctx.db.property.create({ data: input });

      await ctx.db.companyProperty.create({
        data: { companyId: ctx.user.companyId!, propertyId: property.id, isDefault: true },
      });

      await ctx.db.jobEvent.create({
        data: { jobId: 'system', actorId: ctx.user.id, eventType: 'PROPERTY_CREATED', payload: { propertyId: property.id, name: property.name } },
      }).catch(() => null); // system event, not tied to job

      return property;
    }),

  // ── List properties for this company ─────────────────────────────────────
  list: companyProcedure
    .query(async ({ ctx }) => {
      const contracts = await ctx.db.companyProperty.findMany({
        where: { companyId: ctx.user.companyId!, isActive: true },
        include: {
          property: {
            include: {
              parkingSpots: { where: { isActive: true }, select: { id: true, zone: true, label: true, spotType: true } },
              _count: { select: { towJobs: true } },
            },
          },
        },
      });
      return contracts.map(c => c.property);
    }),

  // ── Get single property ────────────────────────────────────────────────────
  get: propertyProcedure
    .input(z.object({ id: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const property = await ctx.db.property.findUnique({
        where: { id: input.id },
        include: {
          parkingSpots: { where: { isActive: true }, orderBy: [{ zone: 'asc' }, { label: 'asc' }] },
          companyProperties: { where: { isActive: true }, include: { company: { select: { id: true, name: true } } } },
        },
      });
      if (!property) throw new TRPCError({ code: 'NOT_FOUND' });
      return property;
    }),

  // ── Add parking spots ─────────────────────────────────────────────────────
  addSpots: adminProcedure
    .input(z.object({ spots: z.array(CreateParkingSpotSchema).min(1).max(100) }))
    .mutation(async ({ ctx, input }) => {
      return ctx.db.parkingSpot.createMany({ data: input.spots, skipDuplicates: true });
    }),

  // ── Update spot authorized plates ────────────────────────────────────────
  updateSpotPlates: propertyProcedure
    .input(z.object({ spotId: z.string().uuid(), authorizedPlates: z.array(z.string()).max(10) }))
    .mutation(async ({ ctx, input }) => {
      return ctx.db.parkingSpot.update({
        where: { id: input.spotId },
        data: { authorizedPlates: input.authorizedPlates.map(p => p.toUpperCase()) },
      });
    }),

  // ── Get enforcement history for a property ────────────────────────────────
  getHistory: propertyProcedure
    .input(z.object({
      propertyId: z.string().uuid(),
      page: z.number().int().min(1).default(1),
      limit: z.number().int().min(1).max(50).default(20),
    }))
    .query(async ({ ctx, input }) => {
      const skip = (input.page - 1) * input.limit;
      const [items, total] = await Promise.all([
        ctx.db.towJob.findMany({
          where: { propertyId: input.propertyId },
          orderBy: { createdAt: 'desc' },
          skip, take: input.limit,
          include: { vehicle: true, driver: { include: { user: { select: { firstName: true, lastName: true } } } }, payment: { select: { status: true, totalCents: true } } },
        }),
        ctx.db.towJob.count({ where: { propertyId: input.propertyId } }),
      ]);
      return { items, total, page: input.page, limit: input.limit, hasMore: skip + items.length < total };
    }),

  // ── Invite a property manager ─────────────────────────────────────────────
  inviteManager: adminProcedure
    .input(InviteUserSchema.extend({ propertyId: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      const tempPassword = crypto.randomBytes(12).toString('hex');
      const hashedPassword = await bcrypt.hash(tempPassword, 10);

      const user = await ctx.db.user.create({
        data: {
          email: input.email.toLowerCase(),
          hashedPassword,
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
          role: input.role as never,
          companyId: ctx.user.companyId,
          propertyId: input.propertyId,
        },
      });

      // TODO: Send invite email via SendGrid with tempPassword
      // await notificationService.sendInviteEmail(user.email, tempPassword);

      return { userId: user.id, email: user.email, tempPassword }; // In production, don't return tempPassword
    }),

  // ── Property analytics ─────────────────────────────────────────────────────
  getAnalytics: propertyProcedure
    .input(z.object({ propertyId: z.string().uuid(), days: z.number().int().min(1).max(90).default(30) }))
    .query(async ({ ctx, input }) => {
      const since = new Date(Date.now() - input.days * 24 * 60 * 60 * 1000);

      const [totalJobs, byViolation, byZone, byStatus] = await Promise.all([
        ctx.db.towJob.count({ where: { propertyId: input.propertyId, createdAt: { gte: since } } }),
        ctx.db.towJob.groupBy({
          by: ['violationReason'],
          where: { propertyId: input.propertyId, createdAt: { gte: since } },
          _count: { id: true },
          orderBy: { _count: { id: 'desc' } },
        }),
        ctx.db.$queryRaw<{ zone: string; count: bigint }[]>`
          SELECT ps.zone, COUNT(*) as count
          FROM tow_jobs tj
          JOIN parking_spots ps ON tj.spot_id = ps.id
          WHERE tj.property_id = ${input.propertyId}
            AND tj.created_at >= ${since}
          GROUP BY ps.zone
          ORDER BY count DESC
        `,
        ctx.db.towJob.groupBy({
          by: ['status'],
          where: { propertyId: input.propertyId, createdAt: { gte: since } },
          _count: { id: true },
        }),
      ]);

      return {
        totalJobs,
        byViolation: byViolation.map(r => ({ reason: r.violationReason, count: r._count.id })),
        byZone: byZone.map(r => ({ zone: r.zone, count: Number(r.count) })),
        byStatus: byStatus.map(r => ({ status: r.status, count: r._count.id })),
      };
    }),
});
