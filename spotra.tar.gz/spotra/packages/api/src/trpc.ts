import { initTRPC, TRPCError } from '@trpc/server';
import type { CreateExpressContextOptions } from '@trpc/server/adapters/express';
import type { Server as SocketServer } from 'socket.io';
import type Redis from 'ioredis';
import { db } from '@spotra/db';
import { verifyAccessToken } from './services/auth.service';
import type { AuthUser } from '@spotra/shared';

export interface TrpcContext {
  req: CreateExpressContextOptions['req'];
  res: CreateExpressContextOptions['res'];
  user: AuthUser | null;
  db: typeof db;
  io: SocketServer;
  redis: Redis;
}

export function createContext(io: SocketServer, redis: Redis) {
  return async ({ req, res }: CreateExpressContextOptions): Promise<TrpcContext> => {
    let user: AuthUser | null = null;

    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.slice(7);
      try {
        user = await verifyAccessToken(token, db);
      } catch {
        // Invalid token — user stays null, protected procedures will reject
      }
    }

    return { req, res, user, db, io, redis };
  };
}

const t = initTRPC.context<TrpcContext>().create({
  errorFormatter({ shape, error }) {
    return {
      ...shape,
      data: {
        ...shape.data,
        zodError: error.cause instanceof Error ? null : null,
      },
    };
  },
});

export const router = t.router;
export const publicProcedure = t.procedure;

// Require any authenticated user
export const protectedProcedure = t.procedure.use(({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Authentication required' });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

// Company-scoped procedures
export const companyProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!ctx.user.companyId) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Company account required' });
  }
  return next({ ctx: { ...ctx, user: ctx.user, companyId: ctx.user.companyId } });
});

// Admin or Dispatcher only
export const dispatcherProcedure = companyProcedure.use(({ ctx, next }) => {
  const allowed = ['SUPER_ADMIN', 'COMPANY_ADMIN', 'DISPATCHER'];
  if (!allowed.includes(ctx.user.role)) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Dispatcher or admin role required' });
  }
  return next({ ctx });
});

// Company Admin only
export const adminProcedure = companyProcedure.use(({ ctx, next }) => {
  if (!['SUPER_ADMIN', 'COMPANY_ADMIN'].includes(ctx.user.role)) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin role required' });
  }
  return next({ ctx });
});

// Driver only
export const driverProcedure = companyProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'DRIVER') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Driver role required' });
  }
  return next({ ctx });
});

// Property Manager/Staff
export const propertyProcedure = protectedProcedure.use(({ ctx, next }) => {
  const allowed = ['SUPER_ADMIN', 'COMPANY_ADMIN', 'PROPERTY_MANAGER', 'PROPERTY_STAFF'];
  if (!allowed.includes(ctx.user.role)) {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Property access required' });
  }
  return next({ ctx });
});
