import { TRPCError } from '@trpc/server';
import type { PrismaClient } from '@prisma/client';
import type { Server as SocketServer } from 'socket.io';
import {
  VALID_TRANSITIONS, MIN_EVIDENCE_PHOTOS, TERMINAL_STATUSES,
  type JobStatus,
} from '@spotra/shared';

export class JobService {
  constructor(private db: PrismaClient, private io: SocketServer) {}

  async transition(
    jobId: string,
    toStatus: JobStatus,
    actorId: string | null,
    companyId: string,
    notes?: string,
  ) {
    const job = await this.db.towJob.findUnique({
      where: { id: jobId, companyId },
      include: { driver: true },
    });

    if (!job) {
      throw new TRPCError({ code: 'NOT_FOUND', message: 'Job not found' });
    }

    const currentStatus = job.status as JobStatus;

    if (TERMINAL_STATUSES.includes(currentStatus)) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: `Job is in terminal status ${currentStatus} and cannot be changed`,
      });
    }

    const allowed = VALID_TRANSITIONS[currentStatus];
    if (!allowed.includes(toStatus)) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: `Cannot transition from ${currentStatus} to ${toStatus}. Allowed: ${allowed.join(', ')}`,
      });
    }

    // Business rule: cannot start towing without minimum evidence
    if (toStatus === 'TOWING' && job.evidencePhotoCount < MIN_EVIDENCE_PHOTOS) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: `Minimum ${MIN_EVIDENCE_PHOTOS} evidence photos required before towing. Current: ${job.evidencePhotoCount}`,
      });
    }

    // Build timestamp updates
    const timestampUpdate: Record<string, Date> = {};
    const now = new Date();
    if (toStatus === 'DISPATCHED') timestampUpdate.dispatchedAt = now;
    if (toStatus === 'ARRIVED') timestampUpdate.arrivedAt = now;
    if (toStatus === 'TOWING') timestampUpdate.towStartedAt = now;
    if (toStatus === 'COMPLETED') timestampUpdate.completedAt = now;
    if (toStatus === 'RELEASED') timestampUpdate.releasedAt = now;
    if (toStatus === 'DISPUTED') timestampUpdate.disputedAt = now;
    if (toStatus === 'CANCELLED') timestampUpdate.cancelledAt = now;

    const updatedJob = await this.db.towJob.update({
      where: { id: jobId },
      data: { status: toStatus, ...timestampUpdate },
      include: { vehicle: true, property: true, driver: { include: { user: true } } },
    });

    // Audit log
    await this.db.jobEvent.create({
      data: {
        jobId,
        actorId,
        eventType: 'STATUS_CHANGED',
        payload: {
          from: currentStatus,
          to: toStatus,
          notes: notes || null,
          timestamp: now.toISOString(),
        },
      },
    });

    // WebSocket broadcast to company room
    this.io.to(companyId).emit('job:status_changed', {
      type: 'job:status_changed',
      payload: {
        jobId,
        previousStatus: currentStatus,
        status: toStatus,
        driverId: updatedJob.driverId,
        propertyName: updatedJob.property.name,
        vehiclePlate: updatedJob.vehicle.plate,
      },
      timestamp: now,
    });

    // If returned to PENDING after driver decline, notify dispatchers
    if (toStatus === 'PENDING' && currentStatus === 'DISPATCHED') {
      this.io.to(companyId).emit('job:declined', {
        type: 'job:declined',
        payload: { jobId, driverId: job.driverId },
        timestamp: now,
      });
    }

    return updatedJob;
  }

  async assignDriver(jobId: string, driverId: string, actorId: string, companyId: string) {
    const [job, driver] = await Promise.all([
      this.db.towJob.findUnique({ where: { id: jobId, companyId, status: 'PENDING' } }),
      this.db.driver.findUnique({ where: { id: driverId, companyId, isAvailable: true } }),
    ]);

    if (!job) throw new TRPCError({ code: 'NOT_FOUND', message: 'Job not found or not in PENDING status' });
    if (!driver) throw new TRPCError({ code: 'BAD_REQUEST', message: 'Driver not found or unavailable' });

    const updatedJob = await this.db.towJob.update({
      where: { id: jobId },
      data: {
        driverId,
        status: 'DISPATCHED',
        dispatchedAt: new Date(),
      },
      include: {
        vehicle: true,
        property: true,
        spot: true,
        driver: { include: { user: true } },
      },
    });

    await this.db.jobEvent.create({
      data: {
        jobId,
        actorId,
        eventType: 'DRIVER_ASSIGNED',
        payload: { driverId, driverName: `${driver.user?.firstName} ${driver.user?.lastName}` || driverId },
      },
    });

    // Broadcast to company + driver's personal room
    this.io.to(companyId).emit('job:driver_assigned', {
      type: 'job:driver_assigned',
      payload: { jobId, driverId, status: 'DISPATCHED' },
      timestamp: new Date(),
    });

    this.io.to(`driver:${driverId}`).emit('job:assigned', {
      type: 'job:assigned',
      payload: {
        jobId,
        ticketNumber: updatedJob.ticketNumber,
        propertyName: updatedJob.property.name,
        propertyAddress: updatedJob.property.address,
        lat: updatedJob.property.lat,
        lng: updatedJob.property.lng,
        violationReason: updatedJob.violationReason,
        vehiclePlate: updatedJob.vehicle.plate,
        spotLabel: updatedJob.spot?.label,
        zone: updatedJob.spot?.zone,
        requestPhotoUrls: updatedJob.requestPhotoUrls,
        notes: updatedJob.notes,
      },
      timestamp: new Date(),
    });

    return updatedJob;
  }

  async addEvidence(
    jobId: string,
    photoUrls: string[],
    actorId: string,
    companyId: string,
  ) {
    const job = await this.db.towJob.findUnique({
      where: { id: jobId, companyId },
    });

    if (!job) throw new TRPCError({ code: 'NOT_FOUND', message: 'Job not found' });

    const allowed: JobStatus[] = ['ARRIVED', 'TOWING'];
    if (!allowed.includes(job.status as JobStatus)) {
      throw new TRPCError({
        code: 'BAD_REQUEST',
        message: 'Evidence can only be added when job is ARRIVED or TOWING',
      });
    }

    const updatedUrls = [...job.evidencePhotoUrls, ...photoUrls];
    const newCount = updatedUrls.length;

    const updated = await this.db.towJob.update({
      where: { id: jobId },
      data: {
        evidencePhotoUrls: updatedUrls,
        evidencePhotoCount: newCount,
      },
    });

    await this.db.jobEvent.create({
      data: {
        jobId,
        actorId,
        eventType: 'EVIDENCE_ADDED',
        payload: { addedUrls: photoUrls, totalCount: newCount },
      },
    });

    this.io.to(companyId).emit('job:evidence_added', {
      type: 'job:evidence_added',
      payload: { jobId, photoCount: newCount, readyToTow: newCount >= MIN_EVIDENCE_PHOTOS },
      timestamp: new Date(),
    });

    return updated;
  }
}
