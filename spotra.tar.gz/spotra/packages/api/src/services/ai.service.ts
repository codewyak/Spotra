import OpenAI from 'openai';
import type { PrismaClient } from '@prisma/client';
import type { Server as SocketServer } from 'socket.io';
import type { DispatchSuggestion, EvidenceCheckResult } from '@spotra/shared';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class AiService {

  // ── OCR: Extract plate from evidence photos ───────────────────────────────
  static async runOcr(jobId: string, photoUrls: string[], db: PrismaClient): Promise<string | null> {
    if (!photoUrls.length || !process.env.OPENAI_API_KEY) return null;

    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        max_tokens: 100,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Look at this vehicle photo. Extract the license plate number and state if visible. Respond ONLY with JSON: {"plate": "PLATE_TEXT", "state": "XX", "confidence": 0.0-1.0}. If not visible, return {"plate": null, "state": null, "confidence": 0}.',
            },
            { type: 'image_url', image_url: { url: photoUrls[0], detail: 'high' } },
          ],
        }],
      });

      const raw = response.choices[0]?.message?.content?.replace(/```json|```/g, '').trim();
      if (!raw) return null;
      const parsed = JSON.parse(raw);

      if (parsed.plate && parsed.confidence > 0.6) {
        await db.towJob.update({
          where: { id: jobId },
          data: { ocrPlateResult: `${parsed.plate} (${parsed.state ?? 'unknown'})` },
        });
        return parsed.plate;
      }
    } catch (err) {
      console.error('[AI] OCR failed:', err);
    }
    return null;
  }

  // ── Evidence quality check ─────────────────────────────────────────────────
  static async checkEvidence(jobId: string, photoUrls: string[], db: PrismaClient): Promise<EvidenceCheckResult | null> {
    if (photoUrls.length < 2 || !process.env.OPENAI_API_KEY) return null;

    try {
      const imageContent = photoUrls.slice(0, 6).map(url => ({
        type: 'image_url' as const,
        image_url: { url, detail: 'low' as const },
      }));

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        max_tokens: 400,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'text',
              text: `You are a towing evidence quality reviewer. Review these ${photoUrls.length} evidence photos for a parking violation tow.
Check:
1. Is the license plate clearly visible and readable?
2. Is the violation (wrong spot, no permit, etc.) clearly documented?
3. Are these angles present: front of vehicle, rear of vehicle, license plate, violation area?
4. Are any photos blurry, too dark, or unusable?

Respond ONLY with JSON (no markdown):
{
  "score": 0-100,
  "missing": ["list of missing angles or issues"],
  "flags": ["any quality problems"],
  "plateDetected": "PLATE_TEXT or null",
  "confidence": 0.0-1.0
}`,
            },
            ...imageContent,
          ],
        }],
      });

      const raw = response.choices[0]?.message?.content?.replace(/```json|```/g, '').trim();
      if (!raw) return null;
      const result: EvidenceCheckResult = JSON.parse(raw);

      // Persist score
      await db.towJob.update({ where: { id: jobId }, data: { evidenceScore: result.score } });

      // Create AI flags for issues
      if (result.flags.length > 0 || result.score < 60) {
        await db.aiFlag.create({
          data: {
            jobId,
            flagType: 'EVIDENCE_INCOMPLETE',
            severity: result.score < 50 ? 'HIGH' : result.score < 70 ? 'MEDIUM' : 'LOW',
            message: [...result.flags, ...result.missing].join('; ') || 'Evidence quality below threshold',
            payload: result as never,
          },
        });
      }

      return result;
    } catch (err) {
      console.error('[AI] Evidence check failed:', err);
      return null;
    }
  }

  // ── Dispatch suggestion ────────────────────────────────────────────────────
  static async suggestDriver(jobId: string, companyId: string, db: PrismaClient, io: SocketServer): Promise<DispatchSuggestion[] | null> {
    try {
      const [job, drivers] = await Promise.all([
        db.towJob.findUnique({ where: { id: jobId }, include: { property: true, vehicle: true } }),
        db.driver.findMany({
          where: { companyId, isAvailable: true },
          include: { user: { select: { firstName: true, lastName: true } }, fleetVehicle: true },
        }),
      ]);

      if (!job || !drivers.length) return null;

      const driverContext = drivers
        .filter(d => d.currentLat && d.currentLng)
        .map(d => ({
          id: d.id,
          name: `${d.user.firstName} ${d.user.lastName}`,
          lat: d.currentLat,
          lng: d.currentLng,
          vehicle: d.fleetVehicle ? `${d.fleetVehicle.year} ${d.fleetVehicle.make}` : 'Unknown',
        }));

      if (!driverContext.length) return null;

      const prompt = `You are a tow dispatch AI. Rank these available drivers for a tow job.

Job details:
- Property: ${job.property.name}, ${job.property.address}
- Coordinates: ${job.property.lat}, ${job.property.lng}
- Violation: ${job.violationReason}
- Vehicle: ${job.vehicle.make ?? ''} ${job.vehicle.model ?? ''} ${job.vehicle.plate}

Available drivers (with current GPS positions):
${driverContext.map(d => `- ID: ${d.id}, Name: ${d.name}, Vehicle: ${d.vehicle}, Position: ${d.lat}, ${d.lng}`).join('\n')}

Rank by: proximity (primary), vehicle suitability (secondary).
Calculate approximate driving distance and ETA.

Respond ONLY with JSON array (top 3):
[{"driverId": "...", "driverName": "...", "score": 0-100, "reason": "concise reason", "distanceMiles": 0.0, "estimatedMinutes": 0}]`;

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }],
      });

      const raw = response.choices[0]?.message?.content?.replace(/```json|```/g, '').trim();
      if (!raw) return null;
      const suggestions: DispatchSuggestion[] = JSON.parse(raw);

      // Cache in Redis for 2 minutes
      const { createClient } = await import('redis');
      // Note: in production, inject Redis instead of creating a new client here

      // Broadcast suggestion to dispatchers
      io.to(companyId).emit('dispatch:suggestion', {
        type: 'dispatch:suggestion',
        payload: { jobId, suggestions: suggestions.slice(0, 3) },
        timestamp: new Date(),
      });

      return suggestions;
    } catch (err) {
      console.error('[AI] Dispatch suggestion failed:', err);
      return null;
    }
  }

  // ── Daily operational summary ─────────────────────────────────────────────
  static async generateDailySummary(companyId: string, db: PrismaClient): Promise<string> {
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
    yesterday.setHours(0, 0, 0, 0);
    const today = new Date(yesterday.getTime() + 24 * 60 * 60 * 1000);

    const [jobs, revenue, disputes, topViolations] = await Promise.all([
      db.towJob.groupBy({
        by: ['status'],
        where: { companyId, createdAt: { gte: yesterday, lt: today } },
        _count: { id: true },
      }),
      db.payment.aggregate({
        where: { companyId, status: 'SUCCEEDED', paidAt: { gte: yesterday, lt: today } },
        _sum: { totalCents: true },
        _count: { id: true },
      }),
      db.dispute.count({ where: { job: { companyId }, createdAt: { gte: yesterday, lt: today } } }),
      db.towJob.groupBy({
        by: ['violationReason'],
        where: { companyId, createdAt: { gte: yesterday, lt: today } },
        _count: { id: true },
        orderBy: { _count: { id: 'desc' } },
        take: 3,
      }),
    ]);

    const totalJobs = jobs.reduce((sum, j) => sum + j._count.id, 0);
    const completed = jobs.find(j => j.status === 'COMPLETED')?._count.id ?? 0;
    const revenueFormatted = `$${((revenue._sum.totalCents ?? 0) / 100).toFixed(2)}`;

    if (!process.env.OPENAI_API_KEY) {
      return `Daily Summary: ${totalJobs} tows, ${completed} completed, ${revenueFormatted} revenue, ${disputes} disputes.`;
    }

    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      max_tokens: 300,
      messages: [{
        role: 'user',
        content: `Write a brief, professional daily operations summary for a towing company dispatcher. Keep it to 3-4 sentences, highlight anything notable.

Data for ${yesterday.toDateString()}:
- Total tow jobs: ${totalJobs}
- Completed: ${completed}
- Revenue collected: ${revenueFormatted} (${revenue._count.id} payments)
- Disputes filed: ${disputes}
- Top violations: ${topViolations.map(v => `${v.violationReason} (${v._count.id})`).join(', ')}`,
      }],
    });

    return response.choices[0]?.message?.content ?? 'Summary unavailable';
  }
}
