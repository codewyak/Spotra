import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { TRPCError } from '@trpc/server';
import type { PrismaClient } from '@prisma/client';
import type { TokenPayload, AuthUser } from '@spotra/shared';
import crypto from 'crypto';

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET!;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET!;
const ACCESS_EXPIRES = process.env.JWT_ACCESS_EXPIRES_IN || '15m';
const REFRESH_EXPIRES = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

export function issueAccessToken(payload: Omit<TokenPayload, 'iat' | 'exp'>): string {
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: ACCESS_EXPIRES } as jwt.SignOptions);
}

export function issueRefreshToken(): string {
  return crypto.randomBytes(40).toString('hex');
}

export async function verifyAccessToken(token: string, db: PrismaClient): Promise<AuthUser> {
  let payload: TokenPayload;
  try {
    payload = jwt.verify(token, ACCESS_SECRET) as TokenPayload;
  } catch {
    throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Invalid or expired token' });
  }

  const user = await db.user.findUnique({
    where: { id: payload.userId, isActive: true },
    select: {
      id: true, email: true, firstName: true, lastName: true,
      role: true, companyId: true, propertyId: true, avatarUrl: true,
    },
  });

  if (!user) {
    throw new TRPCError({ code: 'UNAUTHORIZED', message: 'User not found' });
  }

  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role as AuthUser['role'],
    companyId: user.companyId,
    propertyId: user.propertyId,
    avatarUrl: user.avatarUrl,
  };
}

export async function loginUser(email: string, password: string, db: PrismaClient) {
  // Constant-time lookup to prevent timing attacks
  const user = await db.user.findUnique({
    where: { email: email.toLowerCase() },
    select: {
      id: true, email: true, firstName: true, lastName: true,
      role: true, companyId: true, propertyId: true, avatarUrl: true,
      hashedPassword: true, isActive: true,
    },
  });

  const dummyHash = '$2a$10$dummy.hash.for.timing.safety.dontmatch';
  const hashToCompare = user?.hashedPassword ?? dummyHash;
  const isValid = await bcrypt.compare(password, hashToCompare);

  if (!user || !isValid || !user.isActive) {
    throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Invalid email or password' });
  }

  const tokenPayload: Omit<TokenPayload, 'iat' | 'exp'> = {
    userId: user.id,
    companyId: user.companyId,
    propertyId: user.propertyId,
    role: user.role as TokenPayload['role'],
  };

  const accessToken = issueAccessToken(tokenPayload);
  const refreshToken = issueRefreshToken();
  const refreshTokenHash = await bcrypt.hash(refreshToken, 8);
  const family = crypto.randomUUID();

  await db.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash: refreshTokenHash,
      family,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  await db.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  return {
    accessToken,
    refreshToken,
    expiresIn: 900,
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      companyId: user.companyId,
      propertyId: user.propertyId,
      avatarUrl: user.avatarUrl,
    },
  };
}

export async function refreshAccessToken(rawRefreshToken: string, db: PrismaClient) {
  const tokens = await db.refreshToken.findMany({
    where: { isRevoked: false, expiresAt: { gt: new Date() } },
    include: { user: { select: { id: true, role: true, companyId: true, propertyId: true, isActive: true } } },
  });

  let matched: typeof tokens[0] | null = null;
  for (const token of tokens) {
    const ok = await bcrypt.compare(rawRefreshToken, token.tokenHash);
    if (ok) { matched = token; break; }
  }

  if (!matched || !matched.user.isActive) {
    throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Invalid refresh token' });
  }

  // Rotate: revoke old, issue new
  await db.refreshToken.update({ where: { id: matched.id }, data: { isRevoked: true } });

  const newRefreshToken = issueRefreshToken();
  const newHash = await bcrypt.hash(newRefreshToken, 8);

  await db.refreshToken.create({
    data: {
      userId: matched.userId,
      tokenHash: newHash,
      family: matched.family,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  const accessToken = issueAccessToken({
    userId: matched.userId,
    companyId: matched.user.companyId,
    propertyId: matched.user.propertyId,
    role: matched.user.role as TokenPayload['role'],
  });

  return { accessToken, refreshToken: newRefreshToken, expiresIn: 900 };
}
