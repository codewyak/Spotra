import type { PrismaClient } from '@prisma/client';
import type { FeeBreakdown } from '@spotra/shared';

export class FeeService {
  constructor(private db: PrismaClient) {}

  async calculateFees(jobId: string, at: Date = new Date()): Promise<FeeBreakdown> {
    const job = await this.db.towJob.findUnique({
      where: { id: jobId },
      include: {
        company: true,
        companyProperty: false,
      },
    });

    if (!job) throw new Error(`Job ${jobId} not found`);
    if (!job.completedAt) throw new Error('Job has not been completed yet');

    const company = job.company;

    // Get property-specific fee overrides if any
    const contractOverride = await this.db.companyProperty.findUnique({
      where: { companyId_propertyId: { companyId: job.companyId, propertyId: job.propertyId } },
    });

    const baseTowCents = contractOverride?.baseTowFeeCents ?? company.baseTowFeeCents;
    const dailyRateCents = contractOverride?.storageDailyFeeCents ?? company.storageDailyFeeCents;

    // Storage: whole days from completedAt to now
    const msPerDay = 24 * 60 * 60 * 1000;
    const storageDays = Math.floor((at.getTime() - job.completedAt.getTime()) / msPerDay);
    const storageCents = storageDays * dailyRateCents;

    // After-hours: if tow started between 10pm-7am
    const towHour = job.towStartedAt?.getHours() ?? 12;
    const afterHoursCents = (towHour >= 22 || towHour < 7) ? company.afterHoursFeeCents : 0;

    const subtotal = baseTowCents + storageCents + afterHoursCents;
    const convenienceCents = company.convenienceFeeEnabled ? company.convenienceFeeCents : 0;
    const platformFeeCents = Math.round(subtotal * 0.025); // 2.5%
    const totalCents = subtotal + convenienceCents;

    return {
      baseTowCents,
      storageCents,
      storageDays,
      afterHoursCents,
      convenienceCents,
      platformFeeCents,
      totalCents,
      lockedAt: at,
    };
  }

  formatCents(cents: number): string {
    return `$${(cents / 100).toFixed(2)}`;
  }
}
