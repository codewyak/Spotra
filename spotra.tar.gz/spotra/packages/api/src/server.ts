import express from 'express';
import { createServer } from 'http';
import { Server as SocketServer } from 'socket.io';
import { createExpressMiddleware } from '@trpc/server/adapters/express';
import cors from 'cors';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import Redis from 'ioredis';
import { appRouter } from './root';
import { createContext } from './trpc';
import { verifyAccessToken } from './services/auth.service';
import { db } from '@spotra/db';
import superjson from 'superjson';

const app = express();
const httpServer = createServer(app);

// ── Redis ─────────────────────────────────────────────────────────────────────
const redis = new Redis(process.env.REDIS_URL ?? 'redis://localhost:6379', {
  maxRetriesPerRequest: 3,
  lazyConnect: true,
  retryStrategy: (times) => Math.min(times * 100, 3000),
});

redis.on('error', err => console.error('[Redis]', err));
redis.connect().catch(err => console.error('[Redis] connect error', err));

// ── Socket.io ─────────────────────────────────────────────────────────────────
const io = new SocketServer(httpServer, {
  cors: {
    origin: process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000',
    credentials: true,
  },
  transports: ['websocket', 'polling'],
});

// Socket auth middleware
io.use(async (socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication required'));
  try {
    const user = await verifyAccessToken(token, db);
    (socket as any).user = user;
    next();
  } catch {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const user = (socket as any).user;
  console.log(`[WS] Connected: ${user.email} (${user.role})`);

  // Join tenant rooms
  socket.on('join:company', (companyId: string) => {
    if (user.companyId === companyId || user.role === 'SUPER_ADMIN') {
      socket.join(companyId);
      // Also join driver's personal room
      if (user.role === 'DRIVER') {
        db.driver.findUnique({ where: { userId: user.id } }).then(d => {
          if (d) socket.join(`driver:${d.id}`);
        });
      }
    }
  });

  socket.on('join:property', (propertyId: string) => {
    if (user.propertyId === propertyId || user.companyId) {
      socket.join(`property:${propertyId}`);
    }
  });

  socket.on('disconnect', () => {
    console.log(`[WS] Disconnected: ${user.email}`);
  });
});

// ── Express Middleware ────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000',
  credentials: true,
}));

// Raw body for Stripe webhooks (must come before json parser)
app.use('/api/v1/webhooks/stripe', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '10mb' }));

// Rate limiting
app.use('/api/v1/auth', rateLimit({ windowMs: 60_000, max: 10, message: { error: 'Too many requests' } }));
app.use('/api/v1/vehicles', rateLimit({ windowMs: 60_000, max: 60 }));

// ── tRPC ──────────────────────────────────────────────────────────────────────
app.use(
  '/api/trpc',
  createExpressMiddleware({
    router: appRouter,
    createContext: createContext(io, redis),
    onError: ({ path, error }) => {
      if (error.code !== 'UNAUTHORIZED' && error.code !== 'NOT_FOUND') {
        console.error(`[tRPC] ${path}:`, error);
      }
    },
  })
);

// ── REST: Vehicle Lookup ───────────────────────────────────────────────────────
app.get('/api/v1/vehicles/lookup', async (req, res) => {
  const { q, type = 'plate', state = 'MA' } = req.query as Record<string, string>;
  if (!q) return res.status(400).json({ found: false, error: 'Query required' });

  try {
    const plate = q.toUpperCase().replace(/\s/g, '');
    let job = null;

    if (type === 'ticket') {
      job = await db.towJob.findUnique({
        where: { ticketNumber: plate },
        include: buildJobInclude(),
      });
    } else if (type === 'vin') {
      const vehicle = await db.vehicle.findUnique({ where: { vin: plate } });
      if (vehicle) job = await findActiveJob(vehicle.id);
    } else {
      const vehicle = await db.vehicle.findUnique({ where: { plate_state: { plate, state } } });
      if (vehicle) job = await findActiveJob(vehicle.id);
    }

    if (!job) return res.json({ found: false });

    const { FeeService } = await import('./services/fee.service');
    const feeService = new FeeService(db);
    let fees = null;
    if (['COMPLETED', 'RELEASED'].includes(job.status)) {
      fees = await feeService.calculateFees(job.id).catch(() => null);
    }

    return res.json({
      found: true,
      jobId: job.id,
      ticketNumber: job.ticketNumber,
      status: job.status,
      towedAt: job.towStartedAt ?? job.dispatchedAt ?? job.createdAt,
      completedAt: job.completedAt,
      vehicle: { plate: job.vehicle.plate, state: job.vehicle.state, make: job.vehicle.make, model: job.vehicle.model, color: job.vehicle.color, year: job.vehicle.year },
      company: { name: job.company.name, phone: job.company.phone },
      impoundLot: job.impoundLot ? { name: job.impoundLot.name, address: job.impoundLot.address, lat: job.impoundLot.lat, lng: job.impoundLot.lng, phone: job.impoundLot.phone, hours: job.impoundLot.hoursJson } : null,
      fees: fees ? { baseTowCents: fees.baseTowCents, storageCents: fees.storageCents, storageDays: fees.storageDays, totalCents: fees.totalCents, calculatedAt: fees.lockedAt } : null,
      requiresDocuments: ['Valid government-issued photo ID', 'Vehicle registration or proof of ownership'],
      paymentStatus: (job as any).payment?.status ?? null,
    });
  } catch (err) {
    console.error('[vehicle lookup]', err);
    return res.status(500).json({ found: false, error: 'Server error' });
  }
});

// ── REST: Initiate Payment ─────────────────────────────────────────────────────
app.post('/api/v1/payments/initiate', async (req, res) => {
  const { jobId, ownerEmail, ownerName } = req.body ?? {};
  if (!jobId || !ownerEmail || !ownerName) {
    return res.status(400).json({ error: 'jobId, ownerEmail, and ownerName are required' });
  }

  try {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });

    const job = await db.towJob.findUnique({
      where: { id: jobId, status: { in: ['COMPLETED', 'RELEASED'] } },
      include: { company: true, vehicle: true, payment: true },
    });
    if (!job) return res.status(404).json({ error: 'Job not found or not ready for payment' });
    if (job.payment?.status === 'SUCCEEDED') return res.status(400).json({ error: 'Already paid' });
    if (!job.company.stripeAccountId) return res.status(400).json({ error: 'Company payment not configured' });

    const { FeeService } = await import('./services/fee.service');
    const fees = await new FeeService(db).calculateFees(jobId);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: fees.totalCents,
      currency: 'usd',
      application_fee_amount: fees.platformFeeCents,
      transfer_data: { destination: job.company.stripeAccountId },
      metadata: { jobId, companyId: job.companyId, plate: job.vehicle.plate },
      receipt_email: ownerEmail,
    });

    await db.payment.upsert({
      where: { jobId },
      create: { jobId, companyId: job.companyId, stripePaymentIntentId: paymentIntent.id, ...fees, status: 'PENDING', ownerEmail, ownerName, feeLockedAt: new Date() },
      update: { stripePaymentIntentId: paymentIntent.id, ...fees, status: 'PENDING', ownerEmail, ownerName, feeLockedAt: new Date() },
    });

    return res.json({ clientSecret: paymentIntent.client_secret, fees, companyName: job.company.name });
  } catch (err: any) {
    console.error('[payments/initiate]', err);
    return res.status(500).json({ error: err.message });
  }
});

// ── REST: Stripe Webhook ──────────────────────────────────────────────────────
app.post('/api/v1/webhooks/stripe', async (req, res) => {
  const Stripe = (await import('stripe')).default;
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });
  const sig = req.headers['stripe-signature'] as string;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return res.status(400).json({ error: 'Invalid webhook signature' });
  }

  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object as any;
    await db.payment.update({
      where: { stripePaymentIntentId: pi.id },
      data: { status: 'SUCCEEDED', paidAt: new Date(), stripeChargeId: pi.latest_charge },
    }).catch(() => null);
    await db.jobEvent.create({
      data: { jobId: pi.metadata.jobId, eventType: 'PAYMENT_SUCCEEDED', payload: { amount: pi.amount } },
    }).catch(() => null);
    // Notify dispatcher via WebSocket
    io.to(pi.metadata.companyId).emit('job:updated', {
      type: 'job:updated',
      payload: { jobId: pi.metadata.jobId, paymentStatus: 'SUCCEEDED' },
      timestamp: new Date(),
    });
  }

  if (event.type === 'payment_intent.payment_failed') {
    const pi = event.data.object as any;
    await db.payment.update({ where: { stripePaymentIntentId: pi.id }, data: { status: 'FAILED' } }).catch(() => null);
  }

  return res.json({ received: true });
});

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  const [dbOk, redisOk] = await Promise.all([
    db.$queryRaw`SELECT 1`.then(() => true).catch(() => false),
    redis.ping().then(() => true).catch(() => false),
  ]);
  const status = dbOk && redisOk ? 200 : 503;
  res.status(status).json({ status: status === 200 ? 'ok' : 'degraded', db: dbOk, redis: redisOk, ts: new Date() });
});

// ── Boot ──────────────────────────────────────────────────────────────────────
async function buildJobInclude() {
  return {
    vehicle: true,
    company: { select: { name: true, phone: true } },
    impoundLot: { select: { name: true, address: true, lat: true, lng: true, phone: true, hoursJson: true } },
    payment: { select: { status: true, totalCents: true } },
  };
}

async function findActiveJob(vehicleId: string) {
  return db.towJob.findFirst({
    where: { vehicleId, status: { in: ['PENDING', 'DISPATCHED', 'EN_ROUTE', 'ARRIVED', 'TOWING', 'COMPLETED'] } },
    orderBy: { createdAt: 'desc' },
    include: {
      vehicle: true,
      company: { select: { name: true, phone: true } },
      impoundLot: { select: { name: true, address: true, lat: true, lng: true, phone: true, hoursJson: true } },
      payment: { select: { status: true, totalCents: true } },
    },
  });
}

const PORT = Number(process.env.API_PORT ?? 3001);
httpServer.listen(PORT, () => {
  console.log(`\n🚀 Spotra API running on port ${PORT}`);
  console.log(`   tRPC:    http://localhost:${PORT}/api/trpc`);
  console.log(`   Health:  http://localhost:${PORT}/health`);
  console.log(`   WS:      ws://localhost:${PORT}\n`);
});

export { io };
