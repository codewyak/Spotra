import { PrismaClient, UserRole, Plan, JobStatus, SpotType, VehicleStatus } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding Spotra database...');

  // ── Company ──────────────────────────────────────────────────────────────────
  const company = await prisma.company.upsert({
    where: { slug: 'boston-tow-co' },
    update: {},
    create: {
      name: 'Boston Tow Co.',
      slug: 'boston-tow-co',
      email: 'ops@bostontowco.com',
      phone: '617-555-0100',
      address: '47 Drydock Ave',
      city: 'Boston',
      state: 'MA',
      zip: '02210',
      plan: Plan.GROWTH,
      status: 'ACTIVE',
      baseTowFeeCents: 15000,
      storageDailyFeeCents: 4500,
      afterHoursFeeCents: 5000,
      convenienceFeeEnabled: false,
    },
  });
  console.log('✅ Company created:', company.name);

  // ── Users ─────────────────────────────────────────────────────────────────────
  const hashedPw = await bcrypt.hash('Password123!', 10);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@bostontowco.com' },
    update: {},
    create: {
      email: 'admin@bostontowco.com',
      hashedPassword: hashedPw,
      firstName: 'Sarah',
      lastName: 'Chen',
      phone: '617-555-0101',
      role: UserRole.COMPANY_ADMIN,
      companyId: company.id,
    },
  });

  const dispatcher = await prisma.user.upsert({
    where: { email: 'dispatch@bostontowco.com' },
    update: {},
    create: {
      email: 'dispatch@bostontowco.com',
      hashedPassword: hashedPw,
      firstName: 'Marcus',
      lastName: 'Rivera',
      phone: '617-555-0102',
      role: UserRole.DISPATCHER,
      companyId: company.id,
    },
  });

  const driverUser1 = await prisma.user.upsert({
    where: { email: 'driver1@bostontowco.com' },
    update: {},
    create: {
      email: 'driver1@bostontowco.com',
      hashedPassword: hashedPw,
      firstName: 'James',
      lastName: 'Okafor',
      phone: '617-555-0201',
      role: UserRole.DRIVER,
      companyId: company.id,
    },
  });

  const driverUser2 = await prisma.user.upsert({
    where: { email: 'driver2@bostontowco.com' },
    update: {},
    create: {
      email: 'driver2@bostontowco.com',
      hashedPassword: hashedPw,
      firstName: 'Maria',
      lastName: 'Santos',
      phone: '617-555-0202',
      role: UserRole.DRIVER,
      companyId: company.id,
    },
  });

  const driverUser3 = await prisma.user.upsert({
    where: { email: 'driver3@bostontowco.com' },
    update: {},
    create: {
      email: 'driver3@bostontowco.com',
      hashedPassword: hashedPw,
      firstName: 'Tony',
      lastName: 'Marchetti',
      phone: '617-555-0203',
      role: UserRole.DRIVER,
      companyId: company.id,
    },
  });

  const propManagerUser = await prisma.user.upsert({
    where: { email: 'manager@harborview.com' },
    update: {},
    create: {
      email: 'manager@harborview.com',
      hashedPassword: hashedPw,
      firstName: 'Dana',
      lastName: 'Park',
      phone: '617-555-0301',
      role: UserRole.PROPERTY_MANAGER,
      companyId: company.id,
    },
  });

  console.log('✅ Users created');

  // ── Fleet Vehicles ─────────────────────────────────────────────────────────────
  const truck1 = await prisma.fleetVehicle.upsert({
    where: { id: 'fleet-truck-1' },
    update: {},
    create: {
      id: 'fleet-truck-1',
      companyId: company.id,
      make: 'Ford',
      model: 'F-450 Tow',
      year: 2022,
      plate: 'TOW-001',
      color: 'Yellow',
    },
  });

  const truck2 = await prisma.fleetVehicle.upsert({
    where: { id: 'fleet-truck-2' },
    update: {},
    create: {
      id: 'fleet-truck-2',
      companyId: company.id,
      make: 'Ram',
      model: '3500 Flatbed',
      year: 2021,
      plate: 'TOW-002',
      color: 'White',
    },
  });

  const truck3 = await prisma.fleetVehicle.upsert({
    where: { id: 'fleet-truck-3' },
    update: {},
    create: {
      id: 'fleet-truck-3',
      companyId: company.id,
      make: 'Chevrolet',
      model: 'Silverado 3500',
      year: 2023,
      plate: 'TOW-003',
      color: 'Black',
    },
  });

  // ── Drivers ───────────────────────────────────────────────────────────────────
  const driver1 = await prisma.driver.upsert({
    where: { userId: driverUser1.id },
    update: {},
    create: {
      userId: driverUser1.id,
      companyId: company.id,
      licenseNumber: 'MA-CDL-00123',
      isAvailable: true,
      currentLat: 42.3601,
      currentLng: -71.0589,
      fleetVehicleId: truck1.id,
    },
  });

  const driver2 = await prisma.driver.upsert({
    where: { userId: driverUser2.id },
    update: {},
    create: {
      userId: driverUser2.id,
      companyId: company.id,
      licenseNumber: 'MA-CDL-00456',
      isAvailable: true,
      currentLat: 42.3555,
      currentLng: -71.0605,
      fleetVehicleId: truck2.id,
    },
  });

  const driver3 = await prisma.driver.upsert({
    where: { userId: driverUser3.id },
    update: {},
    create: {
      userId: driverUser3.id,
      companyId: company.id,
      licenseNumber: 'MA-CDL-00789',
      isAvailable: false,
      currentLat: 42.3620,
      currentLng: -71.0541,
      fleetVehicleId: truck3.id,
    },
  });

  console.log('✅ Drivers created');

  // ── Impound Lot ────────────────────────────────────────────────────────────────
  const lot = await prisma.impoundLot.upsert({
    where: { id: 'impound-lot-main' },
    update: {},
    create: {
      id: 'impound-lot-main',
      companyId: company.id,
      name: 'Boston Tow Co. Main Yard',
      address: '47 Drydock Ave, Boston, MA 02210',
      lat: 42.3468,
      lng: -71.0425,
      capacity: 150,
      currentCount: 12,
      phone: '617-555-0100',
      hoursJson: {
        mon: '7am-8pm', tue: '7am-8pm', wed: '7am-8pm',
        thu: '7am-8pm', fri: '7am-8pm', sat: '8am-6pm', sun: '9am-5pm',
      },
    },
  });

  console.log('✅ Impound lot created');

  // ── Properties ────────────────────────────────────────────────────────────────
  const property1 = await prisma.property.upsert({
    where: { id: 'prop-harborview' },
    update: {},
    create: {
      id: 'prop-harborview',
      name: 'Harborview Apartments',
      address: '100 Seaport Blvd',
      city: 'Boston',
      state: 'MA',
      zip: '02210',
      lat: 42.3519,
      lng: -71.0430,
    },
  });

  const property2 = await prisma.property.upsert({
    where: { id: 'prop-backbay' },
    update: {},
    create: {
      id: 'prop-backbay',
      name: 'Back Bay HOA',
      address: '225 Newbury St',
      city: 'Boston',
      state: 'MA',
      zip: '02116',
      lat: 42.3505,
      lng: -71.0789,
    },
  });

  // Link properties to company
  await prisma.companyProperty.upsert({
    where: { companyId_propertyId: { companyId: company.id, propertyId: property1.id } },
    update: {},
    create: { companyId: company.id, propertyId: property1.id, isDefault: true },
  });

  await prisma.companyProperty.upsert({
    where: { companyId_propertyId: { companyId: company.id, propertyId: property2.id } },
    update: {},
    create: { companyId: company.id, propertyId: property2.id, isDefault: true },
  });

  // Link property manager to property1
  await prisma.user.update({
    where: { id: propManagerUser.id },
    data: { propertyId: property1.id },
  });

  // ── Parking Spots ─────────────────────────────────────────────────────────────
  const spots = [];
  for (let i = 1; i <= 10; i++) {
    const spot = await prisma.parkingSpot.upsert({
      where: { propertyId_zone_label: { propertyId: property1.id, zone: 'A', label: `${i}` } },
      update: {},
      create: {
        propertyId: property1.id,
        zone: 'A',
        label: `${i}`,
        spotType: i <= 2 ? SpotType.HANDICAP : i === 3 ? SpotType.VISITOR : SpotType.RESERVED,
        authorizedPlates: i <= 5 ? [`7XKJ${100 + i}`, `RESI${i}MA`] : [],
      },
    });
    spots.push(spot);
  }
  console.log('✅ Parking spots created');

  // ── Vehicles ──────────────────────────────────────────────────────────────────
  const vehicle1 = await prisma.vehicle.upsert({
    where: { plate_state: { plate: '7XKA123', state: 'MA' } },
    update: {},
    create: {
      plate: '7XKA123',
      state: 'MA',
      make: 'Toyota',
      model: 'Camry',
      color: 'Silver',
      year: 2019,
    },
  });

  const vehicle2 = await prisma.vehicle.upsert({
    where: { plate_state: { plate: 'NH-BLUE22', state: 'NH' } },
    update: {},
    create: {
      plate: 'NH-BLUE22',
      state: 'NH',
      make: 'Honda',
      model: 'Civic',
      color: 'Blue',
      year: 2020,
    },
  });

  console.log('✅ Vehicles created');

  // ── Tow Jobs ──────────────────────────────────────────────────────────────────
  const completedAt = new Date(Date.now() - 1000 * 60 * 60 * 3); // 3 hours ago

  const job1 = await prisma.towJob.upsert({
    where: { ticketNumber: 'SPOT-DEMO-001' },
    update: {},
    create: {
      ticketNumber: 'SPOT-DEMO-001',
      companyId: company.id,
      propertyId: property1.id,
      spotId: spots[4].id,
      vehicleId: vehicle1.id,
      driverId: driver1.id,
      status: JobStatus.COMPLETED,
      violationReason: 'No permit displayed',
      requestPhotoUrls: [
        'https://picsum.photos/seed/ev1/800/600',
        'https://picsum.photos/seed/ev2/800/600',
      ],
      evidencePhotoUrls: [
        'https://picsum.photos/seed/ev3/800/600',
        'https://picsum.photos/seed/ev4/800/600',
        'https://picsum.photos/seed/ev5/800/600',
        'https://picsum.photos/seed/ev6/800/600',
      ],
      evidencePhotoCount: 4,
      vehicleStatus: VehicleStatus.IN_IMPOUND,
      impoundLotId: lot.id,
      dispatchedAt: new Date(Date.now() - 1000 * 60 * 60 * 4),
      arrivedAt: new Date(Date.now() - 1000 * 60 * 60 * 3.5),
      towStartedAt: new Date(Date.now() - 1000 * 60 * 60 * 3.3),
      completedAt,
      evidenceScore: 87,
    },
  });

  // Create impound record for job1
  await prisma.impoundRecord.upsert({
    where: { jobId: job1.id },
    update: {},
    create: {
      jobId: job1.id,
      lotId: lot.id,
      bayLabel: 'A-14',
      storageStartAt: completedAt,
      status: VehicleStatus.IN_IMPOUND,
    },
  });

  const job2 = await prisma.towJob.upsert({
    where: { ticketNumber: 'SPOT-DEMO-002' },
    update: {},
    create: {
      ticketNumber: 'SPOT-DEMO-002',
      companyId: company.id,
      propertyId: property1.id,
      spotId: spots[6].id,
      vehicleId: vehicle2.id,
      status: JobStatus.PENDING,
      violationReason: 'Wrong parking spot',
      requestPhotoUrls: [
        'https://picsum.photos/seed/ev7/800/600',
        'https://picsum.photos/seed/ev8/800/600',
      ],
      evidencePhotoCount: 0,
    },
  });

  // Audit events
  await prisma.jobEvent.createMany({
    skipDuplicates: true,
    data: [
      { jobId: job1.id, actorId: admin.id, eventType: 'JOB_CREATED', payload: { source: 'seed' }, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4.1) },
      { jobId: job1.id, actorId: dispatcher.id, eventType: 'DRIVER_ASSIGNED', payload: { driverId: driver1.id }, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4) },
      { jobId: job1.id, actorId: driverUser1.id, eventType: 'STATUS_CHANGED', payload: { from: 'DISPATCHED', to: 'EN_ROUTE' }, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3.8) },
      { jobId: job1.id, actorId: driverUser1.id, eventType: 'STATUS_CHANGED', payload: { from: 'EN_ROUTE', to: 'ARRIVED' }, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3.5) },
      { jobId: job1.id, actorId: driverUser1.id, eventType: 'EVIDENCE_ADDED', payload: { count: 4, score: 87 }, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3.3) },
      { jobId: job1.id, actorId: driverUser1.id, eventType: 'STATUS_CHANGED', payload: { from: 'TOWING', to: 'COMPLETED' }, timestamp: completedAt },
      { jobId: job2.id, actorId: propManagerUser.id, eventType: 'JOB_CREATED', payload: { source: 'property_portal' }, timestamp: new Date(Date.now() - 1000 * 60 * 20) },
    ],
  });

  console.log('✅ Tow jobs + events created');
  console.log('\n🎉 Seed complete!');
  console.log('\n📧 Demo logins (password: Password123!):');
  console.log('   Admin:      admin@bostontowco.com');
  console.log('   Dispatcher: dispatch@bostontowco.com');
  console.log('   Driver 1:   driver1@bostontowco.com');
  console.log('   Driver 2:   driver2@bostontowco.com');
  console.log('   Prop Mgr:   manager@harborview.com');
  console.log('\n🔍 Demo vehicle lookup: plate "7XKA123" state "MA"');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
